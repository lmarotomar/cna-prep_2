/**
 * CNA ProMaster - High Difficulty Question Database (BILINGUAL)
 */

const allBatteries = [
    {
        name: "Batería 1: Cuidados Básicos / Basic Care (Expert Level)",
        questions: [
            {
                text_en: "A resident with Alzheimer's disease becomes agitated and attempts to strike the CNA during a bed bath. What is the MOST appropriate initial action?",
                text_es: "Un residente con enfermedad de Alzheimer se agita e intenta golpear al CNA durante un baño en cama. ¿Cuál es la acción inicial MÁS apropiada?",
                options_en: [
                    "Restrain the resident to prevent injury to the CNA.",
                    "Step back and speak in a calm, soothing voice.",
                    "Complete the bath quickly before the resident gets more upset.",
                    "Call for another CNA to help hold the resident down."
                ],
                options_es: [
                    "Sujetar al residente para evitar lesiones al CNA.",
                    "Dar un paso atrás y hablar con voz tranquila y reconfortante.",
                    "Completar el baño rápidamente antes de que el residente se altere más.",
                    "Llamar a otro CNA para que ayude a sujetar al residente."
                ],
                correct: 1,
                reason_en: "De-escalation and safety of both the resident and staff are priority. Stepping back prevents injury while a calm voice may soothe the resident.",
                reason_es: "La desescalada y la seguridad tanto del residente como del personal son prioridad. Dar un paso atrás evita lesiones, mientras que una voz tranquila puede calmar al residente."
            },
            {
                text_en: "When measuring a resident's blood pressure, the CNA notices the reading is 158/94 mmHg. The resident has no history of hypertension. What should the CNA do FIRST?",
                text_es: "Al medir la presión arterial de un residente, el CNA nota que la lectura es 158/94 mmHg. El residente no tiene antecedentes de hipertensión. ¿Qué debe hacer el CNA PRIMERO?",
                options_en: [
                    "Wait 30 minutes and remeasure the blood pressure.",
                    "Document the reading in the resident's chart.",
                    "Report the finding immediately to the charge nurse.",
                    "Tell the resident they need to start taking medication."
                ],
                options_es: [
                    "Esperar 30 minutos y volver a medir la presión arterial.",
                    "Documentar la lectura en el expediente del residente.",
                    "Informar el hallazgo inmediatamente a la enfermera a cargo.",
                    "Decirle al residente que debe empezar a tomar medicamentos."
                ],
                correct: 2,
                reason_en: "Unexpected high readings must be reported immediately to the nurse for assessment, especially if the resident has no prior history.",
                reason_es: "Las lecturas altas inesperadas deben informarse de inmediato a la enfermera para su evaluación, especialmente si el residente no tiene antecedentes previos."
            },
            {
                text_en: "A resident is on a clear liquid diet. Which of the following items is the CNA allowed to serve?",
                text_es: "Un residente tiene una dieta de líquidos claros. ¿Cuál de los siguientes elementos se le permite servir al CNA?",
                options_en: [
                    "Orange juice with pulp",
                    "Vanilla ice cream",
                    "Apple juice",
                    "Cream of mushroom soup"
                ],
                options_es: [
                    "Jugo de naranja con pulpa",
                    "Helado de vainilla",
                    "Jugo de manzana",
                    "Crema de champiñones"
                ],
                correct: 2,
                reason_en: "Clear liquid diets include only fluids you can see through. Orange juice with pulp, cream soup, and ice cream are not allowed.",
                reason_es: "Las dietas de líquidos claros incluyen solo fluidos que se pueden ver a través de ellos. El jugo de naranja con pulpa, las cremas y el helado no están permitidos."
            },
            {
                text_en: "The CNA finds a resident lying on the floor. After ensuring the resident is conscious and breathing, what is the NEXT action?",
                text_es: "El CNA encuentra a un residente tendido en el suelo. Después de asegurarse de que el residente esté consciente y respire, ¿cuál es la SIGUIENTE acción?",
                options_en: [
                    "Help the resident back into bed immediately.",
                    "Go find the nurse to report the fall.",
                    "Stay with the resident and call for help.",
                    "Check the resident for a pulse."
                ],
                options_es: [
                    "Ayudar al residente a volver a la cama inmediatamente.",
                    "Ir a buscar a la enfermera para informar la caída.",
                    "Permanecer con el residente y pedir ayuda.",
                    "Comprobar el pulso del residente."
                ],
                correct: 2,
                reason_en: "The CNA should never leave a resident who has fallen. Staying with them while calling for help ensures their safety until the nurse arrives.",
                reason_es: "El CNA nunca debe dejar solo a un residente que se ha caído. Permanecer con ellos mientras se pide ayuda garantiza su seguridad hasta que llegue la enfermera."
            },
            {
                text_en: "A CNA is assigned to a resident who is in droplet precautions. Which personal protective equipment (PPE) is REQUIRED before entering the room?",
                text_es: "Se asigna a un CNA a un residente que tiene precauciones por gotas. ¿Qué equipo de protección personal (EPP) es REQUERIDO antes de entrar a la habitación?",
                options_en: [
                    "Gown, gloves, and N95 mask",
                    "Gloves and a surgical mask",
                    "Gown and gloves only",
                    "Full face shield and gown"
                ],
                options_es: [
                    "Bata, guantes y mascarilla N95",
                    "Guantes y una mascarilla quirúrgica",
                    "Solo bata y guantes",
                    "Protector facial completo y bata"
                ],
                correct: 1,
                reason_en: "Droplet precautions require a standard surgical mask and gloves. N95 is for airborne precautions.",
                reason_es: "Las precauciones por gotas requieren una mascarilla quirúrgica estándar y guantes. La N95 es para precauciones por vía aérea."
            },
            {
                text_en: "Which of the following is a sign of a localized infection?",
                text_es: "¿Cuál de los siguientes es un signo de una infección localizada?",
                options_en: [
                    "Fever and chills",
                    "Redness and swelling at the site",
                    "Fatigue and body aches",
                    "Low blood pressure"
                ],
                options_es: [
                    "Fiebre y escalofríos",
                    "Enrojecimiento e hinchazón en el sitio",
                    "Fatiga y dolores corporales",
                    "Presión arterial baja"
                ],
                correct: 1,
                reason_en: "Localized infection signs are specific to the area (redness, swelling, heat). Fever and chills are signs of systemic infection.",
                reason_es: "Los signos de infección localizada son específicos del área (enrojecimiento, hinchazón, calor). La fiebre y los escalofríos son signos de infección sistémica."
            },
            {
                text_en: "A resident with a right-sided weakness is being dressed. How should the CNA proceed?",
                text_es: "Se está vistiendo a un residente con debilidad en el lado derecho. ¿Cómo debe proceder el CNA?",
                options_en: [
                    "Dress the left side first, then the right side.",
                    "Dress the right side first, then the left side.",
                    "Ask the resident to dress themselves entirely.",
                    "Put on both sleeves at the same time."
                ],
                options_es: [
                    "Vestir primero el lado izquierdo y luego el derecho.",
                    "Vestir primero el lado derecho y luego el izquierdo.",
                    "Pedir al residente que se vista solo por completo.",
                    "Poner ambas mangas al mismo tiempo."
                ],
                correct: 1,
                reason_en: "When dressing a resident with weakness, always start with the weak side (Right) to make it easier (Put it on the weak side first, take it off the strong side first).",
                reason_es: "Al vestir a un residente con debilidad, comience siempre por el lado débil (derecho) para que sea más fácil (póngasela primero en el lado débil, quítesela primero en el lado fuerte)."
            },
            {
                text_en: "What is the proper position for a resident receiving an enema?",
                text_es: "¿Cuál es la posición adecuada para un residente que recibe un enema?",
                options_en: [
                    "Prone position",
                    "Fowler's position",
                    "Sims' position",
                    "Supine position"
                ],
                options_es: [
                    "Posición prona (boca abajo)",
                    "Posición de Fowler",
                    "Posición de Sims",
                    "Posición supina (boca arriba)"
                ],
                correct: 2,
                reason_en: "Sims' position (left side with right knee flexed) is the standard for rectal procedures.",
                reason_es: "La posición de Sims (lado izquierdo con la rodilla derecha flexionada) es el estándar para procedimientos rectales."
            },
            {
                text_en: "A resident's call light is on. The CNA enters the room and finds the resident clutching their chest and having difficulty breathing. What should the CNA do?",
                text_es: "La luz de llamada de un residente está encendida. El CNA entra en la habitación y encuentra al residente agarrándose el pecho y con dificultad para respirar. ¿Qué debe hacer el CNA?",
                options_en: [
                    "Wait for the resident to catch their breath.",
                    "Place the resident in a supine position.",
                    "Call for the nurse immediately using the emergency call system.",
                    "Go fetch an oxygen tank from the hallway."
                ],
                options_es: [
                    "Esperar a que el residente recupere el aliento.",
                    "Colocar al residente en posición supina.",
                    "Llamar a la enfermera de inmediato usando el sistema de llamada de emergencia.",
                    "Ir a buscar un tanque de oxígeno al pasillo."
                ],
                correct: 2,
                reason_en: "Chest pain and dyspnea are medical emergencies. Immediate reporting is required.",
                reason_es: "El dolor en el pecho y la disnea son emergencias médicas. Se requiere un informe inmediato."
            },
            {
                text_en: "To prevent pressure ulcers in an immobile resident, how often should the CNA reposition them?",
                text_es: "Para prevenir úlceras por presión en un residente inmóvil, ¿con qué frecuencia debe el CNA reposicionarlo?",
                options_en: [
                    "Every 4 hours",
                    "Once per shift",
                    "At least every 2 hours",
                    "Only when the resident asks"
                ],
                options_es: [
                    "Cada 4 horas",
                    "Una vez por turno",
                    "Al menos cada 2 horas",
                    "Solo cuando el residente lo pida"
                ],
                correct: 2,
                reason_en: "The standard for pressure ulcer prevention is repositioning at least every 2 hours.",
                reason_es: "El estándar para la prevención de úlceras por presión es el reposicionamiento al menos cada 2 horas."
            },
            {
                text_en: "Which of the following is the CORRECT way to identify a resident before providing care?",
                text_es: "¿Cuál de las siguientes es la forma CORRECTA de identificar a un residente antes de brindarle cuidados?",
                options_en: [
                    "Ask the resident, 'Are you Mr. Miller?'",
                    "Check the name on the door of the room.",
                    "Check the resident's identification band and compare it to the care plan.",
                    "Ask the roommate to confirm the resident's name."
                ],
                options_es: [
                    "Preguntar al residente: '¿Es usted el Sr. Miller?'",
                    "Verificar el nombre en la puerta de la habitación.",
                    "Verificar la pulsera de identificación del residente y compararla con el plan de cuidados.",
                    "Pedir al compañero de cuarto que confirme el nombre del residente."
                ],
                correct: 2,
                reason_en: "Proper identification requires using at least two identifiers, such as the ID band and the resident's own statement (though not a leading question).",
                reason_es: "La identificación adecuada requiere usar al menos dos identificadores, como la pulsera de identificación y la propia declaración del residente (aunque no una pregunta dirigida)."
            },
            {
                text_en: "A CNA is assisting a resident with a meal. The resident begins to cough forcefully and can speak. What should the CNA do?",
                text_es: "Un CNA está ayudando a un residente con una comida. El residente comienza a toser con fuerza y puede hablar. ¿Qué debe hacer el CNA?",
                options_en: [
                    "Perform the Heimlich maneuver immediately.",
                    "Slap the resident on the back.",
                    "Encourage the resident to continue coughing.",
                    "Offer the resident a sip of water to clear their throat."
                ],
                options_es: [
                    "Realizar la maniobra de Heimlich inmediatamente.",
                    "Darle palmadas en la espalda al residente.",
                    "Animar al residente a seguir tosiendo.",
                    "Ofrecer al residente un sorbo de agua para limpiar la garganta."
                ],
                correct: 2,
                reason_en: "If the resident is coughing forcefully and can speak/breathe, the airway is only partially obstructed. Encouraging coughing is the best action.",
                reason_es: "Si el residente tosiera con fuerza y puede hablar/respirar, la vía aérea está solo parcialmente obstruida. Animar a toser es la mejor acción."
            },
            {
                text_en: "When performing perineal care on a female resident, the CNA should wipe:",
                text_es: "Al realizar el cuidado perineal en una residente femenina, el CNA debe limpiar:",
                options_en: [
                    "Back to front.",
                    "Side to side.",
                    "Front to back.",
                    "In a circular motion."
                ],
                options_es: [
                    "De atrás hacia adelante.",
                    "De lado a lado.",
                    "De adelante hacia atrás.",
                    "En movimiento circular."
                ],
                correct: 2,
                reason_en: "Wiping front to back prevents the spread of bacteria from the anal area to the urethra, reducing UTI risk.",
                reason_es: "Limpiar de adelante hacia atrás evita la propagación de bacterias desde el área anal hacia la uretra, reduciendo el riesgo de infección urinaria (UTI)."
            },
            {
                text_en: "A resident who is NPO has a dry mouth. What is the MOST appropriate action for the CNA?",
                text_es: "Un residente que está en NPO (nada por boca) tiene la boca seca. ¿Cuál es la acción MÁS apropiada para el CNA?",
                options_en: [
                    "Give the resident a small glass of water.",
                    "Provide oral care with a moist swab.",
                    "Ignore it, as they are NPO.",
                    "Give the resident a piece of hard candy."
                ],
                options_es: [
                    "Darle al residente un vaso pequeño de agua.",
                    "Proporcionar cuidado oral con un hisopo húmedo.",
                    "Ignorarlo, ya que están en NPO.",
                    "Darle al residente un trozo de caramelo duro."
                ],
                correct: 1,
                reason_en: "NPO means nothing by mouth. Oral care with a moist swab provides comfort without ingestion.",
                reason_es: "NPO significa nada por boca. El cuidado oral con un hisopo húmedo brinda comodidad sin ingestión."
            },
            {
                text_en: "What is the first sign of a pressure ulcer?",
                text_es: "¿Cuál es el primer signo de una úlcera por presión?",
                options_en: [
                    "A deep crater in the skin.",
                    "Bleeding and pus drainage.",
                    "Redness that does not go away when pressed (non-blanchable).",
                    "Blue or purple discoloration."
                ],
                options_es: [
                    "Un cráter profundo en la piel.",
                    "Sangrado y drenaje de pus.",
                    "Enrojecimiento que no desaparece al presionar (no blanqueable).",
                    "Decoloración azul o púrpura."
                ],
                correct: 2,
                reason_en: "Stage 1 pressure ulcers are characterized by non-blanchable erythema (redness that doesn't turn white when pressed).",
                reason_es: "Las úlceras por presión de Etapa 1 se caracterizan por eritema no blanqueable (enrojecimiento que no se vuelve blanco al presionarlo)."
            },
            {
                text_en: "The CNA is weighing a resident who has a history of congestive heart failure. The CNA notices the resident has gained 4 pounds since yesterday. What should the CNA do?",
                text_es: "El CNA está pesando a un residente que tiene antecedentes de insuficiencia cardíaca congestiva. El CNA nota que el residente ha ganado 4 libras desde ayer. ¿Qué debe hacer el CNA?",
                options_en: [
                    "Assume the scale is broken and use a different one.",
                    "Ignore it, as weight fluctuates daily.",
                    "Report the weight gain immediately to the nurse.",
                    "Tell the resident to stop drinking so much water."
                ],
                options_es: [
                    "Asumir que la báscula está rota y usar una diferente.",
                    "Ignorarlo, ya que el peso fluctúa a diario.",
                    "Informar el aumento de peso inmediatamente a la enfermera.",
                    "Decirle al residente que deje de beber tanta agua."
                ],
                correct: 2,
                reason_en: "Sudden weight gain in CHF patients indicates fluid retention and must be reported immediately.",
                reason_es: "El aumento repentino de peso en pacientes con ICC indica retención de líquidos y debe informarse de inmediato."
            },
            {
                text_en: "When transferring a resident from a bed to a wheelchair, the CNA should:",
                text_es: "Al trasladar a un residente de la cama a una silla de ruedas, el CNA debe:",
                options_en: [
                    "Keep their feet close together and bend at the waist.",
                    "Ask the resident to put their arms around the CNA's neck.",
                    "Place the wheelchair on the resident's stronger side.",
                    "Unlock the wheelchair brakes to allow for movement."
                ],
                options_es: [
                    "Mantener los pies juntos y doblar la cintura.",
                    "Pedir al residente que ponga los brazos alrededor del cuello del CNA.",
                    "Colocar la silla de ruedas en el lado más fuerte del residente.",
                    "Desbloquear los frenos de la silla de ruedas para permitir el movimiento."
                ],
                correct: 2,
                reason_en: "Placing the wheelchair on the strong side allows the resident to assist better and improves safety.",
                reason_es: "Colocar la silla de ruedas en el lado fuerte permite que el residente ayude mejor y mejora la seguridad."
            },
            {
                text_en: "Which of the following is a symptom of hypoglycemia (low blood sugar)?",
                text_es: "¿Cuál de los siguientes es un síntoma de hipoglucemia (nivel bajo de azúcar en sangre)?",
                options_en: [
                    "Excessive thirst and frequent urination.",
                    "Fruity-smelling breath.",
                    "Shakiness, sweating, and confusion.",
                    "Dry, hot skin."
                ],
                options_es: [
                    "Sed excesiva y micción frecuente.",
                    "Aliento con olor a fruta.",
                    "Temblores, sudoración y confusión.",
                    "Piel seca y caliente."
                ],
                correct: 2,
                reason_en: "Hypoglycemia often causes 'cold and clammy' skin, shakiness, and mental status changes.",
                reason_es: "La hipoglucemia a menudo causa piel 'fría y húmeda', temblores y cambios en el estado mental."
            },
            {
                text_en: "A resident with a indwelling urinary catheter is in bed. Where should the drainage bag be placed?",
                text_es: "Un residente con una sonda urinaria permanente está en la cama. ¿Dónde debe colocarse la bolsa de drenaje?",
                options_en: [
                    "On the side rail for easy access.",
                    "Attached to the bed frame, below the level of the bladder.",
                    "On the resident's abdomen.",
                    "On the bedside table."
                ],
                options_es: [
                    "En la barandilla lateral para facilitar el acceso.",
                    "Sujeta al marco de la cama, por debajo del nivel de la vejiga.",
                    "En el abdomen del residente.",
                    "En la mesa de noche."
                ],
                correct: 1,
                reason_en: "The bag must be below bladder level to prevent backflow and on the bed frame (not rails) for safety.",
                reason_es: "La bolsa debe estar por debajo del nivel de la vejiga para evitar el reflujo y en el marco de la cama (no en las barandillas) por seguridad."
            },
            {
                text_en: "The CNA is providing post-mortem care. Which of the following is correct?",
                text_es: "El CNA está brindando cuidados post-mortem. ¿Cuál de lo siguiente es correcto?",
                options_en: [
                    "The body should be placed in a prone position.",
                    "Family members should be asked to leave the facility immediately.",
                    "The body should be treated with dignity and respect.",
                    "All tubes and catheters should be pulled out immediately by the CNA."
                ],
                options_es: [
                    "El cuerpo debe colocarse en posición prona.",
                    "Se debe pedir a los familiares que abandonen el centro de inmediato.",
                    "El cuerpo debe ser tratado con dignidad y respeto.",
                    "Todos los tubos y sondas deben ser retirados inmediatamente por el CNA."
                ],
                correct: 2,
                reason_en: "Dignity and respect are essential in post-mortem care. Tube removal depends on facility policy/medical examiner requirements.",
                reason_es: "La dignidad y el respeto son esenciales en el cuidado post-mortem. El retiro de tubos depende de la política del centro/requisitos del médico forense."
            },
            {
                text_en: "A resident is receiving oxygen via nasal cannula. Which of the following is a safety hazard?",
                text_es: "Un residente recibe oxígeno a través de una cánula nasal. ¿Cuál de los siguientes es un riesgo para la seguridad?",
                options_en: [
                    "The resident is wearing a cotton gown.",
                    "The resident's roommate is using an electric razor.",
                    "There is a 'No Smoking' sign on the door.",
                    "The resident is using water-based moisturizer on their lips."
                ],
                options_es: [
                    "El residente lleva una bata de algodón.",
                    "El compañero de cuarto del residente está usando una afeitadora eléctrica.",
                    "Hay un letrero de 'No fumar' en la puerta.",
                    "El residente utiliza crema hidratante a base de agua en los labios."
                ],
                correct: 1,
                reason_en: "Electrical equipment can spark and cause a fire in an oxygen-enriched environment.",
                reason_es: "Los equipos eléctricos pueden generar chispas y provocar un incendio en un entorno enriquecido con oxígeno."
            },
            {
                text_en: "What is the FIRST thing a CNA should do when a fire is discovered in a resident's room?",
                text_es: "¿Qué es lo PRIMERO que debe hacer un CNA cuando se descubre un incendio en la habitación de un residente?",
                options_en: [
                    "Activate the fire alarm.",
                    "Extinguish the fire with a wet blanket.",
                    "Remove the resident from the room.",
                    "Close the door and windows."
                ],
                options_es: [
                    "Activar la alarma de incendios.",
                    "Extinguir el fuego con una manta húmeda.",
                    "Retirar al residente de la habitación.",
                    "Cerrar la puerta y las ventanas."
                ],
                correct: 2,
                reason_en: "Follow RACE: Rescue/Remove, Activate, Contain, Extinguish.",
                reason_es: "Siga RACE: Rescatar/Retirar, Activar, Contener, Extinguir."
            },
            {
                text_en: "Which pulse site is most commonly used for measuring a resident's heart rate?",
                text_es: "¿Qué sitio de pulso se usa con más frecuencia para medir la frecuencia cardíaca de un residente?",
                options_en: ["Carotid", "Brachial", "Radial", "Apical"],
                options_es: ["Carótida", "Braquial", "Radial", "Apical"],
                correct: 2,
                reason_en: "The radial pulse (wrist) is the standard for routine vital signs.",
                reason_es: "El pulso radial (muñeca) es el estándar para los signos vitales de rutina."
            },
            {
                text_en: "A resident has a 'Restraint Alternative' order. This means the CNA should:",
                text_es: "Un residente tiene una orden de 'Alternativa a la Restricción'. Esto significa que el CNA debe:",
                options_en: [
                    "Use a vest restraint instead of a belt.",
                    "Use pillows or chair alarms to prevent falls without restricting movement.",
                    "Tie the resident's hands to the bed rail loosely.",
                    "Only use restraints when the nurse is not looking."
                ],
                options_es: [
                    "Usar un chaleco de restricción en lugar de un cinturón.",
                    "Usar almohadas o alarmas de silla para evitar caídas sin restringir el movimiento.",
                    "Atar las manos del residente a la barandilla de la cama sin apretar.",
                    "Solo usar restricciones cuando la enfermera no esté mirando."
                ],
                correct: 1,
                reason_en: "Restraint alternatives are non-restrictive measures.",
                reason_es: "Las alternativas de restricción son medidas no restrictivas."
            },
            {
                text_en: "A resident is experiencing a grand mal seizure. The CNA should:",
                text_es: "Un residente está sufriendo una convulsión de gran mal. El CNA debe:",
                options_en: [
                    "Place a tongue depressor in the resident's mouth.",
                    "Restrain the resident's limbs to prevent injury.",
                    "Protect the resident's head and clear the area of furniture.",
                    "Give the resident a sip of water."
                ],
                options_es: [
                    "Colocar un depresor lingual en la boca del residente.",
                    "Sujetar las extremidades del residente para evitar lesiones.",
                    "Proteger la cabeza del residente y despejar el área de muebles.",
                    "Darle un sorbo de agua al residente."
                ],
                correct: 2,
                reason_en: "Safety and airway protection (without insertion) are priorities during a seizure.",
                reason_es: "La seguridad y la protección de las vías respiratorias (sin inserción) son prioridades durante una convulsión."
            },
            {
                text_en: "When communicating with a resident who is hard of hearing, the CNA should:",
                text_es: "Al comunicarse con un residente con dificultades auditivas, el CNA debe:",
                options_en: [
                    "Shout as loudly as possible.",
                    "Speak clearly while facing the resident.",
                    "Avoid eye contact to reduce pressure.",
                    "Leave the room and come back later."
                ],
                options_es: [
                    "Gritar lo más fuerte posible.",
                    "Hablar con claridad mientras mira al residente de frente.",
                    "Evitar el contacto visual para reducir la presión.",
                    "Salir de la habitación y volver más tarde."
                ],
                correct: 1,
                reason_en: "Facing the resident and speaking clearly at a normal or slightly lower pitch is most effective.",
                reason_es: "Mirar de frente al residente y hablar con claridad en un tono normal o ligeramente más bajo es lo más eficaz."
            },
            {
                text_en: "Which of the following describes 'Body Mechanics'?",
                text_es: "¿Cuál de los siguientes describe la 'Mecánica Corporal'?",
                options_en: [
                    "The study of how the heart works.",
                    "Using the body in an efficient and careful way to prevent injury.",
                    "A type of exercise for residents.",
                    "The process of cleaning medical equipment."
                ],
                options_es: [
                    "El estudio de cómo funciona el corazón.",
                    "Usar el cuerpo de manera eficiente y cuidadosa para evitar lesiones.",
                    "Un tipo de ejercicio para los residentes.",
                    "El proceso de limpieza de equipos médicos."
                ],
                correct: 1,
                reason_en: "Body mechanics involves proper alignment and lifting techniques.",
                reason_es: "La mecánica corporal implica una alineación adecuada y técnicas de levantamiento correctas."
            },
            {
                text_en: "A resident is angry and shouting at the CNA. The CNA should:",
                text_es: "Un residente está enojado y le grita al CNA. El CNA debe:",
                options_en: [
                    "Shout back so the resident hears them.",
                    "Ignore the resident and walk away.",
                    "Listen and apologize for any perceived slights.",
                    "Call the police."
                ],
                options_es: [
                    "Gritar de vuelta para que el residente lo escuche.",
                    "Ignorar al residente e irse.",
                    "Escuchar y disculparse por cualquier ofensa percibida.",
                    "Llamar a la policía."
                ],
                correct: 2,
                reason_en: "Active listening and remaining calm are key to de-escalation.",
                reason_es: "La escucha activa y mantener la calma son claves para la desescalada."
            },
            {
                text_en: "What is the main purpose of Range of Motion (ROM) exercises?",
                text_es: "¿Cuál es el propósito principal de los ejercicios de rango de movimiento (ROM)?",
                options_en: [
                    "To tire the resident out so they sleep better.",
                    "To prevent contractures and muscle atrophy.",
                    "To increase the resident's blood pressure.",
                    "To help the resident lose weight."
                ],
                options_es: [
                    "Cansar al residente para que duerma mejor.",
                    "Prevenir contracturas y atrofia muscular.",
                    "Aumentar la presión arterial del residente.",
                    "Ayudar al residente a perder peso."
                ],
                correct: 1,
                reason_en: "ROM prevents joints from becoming permanently stiff (contractures).",
                reason_es: "El ROM evita que las articulaciones se vuelvan permanentemente rígidas (contracturas)."
            },
            {
                text_en: "An 'Ombudsman' is a person who:",
                text_es: "Un 'Ombudsman' (defensor del residente) es una persona que:",
                options_en: [
                    "Performs surgery on residents.",
                    "Investigates complaints and protects residents' rights.",
                    "Is in charge of the facility's finances.",
                    "Delivers mail to the residents."
                ],
                options_es: [
                    "Realiza cirugías a los residentes.",
                    "Investiga quejas y protege los derechos de los residentes.",
                    "Está a cargo de las finanzas del centro.",
                    "Entrega el correo a los residentes."
                ],
                correct: 1,
                reason_en: "An ombudsman is a legal advocate for residents in long-term care.",
                reason_es: "Un ombudsman es un defensor legal de los residentes en cuidados a largo plazo."
            },
            {
                text_en: "Which of these is NOT a resident's right?",
                text_es: "¿Cuál de estos NO es un derecho del residente?",
                options_en: [
                    "The right to refuse treatment.",
                    "The right to privacy during visits.",
                    "The right to choose their own physician.",
                    "The right to hit a staff member if they are angry."
                ],
                options_es: [
                    "El derecho a rechazar el tratamiento.",
                    "El derecho a la privacidad durante las visitas.",
                    "El derecho a elegir su propio médico.",
                    "El derecho a golpear a un miembro del personal si está enojado."
                ],
                correct: 3,
                reason_en: "Rights include dignity and refusal, but not violence.",
                reason_es: "Los derechos incluyen la dignidad y el rechazo, pero no la violencia."
            },
            {
                text_en: "When a resident is dying, which sense is usually the LAST to go?",
                text_es: "Cuando un residente está muriendo, ¿qué sentido suele ser el ÚLTIMO en desaparecer?",
                options_en: ["Sight", "Taste", "Hearing", "Smell"],
                options_es: ["Vista", "Gusto", "Oído", "Olfato"],
                correct: 2,
                reason_en: "Hearing is widely believed to be the last sense lost during the dying process.",
                reason_es: "Se cree ampliamente que el oído es el último sentido que se pierde durante el proceso de muerte."
            },
            {
                text_en: "The term 'Aphasia' means:",
                text_es: "El término 'Afasia' significa:",
                options_en: [
                    "Inability to swallow.",
                    "Inability to walk.",
                    "Inability to communicate or understand speech.",
                    "Inability to see clearly."
                ],
                options_es: [
                    "Incapacidad para tragar.",
                    "Incapacidad para caminar.",
                    "Incapacidad para comunicarse o comprender el habla.",
                    "Incapacidad para ver con claridad."
                ],
                correct: 2,
                reason_en: "Aphasia is a language disorder, often following a stroke.",
                reason_es: "La afasia es un trastorno del lenguaje, a menudo después de un accidente cerebrovascular."
            },
            {
                text_en: "A resident has a standard bedside stool. When the CNA provides oral care, they should:",
                text_es: "Un residente tiene un taburete de noche estándar. Cuando el CNA brinda cuidado oral, debe:",
                options_en: [
                    "Brush only the front teeth.",
                    "Use a hard-bristle brush for deep cleaning.",
                    "Assist the resident to sit up at 90 degrees if possible.",
                    "Have the resident lie flat on their back."
                ],
                options_es: [
                    "Cepillar solo los dientes frontales.",
                    "Usar un cepillo de cerdas duras para una limpieza profunda.",
                    "Ayudar al residente a sentarse a 90 grados si es posible.",
                    "Hacer que el residente se acueste boca arriba."
                ],
                correct: 2,
                reason_en: "Aspiration prevention is key; sitting upright is safest.",
                reason_es: "La prevención de la aspiración es clave; sentarse erguido es lo más seguro."
            },
            {
                text_en: "Which department in the hospital deals with the structure and function of the heart?",
                text_es: "¿Qué departamento del hospital se ocupa de la estructura y función del corazón?",
                options_en: ["Neurology", "Cardiology", "Oncology", "Orthopedics"],
                options_es: ["Neurología", "Cardiología", "Oncología", "Ortopedia"],
                correct: 1,
                reason_en: "Cardiology is the study of the heart.",
                reason_es: "La cardiología es el estudio del corazón."
            },
            {
                text_en: "Abduction means:",
                text_es: "Abducción significa:",
                options_en: [
                    "Moving a body part toward the midline.",
                    "Moving a body part away from the midline.",
                    "Turning a body part downward.",
                    "Straightening a limb."
                ],
                options_es: [
                    "Mover una parte del cuerpo hacia la línea media.",
                    "Alejar una parte del cuerpo de la línea media.",
                    "Girar una parte del cuerpo hacia abajo.",
                    "Enderezar una extremidad."
                ],
                correct: 1,
                reason_en: "Abduction = away. Adduction = toward (adding to the midline).",
                reason_es: "Abducción = afuera. Aducción = hacia (añadir a la línea media)."
            },
            {
                text_en: "A resident has an indwelling catheter. The CNA should clean the catheter:",
                text_es: "Un residente tiene una sonda permanente. El CNA debe limpiar la sonda:",
                options_en: [
                    "Toward the meatus.",
                    "Away from the meatus.",
                    "Only once a week.",
                    "With alcohol wipes."
                ],
                options_es: [
                    "Hacia el meato.",
                    "Alejándose del meato.",
                    "Solo una vez a la semana.",
                    "Con toallitas de alcohol."
                ],
                correct: 1,
                reason_en: "Cleaning away from the meatus prevents pushing bacteria into the body.",
                reason_es: "Limpiar alejándose del meato evita empujar bacterias hacia el interior del cuerpo."
            },
            {
                text_en: "When should the CNA wash their hands?",
                text_es: "¿Cuándo debe el CNA lavarse las manos?",
                options_en: [
                    "Only after providing care.",
                    "Only when they look dirty.",
                    "Before and after every resident contact.",
                    "Once at the beginning of the shift."
                ],
                options_es: [
                    "Solo después de brindar cuidados.",
                    "Solo cuando se vean sucias.",
                    "Antes y después de cada contacto con un residente.",
                    "Una vez al comienzo del turno."
                ],
                correct: 2,
                reason_en: "Hand hygiene is the #1 way to prevent infection spread.",
                reason_es: "La higiene de manos es la forma número uno de prevenir la propagación de infecciones."
            },
            {
                text_en: "The 'Golden Rule' of charting is:",
                text_es: "La 'Regla de Oro' del registro (charting) es:",
                options_en: [
                    "If it wasn't documented, it wasn't done.",
                    "Use pencil so you can fix mistakes.",
                    "Only document the good things.",
                    "Wait until the end of the week to do all charting."
                ],
                options_es: [
                    "Si no se documentó, no se hizo.",
                    "Usar lápiz para poder corregir errores.",
                    "Solo documentar las cosas buenas.",
                    "Esperar hasta el final de la semana para hacer todos los registros."
                ],
                correct: 0,
                reason_en: "Legal documentation requires real-time, accurate records.",
                reason_es: "La documentación legal requiere registros precisos y en tiempo real."
            },
            {
                text_en: "A resident is on 'Fluid Restriction'. This means the CNA should:",
                text_es: "Un residente tiene 'Restricción de Líquidos'. Esto significa que el CNA debe:",
                options_en: [
                    "Give the resident as much water as they want.",
                    "Measure and record all fluid intake carefully.",
                    "Hide the water pitcher from the resident.",
                    "Only give water if the nurse is present."
                ],
                options_es: [
                    "Darle al residente tanta agua como quiera.",
                    "Medir y registrar cuidadosamente toda la ingesta de líquidos.",
                    "Esconder la jarra de agua al residente.",
                    "Solo dar agua si la enfermera está presente."
                ],
                correct: 1,
                reason_en: "Restriction requires precise monitoring of intake and output (I&O).",
                reason_es: "La restricción requiere un seguimiento preciso de la ingesta y la eliminación (I&O)."
            },
            {
                text_en: "What does 'PRN' mean?",
                text_es: "¿Qué significa 'PRN'?",
                options_en: ["Every morning", "After meals", "As needed", "Immediately"],
                options_es: ["Cada mañana", "Después de las comidas", "Según sea necesario", "Inmediatamente"],
                correct: 2,
                reason_en: "Pro re nata (as needed).",
                reason_es: "Pro re nata (según sea necesario)."
            },
            {
                text_en: "Which of the following is a normal pulse rate for an adult?",
                text_es: "¿Cuál de los siguientes es una frecuencia de pulso normal para un adulto?",
                options_en: ["40-60 bpm", "60-100 bpm", "100-120 bpm", "120-140 bpm"],
                options_es: ["40-60 lpm", "60-100 lpm", "100-120 lpm", "120-140 lpm"],
                correct: 1,
                reason_en: "60-100 is the standard adult range.",
                reason_es: "60-100 es el rango estándar para adultos."
            },
            {
                text_en: "A resident's skin is 'cyanotic'. This means it is:",
                text_es: "La piel de un residente está 'cianótica'. Esto significa que está:",
                options_en: ["Red", "Yellow", "Blueish/Gray", "Pale white"],
                options_es: ["Roja", "Amarilla", "Azulada/Gris", "Blanco pálido"],
                correct: 2,
                reason_en: "Cyanosis indicates lack of oxygen in the blood.",
                reason_es: "La cianosis indica falta de oxígeno en la sangre."
            },
            {
                text_en: "Which of the following is an example of non-verbal communication?",
                text_es: "¿Cuál de los siguientes es un ejemplo de comunicación no verbal?",
                options_en: [
                    "Writing a note.",
                    "Speaking on the phone.",
                    "Crossing your arms and frowning.",
                    "Sending an email."
                ],
                options_es: [
                    "Escribir una nota.",
                    "Hablar por teléfono.",
                    "Cruzar los brazos y fruncir el ceño.",
                    "Enviar un correo electrónico."
                ],
                correct: 2,
                reason_en: "Body language and facial expressions are non-verbal.",
                reason_es: "El lenguaje corporal y las expresiones faciales son no verbales."
            },
            {
                text_en: "The medical term for 'Difficulty Swallowing' is:",
                text_es: "El término médico para 'Dificultad para Tragar' es:",
                options_en: ["Dyspnea", "Dysphasia", "Dysphagia", "Dysuria"],
                options_es: ["Disnea", "Disfasia", "Disfagia", "Disuria"],
                correct: 2,
                reason_en: "Dysphagia (with a 'g' for gastro/gullet). Dysphasia is speech.",
                reason_es: "Disfagia (con 'g' de garganta). La disfasia es del habla."
            },
            {
                text_en: "A resident is complaining of a 'burning' sensation when urinating. This is a sign of:",
                text_es: "Un residente se queja de una sensación de 'ardor' al orinar. Esto es un signo de:",
                options_en: ["Diabetes", "Urinary Tract Infection", "Renal Failure", "Dehydration"],
                options_es: ["Diabetes", "Infección del Tracto Urinario", "Insuficiencia Renal", "Deshidratación"],
                correct: 1,
                reason_en: "Dysuria is a classic sign of a UTI.",
                reason_es: "La disuria es un signo clásico de una infección urinaria."
            },
            {
                text_en: "How should a CNA handle soiled linen?",
                text_es: "¿Cómo debe manejar un CNA la ropa de cama sucia?",
                options_en: [
                    "Shake it out to remove crumbs.",
                    "Carry it close to the body to prevent dropping.",
                    "Place it in a leak-proof bag without touching the floor.",
                    "Put it on the floor until you have a full load."
                ],
                options_es: [
                    "Sacudirla para quitar las migajas.",
                    "Llevarla pegada al cuerpo para evitar que se caiga.",
                    "Colocarla en una bolsa a prueba de fugas sin tocar el suelo.",
                    "Ponerla en el suelo hasta que tenga una carga completa."
                ],
                correct: 2,
                reason_en: "Biohazard safety requires bagging and avoiding cross-contamination.",
                reason_es: "La seguridad frente a riesgos biológicos requiere embolsar y evitar la contaminación cruzada."
            },
            {
                text_en: "Which of the following is a cognitive change associated with aging?",
                text_es: "¿Cuál de los siguientes es un cambio cognitivo asociado con el envejecimiento?",
                options_en: [
                    "Slower reaction time.",
                    "Complete loss of memory.",
                    "Inability to learn new things.",
                    "Vision loss."
                ],
                options_es: [
                    "Tiempo de reacción más lento.",
                    "Pérdida total de la memoria.",
                    "Incapacidad para aprender cosas nuevas.",
                    "Pérdida de visión."
                ],
                correct: 0,
                reason_en: "Reaction time naturally slows, but significant memory loss is not normal aging.",
                reason_es: "El tiempo de reacción se ralentiza naturalmente, pero la pérdida significativa de memoria no es un envejecimiento normal."
            },
            {
                text_en: "A resident is in the 'Sun-Downing' phase of dementia. This means they:",
                text_es: "Un residente está en la fase de 'Sundowning' (agitación vespertina) de la demencia. Esto significa que:",
                options_en: [
                    "Become more alert in the morning.",
                    "Become more confused and agitated in the late afternoon/evening.",
                    "Only eat during the daytime.",
                    "Sleep all day."
                ],
                options_es: [
                    "Están más alerta por la mañana.",
                    "Se vuelven más confundidos y agitados al final de la tarde o noche.",
                    "Solo comen durante el día.",
                    "Duermen todo el día."
                ],
                correct: 1,
                reason_en: "Sundowning is increased confusion as daylight fades.",
                reason_es: "El sundowning es el aumento de la confusión a medida que se desvanece la luz del día."
            },
            {
                text_en: "What is the FIRST sign of dehidration in an elderly resident?",
                text_es: "¿Cuál es el PRIMER signo de deshidratación en un residente anciano?",
                options_en: [
                    "Confusion and dark urine.",
                    "Excessive sweating.",
                    "High blood pressure.",
                    "Weight gain."
                ],
                options_es: [
                    "Confusión y orina oscura.",
                    "Sudoración excesiva.",
                    "Presión arterial alta.",
                    "Aumento de peso."
                ],
                correct: 0,
                reason_en: "Confusion and concentrated urine are early indicators in seniors.",
                reason_es: "La confusión y la orina concentrada son indicadores tempranos en los adultos mayores."
            },
            {
                text_en: "A resident with heart failure is on a 1500mL fluid restriction. The tray contains a 4oz juice, 6oz coffee, and 4oz of jello. How many mL did the resident consume if they finished everything?",
                text_es: "Un residente con insuficiencia cardíaca tiene una restricción de líquidos de 1500 ml. La bandeja contiene un jugo de 4 oz, un café de 6 oz y 4 oz de gelatina. ¿Cuántos ml consumió el residente si terminó todo?",
                options_en: ["320 mL", "420 mL", "480 mL", "540 mL"],
                options_es: ["320 ml", "420 ml", "480 ml", "540 ml"],
                correct: 1,
                reason_en: "1 oz = 30 mL. (4+6+4) * 30 = 14 * 30 = 420 mL. Jello counts as fluid.",
                reason_es: "1 oz = 30 ml. (4+6+4) * 30 = 14 * 30 = 420 ml. La gelatina cuenta como líquido."
            },
            {
                text_en: "A CNA is performing ROM on a resident's shoulder. The resident complains of pain. What should the CNA do?",
                text_es: "Un CNA está realizando ROM en el hombro de un residente. El residente se queja de punto de dolor. ¿Qué debe hacer el CNA?",
                options_en: [
                    "Push past the pain to increase flexibility.",
                    "Stop the exercise and notify the nurse.",
                    "Tell the resident 'no pain, no gain'.",
                    "Apply a hot pack and continue."
                ],
                options_es: [
                    "Presionar más allá del dolor para aumentar la flexibilidad.",
                    "Detener el ejercicio e informar a la enfermera.",
                    "Decirle al residente 'sin dolor no hay ganancia'.",
                    "Aplicar una compresa caliente y continuar."
                ],
                correct: 1,
                reason_en: "Never force a joint beyond the point of pain or resistance.",
                reason_es: "Nunca fuerce una articulación más allá del punto de dolor o resistencia."
            },
            {
                text_en: "When recording intake and output (I&O), what is the correct unit of measurement?",
                text_es: "Al registrar la ingesta y la eliminación (I&O), ¿cuál es la unidad de medida correcta?",
                options_en: ["Ounces (oz)", "Milliliters (mL)", "Cups", "Liters (L)"],
                options_es: ["Onzas (oz)", "Mililitros (ml)", "Tazas", "Litros (L)"],
                correct: 1,
                reason_en: "I&O is always documented in milliliters (mL).",
                reason_es: "La I&O siempre se documenta en mililitros (ml)."
            },
            {
                text_en: "A resident has a diagnosis of COPD and is on 2L of oxygen. They ask the CNA to turn it up to 5L because they feel short of breath. What should the CNA do?",
                text_es: "Un residente tiene un diagnóstico de EPOC (COPD) y usa 2L de oxígeno. Le pide al CNA que lo suba a 5L porque siente falta de aire. ¿Qué debe hacer el CNA?",
                options_en: [
                    "Turn it up as requested to help the resident.",
                    "Tell the resident they don't need that much oxygen.",
                    "Notify the nurse of the resident's request and distress.",
                    "Wait 10 minutes to see if they feel better."
                ],
                options_es: [
                    "Subirlo según lo solicitado para ayudar al residente.",
                    "Decirle al residente que no necesita tanto oxígeno.",
                    "Informar a la enfermera de la solicitud y el malestar del residente.",
                    "Esperar 10 minutos para ver si se sienten mejor."
                ],
                correct: 2,
                reason_en: "CNAs cannot adjust oxygen levels; it is a medication. Notify the nurse immediately for assessment.",
                reason_es: "Los CNA no pueden ajustar los niveles de oxígeno; se considera un medicamento. Informe a la enfermera de inmediato para su evaluación."
            },
            {
                text_en: "Which of the following is considered a subjective observation?",
                text_es: "¿Cuál de las siguientes se considera una observación subjetiva?",
                options_en: [
                    "The resident's blood pressure is 120/80.",
                    "The resident has a red rash on their arm.",
                    "The resident says, 'I feel very dizzy today'.",
                    "The resident ate 50% of their breakfast."
                ],
                options_es: [
                    "La presión arterial del residente es 120/80.",
                    "El residente tiene una erupción roja en el brazo.",
                    "El residente dice: 'Me siento muy mareado hoy'.",
                    "El residente comió el 50% de su desayuno."
                ],
                correct: 2,
                reason_en: "Subjective data is what the resident reports or feels (symptoms).",
                reason_es: "Los datos subjetivos son los que el residente informa o siente (síntomas)."
            },
            {
                text_en: "A resident is in the dying process and has 'Cheyne-Stokes' respirations. This is characterized by:",
                text_es: "Un residente está en proceso de muerte y tiene respiraciones de 'Cheyne-Stokes'. Esto se caracteriza por:",
                options_en: [
                    "Rapid, deep breathing with a fruity odor.",
                    "Slow, shallow breathing only.",
                    "Periods of rapid breathing followed by periods of apnea (no breathing).",
                    "Gurgling sounds in the throat."
                ],
                options_es: [
                    "Respiración rápida y profunda con olor a fruta.",
                    "Respiración lenta y superficial solamente.",
                    "Periodos de respiración rápida seguidos de periodos de apnea (sin respiración).",
                    "Sonidos de gorgoteo en la garganta."
                ],
                correct: 2,
                reason_en: "Cheyne-Stokes is a pattern of crescendo-decrescendo breathing with apnea, often seen at the end of life.",
                reason_es: "Cheyne-Stokes es un patrón de respiración en crescendo-decrescendo con apnea, que se ve a menudo al final de la vida."
            },
            {
                text_en: "When helping a resident who had a stroke (CVA) walk, the CNA should stand:",
                text_es: "Al ayudar a caminar a un residente que tuvo un accidente cerebrovascular (CVA), el CNA debe pararse:",
                options_en: [
                    "On the resident's stronger side.",
                    "Behind the resident.",
                    "On the resident's affected (weaker) side.",
                    "In front of the resident."
                ],
                options_es: [
                    "Del lado más fuerte del residente.",
                    "Detrás del residente.",
                    "Del lado afectado (más débil) del residente.",
                    "Frente al residente."
                ],
                correct: 2,
                reason_en: "Support the affected side to prevent falls and provide stability.",
                reason_es: "Apoye el lado afectado para evitar caídas y brindar estabilidad."
            },
            {
                text_en: "What is the primary reason for wearing gloves when providing mouth care?",
                text_es: "¿Cuál es la razón principal para usar guantes al brindar cuidado bucal?",
                options_en: [
                    "To keep the resident's teeth clean.",
                    "Standard precautions for contact with mucous membranes.",
                    "To prevent the CNA's hands from getting wet.",
                    "Because it is facility policy only."
                ],
                options_es: [
                    "Para mantener limpios los dientes del residente.",
                    "Precauciones estándar para el contacto con membranas mucosas.",
                    "Para evitar que se mojen las manos del CNA.",
                    "Porque es solo la política del centro."
                ],
                correct: 1,
                reason_en: "Mouth care involves contact with mucous membranes and saliva, requiring gloves.",
                reason_es: "El cuidado bucal implica contacto con membranas mucosas y saliva, lo que requiere el uso de guantes."
            },
            {
                text_en: "A resident has a HIPAA violation if the CNA:",
                text_es: "Un residente sufre una violación de HIPAA si el CNA:",
                options_en: [
                    "Reports a change in condition to the nurse.",
                    "Discusses the resident's medical condition with a friend at lunch.",
                    "Identifies the resident using their ID band.",
                    "Documents care in the official medical record."
                ],
                options_es: [
                    "Informa un cambio en la condición a la enfermera.",
                    "Habla sobre la condición médica del residente con un amigo en el almuerzo.",
                    "Identifica al residente usando su pulsera de identificación.",
                    "Documenta los cuidados en el registro médico oficial."
                ],
                correct: 1,
                reason_en: "HIPAA protects resident privacy. Sharing info with unauthorized persons is a violation.",
                reason_es: "HIPAA protege la privacidad del residente. Compartir información con personas no autorizadas es una violación."
            },
            {
                text_en: "When performing a 24-hour urine collection, the CNA should:",
                text_es: "Al realizar una recolección de orina de 24 horas, el CNA debe:",
                options_en: [
                    "Save the first void of the morning and start the clock.",
                    "Discard the first void and then collect all urine for the next 24 hours.",
                    "Only collect the morning and evening voids.",
                    "Keep the urine at room temperature on the counter."
                ],
                options_es: [
                    "Guardar la primera micción de la mañana y poner en marcha el reloj.",
                    "Desechar la primera micción y luego recolectar toda la orina durante las siguientes 24 horas.",
                    "Solo recolectar las micciones de la mañana y de la tarde.",
                    "Mantener la orina a temperatura ambiente sobre el mostrador."
                ],
                correct: 1,
                reason_en: "Start with an empty bladder by discarding the first void, then collect everything, usually on ice.",
                reason_es: "Comience con la vejiga vacía desechando la primera micción, luego recolecte todo, generalmente en hielo."
            },
            {
                text_en: "A resident is on a 'Bladder Retraining' program. The CNA's role is to:",
                text_es: "Un residente está en un programa de 'Reentrenamiento de la Vejiga'. El papel del CNA es:",
                options_en: [
                    "Restrict the resident's fluids entirely.",
                    "Take the resident to the bathroom at specific, scheduled times.",
                    "Insert a catheter to keep the resident dry.",
                    "Tell the resident to hold it as long as they can."
                ],
                options_es: [
                    "Restringir por completo los líquidos del residente.",
                    "Llevar al residente al baño a horas específicas y programadas.",
                    "Insertar una sonda para mantener seco al residente.",
                    "Decirle al residente que aguante lo más que pueda."
                ],
                correct: 1,
                reason_en: "Scheduled toileting helps the bladder learn to empty at regular intervals.",
                reason_es: "El uso del baño programado ayuda a la vejiga a aprender a vaciarse en intervalos regulares."
            }
        ]
    },
    {
        name: "Batería 2: Emergencias y Seguridad / Emergencies & Safety",
        questions: [
            {
                text_en: "A fire starts in a resident's wastebasket. After removing the resident, what is the NEXT step according to the RACE acronym?",
                text_es: "Se inicia un incendio en la papelera de un residente. Después de retirar al residente, ¿cuál es el SIGUIENTE paso según el acrónimo RACE?",
                options_en: ["Extinguish the fire.", "Activate the fire alarm.", "Contain the fire by closing the door.", "Run for help."],
                options_es: ["Extinguir el fuego.", "Activar la alarma de incendios.", "Contener el fuego cerrando la puerta.", "Correr a pedir ayuda."],
                correct: 1,
                reason_en: "RACE: Rescue, Activate alarm, Contain, Extinguish.",
                reason_es: "RACE: Rescatar, Activar alarma, Contener, Extinguir."
            },
            {
                text_en: "Which of the following describes a 'Sentinel Event'?",
                text_es: "¿Cuál de los siguientes describe un 'Evento Centinela'?",
                options_en: [
                    "A routine fall with no injury.",
                    "An unexpected occurrence involving death or serious physical or psychological injury.",
                    "A resident refusing their breakfast.",
                    "A minor skin tear discovered during a bath."
                ],
                options_es: [
                    "Una caída rutinaria sin lesiones.",
                    "Un suceso inesperado que involucra la muerte o una lesión física o psicológica grave.",
                    "Un residente que rechaza su desayuno.",
                    "Un pequeño desgarro en la piel descubierto durante el baño."
                ],
                correct: 1,
                reason_en: "Sentinel events are serious adverse events that require immediate investigation.",
                reason_es: "Los eventos centinela son eventos adversos graves que requieren una investigación inmediata."
            },
            {
                text_en: "The CNA finds a resident unresponsive and not breathing. What is the FIRST action?",
                text_es: "El CNA encuentra a un residente que no responde y no respira. ¿Cuál es la PRIMERA acción?",
                options_en: ["Start chest compressions.", "Call for help/Code Blue.", "Check for a pulse for at least 10 seconds.", "Give two rescue breaths."],
                options_es: ["Iniciar compresiones torácicas.", "Pedir ayuda/Código Azul.", "Comprobar el pulso durante al menos 10 segundos.", "Dar dos respiraciones de rescate."],
                correct: 1,
                reason_en: "Immediate notification of the emergency team is priority when a cardiac arrest is suspected.",
                reason_es: "La notificación inmediata al equipo de emergencia es la prioridad cuando se sospecha un paro cardíaco."
            },
            {
                text_en: "What does the abbreviation 'MSDS' (or SDS) stand for in a facility?",
                text_es: "¿Qué significan las siglas 'MSDS' (o SDS) en un centro de salud?",
                options_en: ["Medical Site Documentation System", "Material Safety Data Sheets", "Major Safety Delivery Service", "Managed System for Drug Storage"],
                options_es: ["Sistema de Documentación del Sitio Médico", "Hojas de Datos de Seguridad de Materiales", "Servicio Principal de Entrega de Seguridad", "Sistema Gestionado para el Almacenamiento de Medicamentos"],
                correct: 1,
                reason_en: "SDS provides information on hazardous chemicals and emergency procedures.",
                reason_es: "Las SDS proporcionan información sobre productos químicos peligrosos y procedimientos de emergencia."
            },
            {
                text_en: "A resident is choking and cannot speak, cough, or breathe. What action should the CNA take?",
                text_es: "Un residente se está asfixiando y no puede hablar, toser ni respirar. ¿Qué acción debe tomar el CNA?",
                options_en: ["Back blows only.", "Abdominal thrusts (Heimlich Maneuver).", "Finger sweep of the mouth.", "Wait for the resident to lose consciousness."],
                options_es: ["Solo palmadas en la espalda.", "Sujeciones abdominales (Maniobra de Heimlich).", "Barrido digital de la boca.", "Esperar a que el residente pierda el conocimiento."],
                correct: 1,
                reason_en: "Abdominal thrusts are the standard for a complete airway obstruction.",
                reason_es: "Las compresiones abdominales son el estándar para una obstrucción completa de las vías respiratorias."
            },
            {
                text_en: "Which of the following is the CORRECT way to use a fire extinguisher?",
                text_es: "¿Cuál de las siguientes es la forma CORRECTA de usar un extintor de incendios?",
                options_en: ["Aim at the top of the flames.", "Pull the pin, aim at base, squeeze handle, sweep side to side.", "Spray in a circular motion.", "Wait 5 minutes for it to warm up."],
                options_es: ["Apuntar a la parte superior de las llamas.", "Tirar del pasador, apuntar a la base, apretar la manija, barrer de lado a lado (PASS).", "Rociar en movimiento circular.", "Esperar 5 minutos a que se caliente."],
                correct: 1,
                reason_en: "PASS: Pull, Aim, Squeeze, Sweep.",
                reason_es: "PASS: Tirar (Pull), Apuntar, Apretar, Barrer."
            },
            {
                text_en: "A resident has a 'DNAR' (Do Not Attempt Resuscitation) order. If they stop breathing, the CNA should:",
                text_es: "Un residente tiene una orden de 'DNAR' (No intentar reanimación). Si deja de respirar, el CNA debe:",
                options_en: ["Start CPR immediately.", "Notify the nurse immediately and provide comfort care.", "Pretend nothing happened.", "Call 911."],
                options_es: ["Iniciar RCP de inmediato.", "Informar a la enfermera de inmediato y brindar cuidados de confort.", "Pretender que no pasó nada.", "Llamar al 911."],
                correct: 1,
                reason_en: "Respect the resident's advance directives. DNAR means no CPR.",
                reason_es: "Respete las voluntades anticipadas del residente. DNAR significa no realizar RCP."
            },
            {
                text_en: "What is the primary purpose of 'Standard Precautions'?",
                text_es: "¿Cuál es el propósito principal de las 'Precauciones Estándar'?",
                options_en: [
                    "To protect only the residents.",
                    "To prevent the spread of infection from blood and body fluids to others.",
                    "To reduce facility costs.",
                    "To identify infectious residents with signs."
                ],
                options_es: [
                    "Proteger solo a los residentes.",
                    "Prevenir la propagación de infecciones por sangre y fluidos corporales a otros.",
                    "Reducir los costes del centro.",
                    "Identificar a los residentes infecciosos con carteles."
                ],
                correct: 1,
                reason_en: "Standard precautions apply to all residents regardless of diagnosis.",
                reason_es: "Las precauciones estándar se aplican a todos los residentes, independientemente del diagnóstico."
            },
            {
                text_en: "A CNA finds a small puddle of an unknown clear liquid in the hallway. What is the BEST action?",
                text_es: "Un CNA encuentra un pequeño charco de un líquido transparente desconocido en el pasillo. ¿Cuál es la MEJOR acción?",
                options_en: [
                    "Walk around it.",
                    "Clean it up with a paper towel immediately.",
                    "Block the area and report it for proper cleanup.",
                    "Touch it to see if it's sticky."
                ],
                options_es: [
                    "Caminar alrededor.",
                    "Limpiarlo con una toalla de papel de inmediato.",
                    "Bloquear el área e informar para su limpieza adecuada.",
                    "Tocarlo para ver si es pegajoso."
                ],
                correct: 2,
                reason_en: "Safety first: prevent slips and avoid contact with potentially hazardous substances.",
                reason_es: "La seguridad es lo primero: evite resbalones y el contacto con sustancias potencialmente peligrosas."
            },
            {
                text_en: "Which of the following is a symptom of a systemic infection?",
                text_es: "¿Cuál de los siguientes es un síntoma de una infección sistémica?",
                options_en: ["Pain at the site of a cut.", "Fever, chills, and fatigue.", "A small bruise on the leg.", "A dry patch of skin."],
                options_es: ["Dolor en el sitio de un corte.", "Fiebre, escalofríos y fatiga.", "Un pequeño hematoma en la pierna.", "Un parche de piel seca."],
                correct: 1,
                reason_en: "Systemic infections affect the entire body, causing fever and general malaise.",
                reason_es: "Las infecciones sistémicas afectan a todo el cuerpo, causando fiebre y malestar general."
            },
            {
                text_en: "What is the 'Chain of Infection'?",
                text_es: "¿Qué es la 'Cadena de Infección'?",
                options_en: [
                    "A physical chain used to lock biohazard waste.",
                    "The process by which an infectious disease is transmitted from one person to another.",
                    "A list of hospitals in a network.",
                    "The classification of different bacteria."
                ],
                options_es: [
                    "Una cadena física utilizada para cerrar residuos de riesgo biológico.",
                    "El proceso por el cual una enfermedad infecciosa se transmite de una persona a otra.",
                    "Una lista de hospitales en una red.",
                    "La clasificación de las diferentes bacterias."
                ],
                correct: 1,
                reason_en: "Understanding the chain helps in breaking it to prevent outbreaks.",
                reason_es: "Comprender la cadena ayuda a romperla para prevenir brotes."
            },
            {
                text_en: "The CNA is using a mechanical lift to transfer a resident. How many staff members are REQUIRED?",
                text_es: "El CNA está usando un elevador mecánico para trasladar a un residente. ¿Cuántos miembros del personal son REQUERIDOS?",
                options_en: ["One", "At least two", "Three", "Four"],
                options_es: ["Uno", "Al menos dos", "Tres", "Cuatro"],
                correct: 1,
                reason_en: "Mechanical lifts always require at least two trained staff members for safety.",
                reason_es: "Los elevadores mecánicos siempre requieren al menos dos miembros del personal capacitados por seguridad."
            },
            {
                text_en: "A resident has a weak left side. When transferring them to a chair, where should the chair be placed?",
                text_es: "Un residente tiene el lado izquierdo débil. Al trasladarlo a una silla, ¿dónde debe colocarse la silla?",
                options_en: ["On the left side.", "On the right side.", "Directly in front of the bed.", "Behind the resident."],
                options_es: ["En el lado izquierdo.", "En el lado derecho.", "Directamente frente a la cama.", "Detrás del residente."],
                correct: 1,
                reason_en: "Transfer toward the strong side (Right).",
                reason_es: "Traslado hacia el lado fuerte (derecho)."
            },
            {
                text_en: "Which of the following is the MOST common cause of falls in the elderly?",
                text_es: "¿Cuál de las siguientes es la causa MÁS común de caídas en los ancianos?",
                options_en: ["Eating too much.", "Poor lighting and cluttered floors.", "Sleeping during the day.", "Watching too much TV."],
                options_es: ["Comer demasiado.", "Iluminación deficiente y suelos desordenados.", "Dormir durante el día.", "Ver demasiada televisión."],
                correct: 1,
                reason_en: "Environmental hazards are leading causes of preventable falls.",
                reason_es: "Los riesgos ambientales son las principales causas de caídas prevenibles."
            },
            {
                text_en: "What should a CNA do if an electrical cord is frayed?",
                text_es: "¿Qué debe hacer un CNA si un cable eléctrico está deshilachado?",
                options_en: [
                    "Use it anyway if it still works.",
                    "Wrap it in duct tape.",
                    "Remove it from service and report it immediately.",
                    "Wait until it sparks to report it."
                ],
                options_es: [
                    "Usarlo de todos modos si todavía funciona.",
                    "Envolverlo con cinta adhesiva.",
                    "Retirarlo del servicio e informarlo de inmediato.",
                    "Esperar a que chispee para informarlo."
                ],
                correct: 2,
                reason_en: "Preventative safety: damaged equipment is a fire and shock hazard.",
                reason_es: "Seguridad preventiva: el equipo dañado es un riesgo de incendio y descarga eléctrica."
            },
            {
                text_en: "When washing hands, how long should the CNA scrub with soap?",
                text_es: "Al lavarse las manos, ¿cuánto tiempo debe el CNA frotarse con jabón?",
                options_en: ["5 seconds", "At least 20 seconds", "60 seconds", "No scrubbing is needed."],
                options_es: ["5 segundos", "Al menos 20 segundos", "60 segundos", "No es necesario frotar."],
                correct: 1,
                reason_en: "Friction for at least 20 seconds is required to remove microorganisms.",
                reason_es: "Se requiere fricción durante al menos 20 segundos para eliminar los microorganismos."
            },
            {
                text_en: "Which type of transmission-based precaution requires an N95 respirator?",
                text_es: "¿Qué tipo de precaución basada en la transmisión requiere un respirador N95?",
                options_en: ["Contact Precautions", "Droplet Precautions", "Airborne Precautions", "Standard Precautions"],
                options_es: ["Precauciones de contacto", "Precauciones por gotas", "Precauciones por vía aérea", "Precauciones estándar"],
                correct: 2,
                reason_en: "Airborne particles are small and require special filtration.",
                reason_es: "Las partículas transportadas por el aire son pequeñas y requieren una filtración especial."
            },
            {
                text_en: "A resident is having an allergic reaction and starts to swell around the face. This is called:",
                text_es: "Un residente tiene una reacción alérgica y comienza a hincharse alrededor de la cara. Esto se llama:",
                options_en: ["Hyperglycemia", "Angioedema", "Aphasia", "Dysphagia"],
                options_es: ["Hiperglucemia", "Angioedema", "Afasia", "Disfagia"],
                correct: 1,
                reason_en: "Angioedema is rapid swelling of deeper skin layers, often associated with allergies.",
                reason_es: "El angioedema es la hinchazón rápida de las capas más profundas de la piel, a menudo asociada con alergias."
            },
            {
                text_en: "What should the CNA do if they stick themselves with a used needle?",
                text_es: "¿Qué debe hacer el CNA si se pincha con una aguja usada?",
                options_en: [
                    "Wash the area and report it immediately to the supervisor.",
                    "Squeeze the site to get all the blood out.",
                    "Wait 24 hours to see if a rash develops.",
                    "Put a Band-Aid on and finish the shift."
                ],
                options_es: [
                    "Lavar el área e informar de inmediato al supervisor.",
                    "Apretar el sitio para sacar toda la sangre.",
                    "Esperar 24 horas para ver si aparece una erupción.",
                    "Ponerse una tirita y terminar el turno."
                ],
                correct: 0,
                reason_en: "Immediate action and reporting are vital for post-exposure prophylaxis.",
                reason_es: "La acción inmediata y el informe son vitales para la profilaxis posterior a la exposición."
            },
            {
                text_en: "Which of the following is the FIRST step in preventing pressure ulcers?",
                text_es: "¿Cuál de los siguientes es el PRIMER paso para prevenir las úlceras por presión?",
                options_en: [
                    "Applying heavy lotion all over the body.",
                    "Keeping the skin clean and dry and repositioning every 2 hours.",
                    "Massaging reddened areas.",
                    "Letting the resident stay in one position for 6 hours."
                ],
                options_es: [
                    "Aplicar mucha loción por todo el cuerpo.",
                    "Mantener la piel limpia y seca y reposicionar cada 2 horas.",
                    "Masajear las zonas enrojecidas.",
                    "Dejar que el residente permanezca en una posición durante 6 horas."
                ],
                correct: 1,
                reason_en: "Turning, positioning, and skin integrity are primary.",
                reason_es: "El giro, la posición y la integridad de la piel son primordiales."
            },
            {
                text_en: "A resident is having a heart attack (Myocardial Infarction). Besides chest pain, what is a common symptom in women?",
                text_es: "Un residente está sufriendo un infarto (Infarto de Miocardio). Además del dolor en el pecho, ¿cuál es un síntoma común en las mujeres?",
                options_en: ["Sudden hunger.", "Jaw pain, nausea, and extreme fatigue.", "Increased hearing ability.", "Sweating only on the hands."],
                options_es: ["Hambre repentina.", "Dolor de mandíbula, náuseas y fatiga extrema.", "Aumento de la capacidad auditiva.", "Sudoración solo en las manos."],
                correct: 1,
                reason_en: "Women often present with atypical MI symptoms like jaw pain and fatigue.",
                reason_es: "Las mujeres suelen presentar síntomas atípicos de IM, como dolor de mandíbula y fatiga."
            },
            {
                text_en: "When performing chest compressions on an adult during CPR, how deep should they be?",
                text_es: "Al realizar compresiones torácicas en un adulto durante la RCP, ¿qué profundidad deben tener?",
                options_en: ["1 inch", "At least 2 inches", "4 inches", "Just enough to see the skin move."],
                options_es: ["1 pulgada", "Al menos 2 pulgadas", "4 pulgadas", "Lo justo para ver que la piel se mueve."],
                correct: 1,
                reason_en: "Effective compressions must be at least 2 inches deep for adults.",
                reason_es: "Las compresiones efectivas deben tener al menos 2 pulgadas de profundidad para adultos."
            },
            {
                text_en: "What should the CNA do if they suspect a resident is being abused by another staff member?",
                text_es: "¿Qué debe hacer el CNA si sospecha que un residente está siendo abusado por otro miembro del personal?",
                options_en: [
                    "Talk to the staff member first.",
                    "Wait for proof before saying anything.",
                    "Report the suspicion immediately to the supervisor or manager.",
                    "Tell the resident's family."
                ],
                options_es: [
                    "Hablar primero con el miembro del personal.",
                    "Esperar a tener pruebas antes de decir nada.",
                    "Informar de la sospecha de inmediato al supervisor o gerente.",
                    "Decírselo a la familia del residente."
                ],
                correct: 2,
                reason_en: "CNAs are mandated reporters. Suspected abuse must be reported immediately.",
                reason_es: "Los CNA son informantes obligatorios. Las sospechas de abuso deben informarse de inmediato."
            },
            {
                text_en: "A resident's skin is pale, cold, and they are breathing rapidly. What could this indicate?",
                text_es: "La piel de un residente está pálida, fría y respira rápidamente. ¿Qué podría indicar esto?",
                options_en: ["Normal aging.", "Hypovolemic Shock.", "A good night's sleep.", "Hyperactivity."],
                options_es: ["Envejecimiento normal.", "Choque hipovolémico.", "Una buena noche de sueño.", "Hiperactividad."],
                correct: 1,
                reason_en: "Signs of shock include pale/cool skin, rapid pulse, and rapid breathing.",
                reason_es: "Los signos de shock incluyen piel pálida/fría, pulso rápido y respiración rápida."
            },
            {
                text_en: "What is the correct order for removing PPE (Doffing)?",
                text_es: "¿Cuál es el orden correcto para quitarse el EPP (Doffing)?",
                options_en: [
                    "Gown, gloves, mask.",
                    "Gloves, gown, mask/shield.",
                    "Mask, gown, gloves.",
                    "Gown, mask, gloves."
                ],
                options_es: [
                    "Bata, guantes, mascarilla.",
                    "Guantes, bata, mascarilla/protector.",
                    "Mascarilla, bata, guantes.",
                    "Bata, mascarilla, guantes."
                ],
                correct: 1,
                reason_en: "Gloves are usually removed first as they are the most contaminated.",
                reason_es: "Los guantes suelen quitarse primero, ya que son lo más contaminado."
            },
            {
                text_en: "Which of the following is a sign of a possible stroke (FAST)?",
                text_es: "¿Cuál de los siguientes es un signo de un posible accidente cerebrovascular (FAST)?",
                options_en: [
                    "Frequent Asking, Slow Talking.",
                    "Face drooping, Arm weakness, Speech difficulty, Time to call 911.",
                    "Fast Acting, Smart Thinking.",
                    "Falling, Aching, Sleeping, Tired."
                ],
                options_es: [
                    "Preguntas frecuentes, habla lenta.",
                    "Caída de la cara, debilidad en los brazos, dificultad para hablar, tiempo de llamar al 911 (FAST).",
                    "Acción rápida, pensamiento inteligente.",
                    "Caída, dolor, sueño, cansancio."
                ],
                correct: 1,
                reason_en: "FAST is a widely used acronym for recognizing stroke symptoms.",
                reason_es: "FAST es un acrónimo ampliamente utilizado para reconocer los síntomas del accidente cerebrovascular."
            },
            {
                text_en: "An elderly resident with a catheter has new confusion. What should be suspected?",
                text_es: "Un residente anciano con una sonda tiene una nueva confusión. ¿Qué se debe sospechar?",
                options_en: ["Alzheimer's.", "Urinary Tract Infection (UTI).", "Normal mood swings.", "Better hearing."],
                options_es: ["Alzheimer.", "Infección del Tracto Urinario (ITU).", "Cambios de humor normales.", "Mejor audición."],
                correct: 1,
                reason_en: "UTIs in the elderly often present with mental status changes rather than fever/burning.",
                reason_es: "Las infecciones urinarias en los ancianos a menudo se presentan con cambios en el estado mental en lugar de fiebre o ardor."
            },
            {
                text_en: "What is the proper way to lift a heavy object?",
                text_es: "¿Cuál es la forma correcta de levantar un objeto pesado?",
                options_en: [
                    "Bend at the waist with straight legs.",
                    "Keep feet together and pull.",
                    "Bent knees, straight back, object close to body.",
                    "Twist the body while lifting."
                ],
                options_es: [
                    "Doblar la cintura con las piernas rectas.",
                    "Mantener los pies juntos y tirar.",
                    "Rodillas dobladas, espalda recta, objeto cerca del cuerpo.",
                    "Girar el cuerpo mientras se levanta."
                ],
                correct: 2,
                reason_en: "Proper body mechanics protect the back from injury.",
                reason_es: "La mecánica corporal adecuada protege la espalda de lesiones."
            },
            {
                text_en: "When using a 'Gait Belt', where should the buckle be positioned?",
                text_es: "Al usar un 'Cinturón de Marcha' (Gait Belt), ¿dónde debe colocarse la hebilla?",
                options_en: ["Directly over the resident's spine.", "Off-center, usually toward the side.", "On the resident's chest.", "Inside the resident's clothing."],
                options_es: ["Directamente sobre la columna vertebral del residente.", "Descentrado, generalmente hacia un lado.", "En el pecho del residente.", "Por dentro de la ropa del residente."],
                correct: 1,
                reason_en: "Avoid the spine or sensitive areas for the resident's comfort.",
                reason_es: "Evite la columna vertebral o las áreas sensibles para la comodidad del residente."
            },
            {
                text_en: "A resident has a 'Full Liquid' diet. Which of the following is allowed?",
                text_es: "Un residente tiene una dieta de 'Líquidos Completos'. ¿Cuál de los siguientes está permitido?",
                options_en: ["Oatmeal.", "Vanilla milkshake and cream soup.", "Steak.", "Whole wheat bread."],
                options_es: ["Avena.", "Batido de vainilla y crema de sopa.", "Bistec.", "Pan de trigo integral."],
                correct: 1,
                reason_en: "Full liquid includes everything in clear liquid plus dairy and cream-based items.",
                reason_es: "Líquidos completos incluye todo lo de líquidos claros más productos lácteos y a base de crema."
            },
            {
                text_en: "How should the CNA help a resident use a walker?",
                text_es: "¿Cómo debe el CNA ayudar a un residente a usar un andador?",
                options_en: [
                    "Pick up the walker for the resident.",
                    "The resident moves the walker, steps with the weak leg, then the strong leg.",
                    "The resident moves both legs first, then the walker.",
                    "The CNA pushes the walker from behind."
                ],
                options_es: [
                    "Recoger el andador para el residente.",
                    "El residente mueve el andador, da un paso con la pierna débil y luego con la fuerte.",
                    "El residente mueve primero ambas piernas y luego el andador.",
                    "El CNA empuja el andador por detrás."
                ],
                correct: 1,
                reason_en: "Proper walker sequence supports safety and stability.",
                reason_es: "La secuencia adecuada del andador favorece la seguridad y la estabilidad."
            },
            {
                text_en: "What is the FIRST sign of a localized infection?",
                text_es: "¿Cuál es el PRIMER signo de una infección localizada?",
                options_en: ["Fever.", "Pain, redness, and swelling.", "Coma.", "Weight loss."],
                options_es: ["Fiebre.", "Dolor, enrojecimiento e hinchazón.", "Coma.", "Pérdida de peso."],
                correct: 1,
                reason_en: "Local signs are confined to the area of entry/injury.",
                reason_es: "Los signos locales se limitan al área de entrada o lesión."
            },
            {
                text_en: "A resident has a seizure. What should the CNA record FIRST?",
                text_es: "Un residente tiene una convulsión. ¿Qué debe registrar el CNA PRIMERO?",
                options_en: ["The time it started and how long it lasted.", "What the resident ate for lunch.", "The resident's blood pressure prior to the event.", "If the resident was wearing shoes."],
                options_es: ["La hora a la que empezó y cuánto duró.", "Lo que el residente comió para el almuerzo.", "La presión arterial del residente antes del evento.", "Si el residente llevaba zapatos."],
                correct: 0,
                reason_en: "Timing is critical for medical assessment of seizure activity.",
                reason_es: "El tiempo es fundamental para la evaluación médica de la actividad convulsiva."
            },
            {
                text_en: "Which of the following is a barrier to communication?",
                text_es: "¿Cuál de los siguientes es una barrera para la comunicación?",
                options_en: ["Using open-ended questions.", "Speaking loudly and in slang.", "Making eye contact.", "Active listening."],
                options_es: ["Usar preguntas abiertas.", "Hablar en voz alta y en jerga.", "Hacer contacto visual.", "Escucha activa."],
                correct: 1,
                reason_en: "Slang and shouting can confuse or intimidate residents.",
                reason_es: "La jerga y los gritos pueden confundir o intimidar a los residentes."
            },
            {
                text_en: "A resident with diabetes has fruity-smelling breath. This could be a sign of:",
                text_es: "Un residente con diabetes tiene un aliento con olor a fruta. Esto podría ser un signo de:",
                options_en: ["Good oral hygiene.", "Hypoglycemia.", "Hyperglycemia (Diabetic Ketoacidosis).", "Normal blood sugar."],
                options_es: ["Buena higiene bucal.", "Hipoglucemia.", "Hiperglucemia (Cetoacidosis diabética).", "Azúcar en sangre normal."],
                correct: 2,
                reason_en: "Fruity breath is a result of ketones being released in severe high blood sugar.",
                reason_es: "El aliento afrutado es el resultado de la liberación de cetonas en niveles severos de azúcar en sangre."
            },
            {
                text_en: "When is it appropriate to use a 'Sharps Container'?",
                text_es: "¿Cuándo es apropiado usar un 'Contenedor de Punzantes' (Sharps Container)?",
                options_en: [
                    "For used paper towels.",
                    "For needles, razors, and broken glass.",
                    "For leftover resident medication.",
                    "For soiled dignity briefs."
                ],
                options_es: [
                    "Para toallas de papel usadas.",
                    "Para agujas, cuchillas de afeitar y cristales rotos.",
                    "Para los restos de la medicación del residente.",
                    "Para pañales de dignidad sucios."
                ],
                correct: 1,
                reason_en: "Sharps containers are for everything that can puncture the skin.",
                reason_es: "Los contenedores para objetos punzantes son para todo lo que pueda perforar la piel."
            },
            {
                text_en: "A resident is on 'Contact Precautions'. What PPE must the CNA wear?",
                text_es: "Un residente tiene 'Precauciones de Contacto'. ¿Qué EPP debe usar el CNA?",
                options_en: ["Mask only.", "Gloves and gown.", "N95 respirator.", "No PPE is needed unless they cough."],
                options_es: ["Solo mascarilla.", "Guantes y bata.", "Respirador N95.", "No se necesita EPP a menos que tosan."],
                correct: 1,
                reason_en: "Contact precautions prevent spread through direct or indirect touch.",
                reason_es: "Las precauciones de contacto previenen la propagación a través del tacto directo o indirecto."
            },
            {
                text_en: "What should the CNA do if a resident falls during a transfer?",
                text_es: "¿Qué debe hacer el CNA si un residente se cae durante un traslado?",
                options_en: [
                    "Try to catch them and hold them up.",
                    "Widen their stance and ease the resident to the floor.",
                    "Run grab a wheelchair.",
                    "Ask the resident to get up quickly."
                ],
                options_es: [
                    "Intentar atraparlos y mantenerlos de pie.",
                    "Ampliar su base de apoyo y acompañar al residente al suelo suavemente.",
                    "Correr a buscar una silla de ruedas.",
                    "Pedir al residente que se levante rápido."
                ],
                correct: 1,
                reason_en: "Prevent injury to both staff and resident by controlling the descent.",
                reason_es: "Evite lesiones tanto al personal como al residente controlando el descenso."
            },
            {
                text_en: "How often should a resident in a wheelchair be repositioned?",
                text_es: "¿Con qué frecuencia se debe reposicionar a un residente en silla de ruedas?",
                options_en: ["Every 2 hours.", "Every hour.", "Once per shift.", "At least every 15 minutes (weight shifts)."],
                options_es: ["Cada 2 horas.", "Cada hora.", "Una vez por turno.", "Al menos cada 15 minutos (cambios de peso)."],
                correct: 3,
                reason_en: "Residents in chairs need more frequent weight shifts due to high pressure on the sacrum.",
                reason_es: "Los residentes en sillas necesitan cambios de peso más frecuentes debido a la alta presión en el sacro."
            },
            {
                text_en: "A resident has a 'Restraint' order. How often must the resident be monitored for safety?",
                text_es: "Un residente tiene una orden de 'Restricción'. ¿Con qué frecuencia se debe vigilar al residente por seguridad?",
                options_en: ["Every hour.", "At least every 15 minutes.", "Every 2 hours.", "Once per shift."],
                options_es: ["Cada hora.", "Al menos cada 15 minutos.", "Cada 2 horas.", "Una vez por turno."],
                correct: 1,
                reason_en: "Restricted residents require intense monitoring for circulation and distress.",
                reason_es: "Los residentes con restricciones requieren una vigilancia intensa de la circulación y el malestar."
            },
            {
                text_en: "What should the CNA do if a resident is having a major hemorrhage (bleeding)?",
                text_es: "¿Qué debe hacer el CNA si un residente tiene una hemorragia (sangrado) importante?",
                options_en: [
                    "Apply direct pressure to the wound with a clean cloth.",
                    "Give the resident a drink of water.",
                    "Lower the limb below the level of the heart.",
                    "Wait for the bleeding to stop on its own."
                ],
                options_es: [
                    "Aplicar presión directa sobre la herida con un paño limpio.",
                    "Darle al residente un trago de agua.",
                    "Bajar la extremidad por debajo del nivel del corazón.",
                    "Esperar a que el sangrado se detenga por sí solo."
                ],
                correct: 0,
                reason_en: "Direct pressure is the initial action to control hemorrhage.",
                reason_es: "La presión directa es la acción inicial para controlar una hemorragia."
            },
            {
                text_en: "Which of the following is a sign of 'Burnout' in a CNA?",
                text_es: "¿Cuál de los siguientes es un signo de 'Burnout' (agotamiento) en un CNA?",
                options_en: [
                    "Feeling energetic at the start of a shift.",
                    "Chronic fatigue, irritability, and lack of motivation.",
                    "Enjoying resident interactions.",
                    "Coming to work on time."
                ],
                options_es: [
                    "Sentirse con energía al comienzo de un turno.",
                    "Fatiga crónica, irritabilidad y falta de motivación.",
                    "Disfrutar de las interacciones con los residentes.",
                    "Llegar al trabajo a tiempo."
                ],
                correct: 1,
                reason_en: "Burnout affects both the quality of care and the CNA's health.",
                reason_es: "El agotamiento afecta tanto a la calidad de los cuidados como a la salud del CNA."
            },
            {
                text_en: "When performing CPR, what is the correct compression rate per minute?",
                text_es: "Al realizar la RCP, ¿cuál es la frecuencia de compresión correcta por minuto?",
                options_en: ["60-80 compressions.", "80-100 compressions.", "100-120 compressions.", "Over 150 compressions."],
                options_es: ["60-80 compresiones.", "80-100 compresiones.", "100-120 compresiones.", "Más de 150 compresiones."],
                correct: 2,
                reason_en: "The standard CPR compression rate is 100 to 120 per minute.",
                reason_es: "La frecuencia de compresión estándar en RCP es de 100 a 120 por minuto."
            },
            {
                text_en: "A resident has a visual impairment. How should the CNA describe their meal tray?",
                text_es: "Un residente tiene una discapacidad visual. ¿Cómo debe describir el CNA su bandeja de comida?",
                options_en: [
                    "Using the positions of a clock (e.g., 'Meat at 6 o'clock').",
                    "By pointing at the items.",
                    "By telling the resident to 'just feel around'.",
                    "Description is not necessary."
                ],
                options_es: [
                    "Usando las posiciones de un reloj (por ejemplo, 'Carne a las 6 en punto').",
                    "Señalando los elementos.",
                    "Diciéndole al residente que 'simplemente palpe'.",
                    "La descripción no es necesaria."
                ],
                correct: 0,
                reason_en: "The clock method is the standard for orienting visually impaired residents.",
                reason_es: "El método del reloj es el estándar para orientar a los residentes con discapacidad visual."
            },
            {
                text_en: "What should the CNA do FIRST if a resident is having a severe allergic reaction (Anaphylaxis)?",
                text_es: "¿Qué debe hacer el CNA PRIMERO si un residente está teniendo una reacción alérgica grave (anafilaxia)?",
                options_en: [
                    "Give an antihistamine.",
                    "Notify the nurse and call for emergency help.",
                    "Apply a cold cloth to the resident's face.",
                    "Wait for the resident to catch their breath."
                ],
                options_es: [
                    "Dar un antihistamínico.",
                    "Informar a la enfermera y pedir ayuda de emergencia.",
                    "Aplicar un paño frío en la cara del residente.",
                    "Esperar a que el residente recupere el aliento."
                ],
                correct: 1,
                reason_en: "Anaphylaxis is life-threatening and requires immediate medical intervention.",
                reason_es: "La anafilaxia pone en peligro la vida y requiere una intervención médica inmediata."
            },
            {
                text_en: "Which of the following is an example of an 'Objective' observation?",
                text_es: "¿Cuál de los siguientes es un ejemplo de una observación 'Objetiva'?",
                options_en: [
                    "The resident says they are in pain.",
                    "The resident's temperature is 101.4 F.",
                    "The resident feels sad.",
                    "The resident says they have a headache."
                ],
                options_es: [
                    "El residente dice que tiene dolor.",
                    "La temperatura del residente es de 101.4 F.",
                    "El residente se siente triste.",
                    "El residente dice que tiene dolor de cabeza."
                ],
                correct: 1,
                reason_en: "Objective data can be measured or observed through the senses (Signs).",
                reason_es: "Los datos objetivos se pueden medir u observar a través de los sentidos (Signos)."
            },
            {
                text_en: "How should the CNA handle a resident who is wandering?",
                text_es: "¿Cómo debe manejar el CNA a un residente que deambula?",
                options_en: [
                    "Lock them in their room.",
                    "Accompany the resident and gently guide them back to a safe area.",
                    "Tell the resident to stop walking immediately.",
                    "Use a vest restraint."
                ],
                options_es: [
                    "Encerrarlos en su habitación.",
                    "Acompañar al residente y guiarlo suavemente de vuelta a un área segura.",
                    "Decirle al residente que deje de caminar de inmediato.",
                    "Usar un chaleco de restricción."
                ],
                correct: 1,
                reason_en: "Safety and dignity are priority. Supervision prevents injury.",
                reason_es: "La seguridad y la dignidad son prioridades. La supervisión evita lesiones."
            },
            {
                text_en: "Which of the following is a sign of physical abuse?",
                text_es: "¿Cuál de los siguientes es un signo de abuso físico?",
                options_en: ["Bilateral bruises or bruises in various stages of healing.", "The resident being tired in the morning.", "A single small scratch from a fingernail.", "A resident reporting they are happy."],
                options_es: ["Hematomas bilaterales o hematomas en varias etapas de curación.", "Que el residente esté cansado por la mañana.", "Un único rasguño pequeño de una uña.", "Un residente que informa que está feliz."],
                correct: 0,
                reason_en: "Unexplained or bilateral bruising is a major red flag for abuse.",
                reason_es: "Los hematomas inexplicables o bilaterales son una señal de alerta importante de abuso."
            },
            {
                text_en: "What is the proper way to dispose of a used razor?",
                text_es: "¿Cuál es la forma correcta de desechar una maquinilla de afeitar usada?",
                options_en: ["In the regular trash.", "In the laundry bin.", "In a sharps container.", "Rinse it and place it in the resident's drawer."],
                options_es: ["En la basura normal.", "En el cesto de la ropa sucia.", "En un contenedor para objetos punzantes.", "Enjuagarla y colocarla en el cajón del residente."],
                correct: 2,
                reason_en: "Razors are sharps and must be disposed of in designated containers.",
                reason_es: "Las maquinillas de afeitar son objetos punzantes y deben desecharse en los contenedores designados."
            },
            {
                text_en: "A resident's family member is angry and shouting at the CNA. The CNA should:",
                text_es: "Un familiar de un residente está enojado y le grita al CNA. El CNA debe:",
                options_en: [
                    "Shout back.",
                    "Listen calmly, remain professional, and notify the supervisor.",
                    "Ignore them and walk away.",
                    "Argue with the family member."
                ],
                options_es: [
                    "Gritar de vuelta.",
                    "Escuchar con calma, mantener el profesionalismo e informar al supervisor.",
                    "Ignorarlos e irse.",
                    "Discutir con el familiar."
                ],
                correct: 1,
                reason_en: "Professionalism and de-escalation are required in all interactions.",
                reason_es: "Se requiere profesionalismo y desescalada en todas las interacciones."
            },
            {
                text_en: "What should the CNA do if a resident is coughing and having difficulty breathing after a meal?",
                text_es: "¿Qué debe hacer el CNA si un residente tosiera y tiene dificultad para respirar después de una comida?",
                options_en: [
                    "Give the resident a drink of water.",
                    "Position the resident upright and notify the nurse immediately.",
                    "Lay the resident flat to rest.",
                    "Ask the resident to wait 30 minutes."
                ],
                options_es: [
                    "Darle al residente un trago de agua.",
                    "Colocar al residente en posición vertical e informar a la enfermera de inmediato.",
                    "Acostar al residente para que descanse.",
                    "Pedir al residente que espere 30 minutos."
                ],
                correct: 1,
                reason_en: "Signs of aspiration require immediate assessment and upright positioning.",
                reason_es: "Los signos de aspiración requieren una evaluación inmediata y un posicionamiento erguido."
            },
            {
                text_en: "Which of the following is a symptom of infection in a resident with a catheter?",
                text_es: "¿Cuál de los siguientes es un síntoma de infección en un residente con una sonda?",
                options_en: ["Foul-smelling or cloudy urine.", "Clear, light yellow urine.", "Large amount of urine output.", "Transparent urine bag."],
                options_es: ["Orina turbia o con mal olor.", "Orina de color amarillo claro y transparente.", "Gran cantidad de orina eliminada.", "Bolsa de orina transparente."],
                correct: 0,
                reason_en: "Cloudy or malodorous urine is a classic sign of UTI.",
                reason_es: "La orina turbia o con mal olor es un signo clásico de infección urinaria."
            },
            {
                text_en: "When using a 'Slide Board' for a transfer, where should it be placed?",
                text_es: "Al usar una 'Tabla de Deslizamiento' (Slide Board) para un traslado, ¿dónde debe colocarse?",
                options_en: [
                    "Under the resident's head.",
                    "Bridging the space between the bed and the chair.",
                    "On the floor.",
                    "Across the resident's lap."
                ],
                options_es: [
                    "Debajo de la cabeza del residente.",
                    "Cubriendo el espacio entre la cama y la silla.",
                    "En el suelo.",
                    "Sobre el regazo del residente."
                ],
                correct: 1,
                reason_en: "Slide boards provide a bridge for residents who cannot stand.",
                reason_es: "Las tablas de deslizamiento sirven de puente para los residentes que no pueden ponerse de pie."
            },
            {
                text_en: "What should the CNA do if a resident's pulse is 112 bpm?",
                text_es: "¿Qué debe hacer el CNA si el pulso de un residente es de 112 lpm?",
                options_en: [
                    "Document it and recheck in 4 hours.",
                    "Report it immediately to the nurse.",
                    "Tell the resident to exercise more.",
                    "Assume it is normal and move on."
                ],
                options_es: [
                    "Documentarlo y volver a comprobarlo en 4 horas.",
                    "Informarlo de inmediato a la enfermera.",
                    "Decirle al residente que haga más ejercicio.",
                    "Asumir que es normal y continuar."
                ],
                correct: 1,
                reason_en: "A heart rate over 100 bpm (Tachycardia) at rest must be reported.",
                reason_es: "Se debe informar de una frecuencia cardíaca superior a 100 lpm (taquicardia) en reposo."
            },
            {
                text_en: "How should a CNA identify an unresponsive resident?",
                text_es: "¿Cómo debe un CNA identificar a un residente que no responde?",
                options_en: [
                    "Asking the roommate.",
                    "Checking the resident's ID band.",
                    "Guessing based on the room number.",
                    "Waiting for them to wake up."
                ],
                options_es: [
                    "Preguntando al compañero de cuarto.",
                    "Verificando la pulsera de identificación del residente.",
                    "Adivinando según el número de habitación.",
                    "Esperando a que se despierte."
                ],
                correct: 1,
                reason_en: "ID band is the standard for uncommunicative residents.",
                reason_es: "La pulsera de identificación es el estándar para residentes que no se comunican."
            },
            {
                text_en: "A resident is on 'Airborne Precautions'. The CNA must wear:",
                text_es: "Un residente tiene 'Precauciones por Vía Aérea'. El CNA debe usar:",
                options_en: ["Surgical mask only.", "Gown and gloves.", "N95 respirator.", "Face shield only."],
                options_es: ["Solo mascarilla quirúrgica.", "Bata y guantes.", "Respirador N95.", "Solo protector facial."],
                correct: 2,
                reason_en: "Airborne particles require a specialized N95 mask.",
                reason_es: "Las partículas transportadas por el aire requieren una mascarilla N95 especializada."
            },
            {
                text_en: "What is the primary sign of an obstructed airway (total)?",
                text_es: "¿Cuál es el signo principal de una obstrucción total de las vías respiratorias?",
                options_en: ["The resident is coughing loudly.", "The resident is clutching their throat and cannot speak.", "The resident is sleeping.", "The resident is asking for water."],
                options_es: ["El residente está tosiendo fuerte.", "El residente se agarra la garganta y no puede hablar.", "El residente está durmiendo.", "El residente pide agua."],
                correct: 1,
                reason_en: "The universal sign of choking is clutching the throat.",
                reason_es: "El signo universal de asfixia es agarrarse la garganta."
            },
            {
                text_en: "A CNA finds a resident has a BP of 88/54 mmHg. What should they do?",
                text_es: "Un CNA encuentra que un residente tiene una PA de 88/54 mmHg. ¿Qué deben hacer?",
                options_en: [
                    "Wait 30 minutes and re-check.",
                    "Notify the nurse immediately.",
                    "Give the resident some coffee.",
                    "Document and move to the next resident."
                ],
                options_es: [
                    "Esperar 30 minutos y volver a comprobar.",
                    "Informar a la enfermera de inmediato.",
                    "Darle un poco de café al residente.",
                    "Documentar y pasar al siguiente residente."
                ],
                correct: 1,
                reason_en: "Low blood pressure (Hypotension) requires immediate nursing assessment.",
                reason_es: "Compartir resultados médicos está fuera del alcance de la práctica de un CNA."
            },
            {
                text_en: "A resident's call light is on, but you are busy with another resident's non-emergency request. You should:",
                text_es: "La luz de llamada de un residente está encendida, pero usted está ocupado con la solicitud no urgente de otro residente. Usted debe:",
                options_en: ["Ignore the light.", "Finish your task and then go.", "Answer the light immediately or ask a teammate to check on the resident.", "Wait for the nurse to answer it."],
                options_es: ["Ignorar la luz.", "Terminar su tarea y luego ir.", "Responder a la luz inmediatamente o pedir a un compañero que compruebe cómo está el residente.", "Esperar a que la enfermera responda."],
                correct: 2,
                reason_en: "Call lights must be answered promptly as they may indicate an emergency.",
                reason_es: "Las luces de llamada deben responderse puntualmente, ya que pueden indicar una emergencia."
            },
            {
                text_en: "Which of the following is a sign of 'Dehydration'?",
                text_es: "¿Cuál de los siguientes es un signo de 'Deshidratación'?",
                options_en: ["Increased thirst and dark urine.", "Clear urine and excessive energy.", "Normal skin turgor.", "Heavy sweating."],
                options_es: ["Aumento de la sed y orina oscura.", "Orina clara y energía excesiva.", "Turgencia normal de la piel.", "Sudoración intensa."],
                correct: 0,
                reason_en: "Dehydration can lead to confusion and other serious complications in the elderly.",
                reason_es: "La deshidratación puede provocar confusión y otras complicaciones graves en los ancianos."
            }
        ]
    },
    {
        name: "Batería 3: Paciente Geriátrico / Geriatric & Chronic Care",
        questions: [
            {
                text_en: "Which of the following is a normal age-related change in the skeletal system?",
                text_es: "¿Cuál de los siguientes es un cambio normal relacionado con la edad en el sistema esquelético?",
                options_en: ["Bones becoming more dense.", "Loss of bone mass and increased risk of fractures.", "Increased height.", "More flexible joints."],
                options_es: ["Los huesos se vuelven más densos.", "Pérdida de masa ósea y mayor riesgo de fracturas.", "Aumento de la estatura.", "Articulaciones más flexibles."],
                correct: 1,
                reason_en: "Osteoporosis is a common condition in older adults due to bone mass loss.",
                reason_es: "La osteoporosis es una afección común en los adultos mayores debido a la pérdida de masa ósea."
            },
            {
                text_en: "A resident has 'Osteoarthritis'. This means they have:",
                text_es: "Un residente tiene 'Osteoartritis'. Esto significa que tiene:",
                options_en: ["Joint pain and stiffness caused by wear and tear.", "A broken bone.", "Strong muscles.", "Perfect balance."],
                options_es: ["Dolor y rigidez articular causados por el desgaste.", "Un hueso roto.", "Músculos fuertes.", "Equilibrio perfecto."],
                correct: 0,
                reason_en: "Osteoarthritis is a degenerative joint disease common in the elderly.",
                reason_es: "La osteoartritis es una enfermedad degenerativa de las articulaciones común en los ancianos."
            },
            {
                text_en: "Which of the following is a normal age-related change in the integumentary system?",
                text_es: "¿Cuál de los siguientes es un cambio normal relacionado con la edad en el sistema tegumentario?",
                options_en: ["Increased skin elasticity.", "Thinning of the skin and loss of subcutaneous fat.", "Thicker, more oily skin.", "Faster wound healing."],
                options_es: ["Aumento de la elasticidad de la piel.", "Adelgazamiento de la piel y pérdida de grasa subcutánea.", "Piel más gruesa y grasa.", "Cicatrización de heridas más rápida."],
                correct: 1,
                reason_en: "Thinning skin increases the risk of tears and pressure ulcers in seniors.",
                reason_es: "La piel delgada aumenta el riesgo de desgarros y úlceras por presión en los ancianos."
            },
            {
                text_en: "A resident has 'Aphasia' following a stroke. This means they have difficulty:",
                text_es: "Un residente tiene 'Afasia' después de un derrame cerebral. Esto significa que tienen dificultad para:",
                options_en: ["Walking.", "Swallowing.", "Communicating through speech or writing.", "Seeing clearly."],
                options_es: ["Caminar.", "Tragar.", "Comunicarse a través del habla o la escritura.", "Ver con claridad."],
                correct: 2,
                reason_en: "Aphasia is a language disorder that affects communication.",
                reason_es: "La afasia es un trastorno del lenguaje que afecta la comunicación."
            },
            {
                text_en: "What is the best way to communicate with a resident who has a hearing impairment?",
                text_es: "¿Cuál es la mejor manera de comunicarse con un residente que tiene una discapacidad auditiva?",
                options_en: [
                    "Shout as loudly as possible.",
                    "Face the resident directly and speak clearly at a normal pace.",
                    "Speak into the resident's ear.",
                    "Avoid communication to prevent frustration."
                ],
                options_es: [
                    "Gritar lo más fuerte posible.",
                    "Mirar directamente al residente y hablar con claridad a un ritmo normal.",
                    "Hablar al oído del residente.",
                    "Evitar la comunicación para prevenir la frustración."
                ],
                correct: 1,
                reason_en: "Visual cues and clear articulation help the resident understand speech better.",
                reason_es: "Las señales visuales y la articulación clara ayudan al residente a comprender mejor el habla."
            },
            {
                text_en: "A resident with Alzheimer's disease is repeating the same question over and over. The CNA should:",
                text_es: "Un residente con la enfermedad de Alzheimer repite la misma pregunta una y otra vez. El CNA debe:",
                options_en: [
                    "Tell the resident to stop being annoying.",
                    "Answer the question calmly each time as if for the first time.",
                    "Ignore the resident.",
                    "Tell the resident they already asked that."
                ],
                options_es: [
                    "Decirle al residente que deje de ser molesto.",
                    "Responder a la pregunta con calma cada vez como si fuera la primera vez.",
                    "Ignorar al residente.",
                    "Decirle al residente que ya preguntó eso."
                ],
                correct: 1,
                reason_en: "Patience and validation are key when dealing with repetitive behaviors in dementia.",
                reason_es: "La paciencia y la validación son fundamentales al tratar comportamientos repetitivos en la demencia."
            },
            {
                text_en: "What is 'Validation Therapy' in dementia care?",
                text_es: "¿Qué es la 'Terapia de Validación' en el cuidado de la demencia?",
                options_en: [
                    "Correcting the resident's reality (e.g., 'Your mother is dead').",
                    "Acknowledging and accepting the resident's feelings and reality.",
                    "Testing the resident's memory with flashcards.",
                    "Using restraints to prevent wandering."
                ],
                options_es: [
                    "Corregir la realidad del residente (ej. 'Tu madre ha muerto').",
                    "Reconocer y aceptar los sentimientos y la realidad del residente.",
                    "Poner a prueba la memoria del residente con tarjetas.",
                    "Usar restricciones para evitar el deambuleo."
                ],
                correct: 1,
                reason_en: "Validation reduces anxiety by meeting the resident in their own world.",
                reason_es: "La validación reduce la ansiedad al encontrarse con el residente en su propio mundo."
            },
            {
                text_en: "A resident has Osteoporosis. This condition makes them at high risk for:",
                text_es: "Un residente tiene osteoporosis. Esta condición lo pone en alto riesgo de:",
                options_en: ["Infection.", "Fractures.", "Diabetes.", "Hearing loss."],
                options_es: ["Infección.", "Fracturas.", "Diabetes.", "Pérdida de audición."],
                correct: 1,
                reason_en: "Osteoporosis causes bones to become brittle and break easily.",
                reason_es: "La osteoporosis hace que los huesos se vuelvan quebradizos y se rompan fácilmente."
            },
            {
                text_en: "Which of the following is a common symptom of Parkinson's Disease?",
                text_es: "¿Cuál de los siguientes es un síntoma común de la enfermedad de Parkinson?",
                options_en: ["Increased speed of movement.", "Tremors and resting 'pill-rolling' motion.", "Excellent balance.", "Clear, loud speech."],
                options_es: ["Aumento de la velocidad de movimiento.", "Temblores y movimiento de 'rodar píldoras' en reposo.", "Excelente equilibrio.", "Habla clara y fuerte."],
                correct: 1,
                reason_en: "Parkinson's affects motor control, causing tremors and stiffness.",
                reason_es: "El Parkinson afecta el control motor, causando temblores y rigidez."
            },
            {
                text_en: "A resident with congestive heart failure (CHF) is experiencing increased shortness of breath and leg swelling. This is likely due to:",
                text_es: "Un residente con insuficiencia cardíaca congestiva (ICC) experimenta un aumento de la falta de aire e hinchazón en las piernas. Esto probablemente se deba a:",
                options_en: ["Fluid overload (Edema).", "Dehydration.", "Too much exercise.", "High protein diet."],
                options_es: ["Sobrecarga de líquidos (Edema).", "Deshidratación.", "Demasiado ejercicio.", "Dieta alta en proteínas."],
                correct: 0,
                reason_en: "CHF prevents the heart from pumping effectively, leading to fluid buildup.",
                reason_es: "La ICC impide que el corazón bombee eficazmente, lo que provoca la acumulación de líquidos."
            },
            {
                text_en: "What is the primary goal of Palliative Care?",
                text_es: "¿Cuál es el objetivo principal de los Cuidados Paliativos?",
                options_en: [
                    "To cure the resident's disease.",
                    "To provide comfort and symptom management for a serious illness.",
                    "To extend life at all costs.",
                    "To restrict visitors."
                ],
                options_es: [
                    "Curar la enfermedad del residente.",
                    "Brindar comodidad y manejo de los síntomas de una enfermedad grave.",
                    "Prolongar la vida a toda costa.",
                    "Restringir las visitas."
                ],
                correct: 1,
                reason_en: "Palliative care focuses on quality of life rather than cure.",
                reason_es: "Los cuidados paliativos se centran en la calidad de vida más que en la curación."
            },
            {
                text_en: "A resident has 'Dysphagia'. The CNA should expect their liquids to be:",
                text_es: "Un residente tiene 'Disfagia'. El CNA debe esperar que sus líquidos sean:",
                options_en: ["Thin (like water).", "Thickened (nectar, honey, or pudding consistency).", "Hot at all times.", "Carbonated."],
                options_es: ["Claros (como el agua).", "Espesados (consistencia de néctar, miel o pudín).", "Calientes en todo momento.", "Carbonatados."],
                correct: 1,
                reason_en: "Thickened liquids are easier to swallow and prevent aspiration.",
                reason_es: "Los líquidos espesados son más fáciles de tragar y previenen la aspiración."
            },
            {
                text_en: "Which of the following is a symptom of Cataracts?",
                text_es: "¿Cuál de los siguientes es un síntoma de cataratas?",
                options_en: ["Increased peripheral vision.", "Cloudy or blurred vision.", "Redness and itching of the eyes.", "Sudden loss of hearing."],
                options_es: ["Aumento de la visión periférica.", "Visión borrosa o nublada.", "Enrojecimiento y picazón en los ojos.", "Pérdida repentina de la audición."],
                correct: 1,
                reason_en: "Cataracts cause the lens of the eye to become opaque.",
                reason_es: "Las cataratas hacen que el cristalino del ojo se vuelva opaco."
            },
            {
                text_en: "A resident with Type 2 Diabetes is found sweaty, shaky, and confused. What is the most likely cause?",
                text_es: "Un residente con diabetes tipo 2 se encuentra sudoroso, tembloroso y confundido. ¿Cuál es la causa más probable?",
                options_en: ["Hyperglycemia.", "Hypoglycemia (Low blood sugar).", "High blood pressure.", "Food poisoning."],
                options_es: ["Hiperglucemia.", "Hipoglucemia (nivel bajo de azúcar en sangre).", "Presión arterial alta.", "Intoxicación alimentaria."],
                correct: 1,
                reason_en: "Sweating and shakiness are classic signs of a 'sugar crash'.",
                reason_es: "La sudoración y los temblores son signos clásicos de un 'bajón de azúcar'."
            },
            {
                text_en: "What is 'Contracture'?",
                text_es: "¿Qué es una 'Contractura'?",
                options_en: [
                    "A legal document for employment.",
                    "Permanent shortening of a muscle or joint resulting in deformity.",
                    "A type of medication.",
                    "An infection of the bone."
                ],
                options_es: [
                    "Un documento legal para el empleo.",
                    "Acortamiento permanente de un músculo o articulación que resulta en deformidad.",
                    "Un tipo de medicamento.",
                    "Una infección del hueso."
                ],
                correct: 1,
                reason_en: "ROM exercises are vital to prevent fixed contractures in bedbound residents.",
                reason_es: "Los ejercicios de ROM son vitales para prevenir contracturas fijas en residentes encamados."
            },
            {
                text_en: "A resident is in the 'Terminal' stage of cancer. Hospice care is usually initiated when the doctor estimates life expectancy to be:",
                text_es: "Un residente se encuentra en la etapa 'Terminal' del cáncer. El cuidado de hospicio suele iniciarse cuando el médico estima que la esperanza de vida es de:",
                options_en: ["2 years.", "6 months or less.", "5 years.", "1 month exactly."],
                options_es: ["2 años.", "6 meses o menos.", "5 años.", "1 mes exactamente."],
                correct: 1,
                reason_en: "Hospice is specifically for end-of-life care with a limited prognosis.",
                reason_es: "El hospicio es específicamente para el cuidado al final de la vida con un pronóstico limitado."
            },
            {
                text_en: "Which of the following is a common cause of constipation in the elderly?",
                text_es: "¿Cuál de los siguientes es una causa común de estreñimiento en los ancianos?",
                options_en: ["Increased physical activity.", "High fiber diet.", "Decreased fluid intake and lack of mobility.", "Drinking too much water."],
                options_es: ["Aumento de la actividad física.", "Dieta alta en fibra.", "Disminución de la ingesta de líquidos y falta de movilidad.", "Beber demasiada agua."],
                correct: 2,
                reason_en: "Seniors often have slower digestion and may not drink enough fluids.",
                reason_es: "Los ancianos suelen tener una digestión más lenta y es posible que no beban suficientes líquidos."
            },
            {
                text_en: "A resident has 'Glaucoma'. This is characterized by:",
                text_es: "Un residente tiene 'Glaucoma'. Esto se caracteriza por:",
                options_en: [
                    "Loss of central vision.",
                    "Increased pressure in the eye damaging the optic nerve.",
                    "An infection of the cornea.",
                    "Double vision only."
                ],
                options_es: [
                    "Pérdida de visión central.",
                    "Aumento de la presión en el ojo que daña el nervio óptico.",
                    "Una infección de la córnea.",
                    "Visión doble únicamente."
                ],
                correct: 1,
                reason_en: "Glaucoma can lead to blindness if intraocular pressure is not controlled.",
                reason_es: "El glaucoma puede provocar ceguera si no se controla la presión intraocular."
            },
            {
                text_en: "When a resident has a 'Phantom Limb' sensation after an amputation, the CNA should:",
                text_es: "Cuando un residente tiene la sensación de un 'miembro fantasma' después de una amputación, el CNA debe:",
                options_en: [
                    "Tell the resident they are imagining it.",
                    "Acknowledge the resident's pain or sensation as real and report it.",
                    "Laugh it off to make the resident feel better.",
                    "Tell the resident the limb is gone."
                ],
                options_es: [
                    "Decirle al residente que lo está imaginando.",
                    "Reconocer el dolor o la sensación del residente como real e informarlo.",
                    "Reírse para que el residente se sienta mejor.",
                    "Decirle al residente que el miembro ya no está."
                ],
                correct: 1,
                reason_en: "Phantom sensation is a real neurological phenomenon and can be painful.",
                reason_es: "La sensación fantasma es un fenómeno neurológico real y puede ser dolorosa."
            },
            {
                text_en: "What is 'Sundowning' specifically associated with?",
                text_es: "¿Con qué se asocia específicamente el 'Sundowning' (agitación vespertina)?",
                options_en: ["Sunburn.", "Diabetes.", "Dementia and Alzheimer's disease.", "Pneumonia."],
                options_es: ["Quemaduras solares.", "Diabetes.", "Demencia y enfermedad de Alzheimer.", "Neumonía."],
                correct: 2,
                reason_en: "Increased confusion in the late afternoon is a common dementia pattern.",
                reason_es: "El aumento de la confusión al final de la tarde es un patrón común de la demencia."
            },
            {
                text_en: "A resident has a 'Stoma'. This is an opening for:",
                text_es: "Un residente tiene un 'Estoma'. Esta es una abertura para:",
                options_en: ["Drawing blood.", "A colostomy or ileostomy.", "Breathing only.", "Feeding tubes only."],
                options_es: ["Sacar sangre.", "Una colostomía o ileostomía.", "Respirar únicamente.", "Sondas de alimentación únicamente."],
                correct: 1,
                reason_en: "Stomas are surgical openings for waste elimination.",
                reason_es: "Los estomas son aberturas quirúrgicas para la eliminación de desechos."
            },
            {
                text_en: "What should the CNA do if a resident's family asks for the results of a recent blood test?",
                text_es: "¿Qué debe hacer el CNA si la familia de un residente pregunta por los resultados de un análisis de sangre reciente?",
                options_en: [
                    "Tell them the results if they know them.",
                    "Refer the family to the nurse or doctor.",
                    "Guess the results.",
                    "Tell them to wait for the mail."
                ],
                options_es: [
                    "Decirles los resultados si los conocen.",
                    "Remitir a la familia a la enfermera o al médico.",
                    "Adivinar los resultados.",
                    "Decirles que esperen al correo."
                ],
                correct: 1,
                reason_en: "Sharing medical results is beyond the CNA scope of practice.",
                reason_es: "Compartir resultados médicos está fuera del alcance de la práctica de un CNA."
            },
            {
                text_en: "A resident has 'Decubitus Ulcers'. These are more commonly known as:",
                text_es: "Un residente tiene 'Úlceras de Decúbito'. Estas se conocen más comúnmente como:",
                options_en: ["Skin tags.", "Pressure sores or bedsores.", "Bruises.", "Warts."],
                options_es: ["Acrocordones o verrugas cutáneas.", "Llagas por presión o escaras.", "Moretones o hematomas.", "Verrugas."],
                correct: 1,
                reason_en: "Pressure ulcers are caused by prolonged pressure on bony prominences.",
                reason_es: "Las úlceras por presión son causadas por una presión prolongada sobre las prominencias óseas."
            },
            {
                text_en: "Which of the following is a sign of 'Dehydration' in the elderly?",
                text_es: "¿Cuál de los siguientes es un signo de 'Deshidratación' en los ancianos?",
                options_en: ["Moist mucous membranes.", "Dark, foul-smelling urine and dry mouth.", "Clear, high-volume urine.", "Excessive energy."],
                options_es: ["Membranas mucosas húmedas.", "Orina oscura y con mal olor y boca seca.", "Orina clara y de gran volumen.", "Energía excesiva."],
                correct: 1,
                reason_en: "Concentrated urine and dry mouth are primary indicators of fluid deficit.",
                reason_es: "La orina concentrada y la boca seca son los principales indicadores de déficit de líquidos."
            },
            {
                text_en: "What does 'NPO' stand for in a resident's chart?",
                text_es: "¿Qué significa 'NPO' en la historia clínica de un residente?",
                options_en: ["No personal objects.", "Nothing by mouth.", "Nightly physical observation.", "Noticeable patient odor."],
                options_es: ["Sin objetos personales.", "Nada por la boca (Nothing by mouth).", "Observación física nocturna.", "Olor notable del paciente."],
                correct: 1,
                reason_en: "NPO is used prior to surgery or for severe swallowing issues.",
                reason_es: "NPO se utiliza antes de una cirugía o por problemas graves de deglución."
            },
            {
                text_en: "A resident with diabetes is 'Hoarding' food in their room. The CNA should:",
                text_es: "Un residente con diabetes está 'Atesorando' (Hoarding) comida en su habitación. El CNA debe:",
                options_en: [
                    "Throw it all away while the resident is sleeping.",
                    "Tell the resident they are being bad.",
                    "Report it to the nurse because it affects blood sugar control and sanitation.",
                    "Ignore it."
                ],
                options_es: [
                    "Tirarlo todo mientras el residente duerme.",
                    "Decirle al residente que se está portando mal.",
                    "Informar a la enfermera porque afecta al control del azúcar en sangre y a la higiene.",
                    "Ignorarlo."
                ],
                correct: 2,
                reason_en: "Hoarding food is a safety and health risk for diabetic residents.",
                reason_es: "Atesorar comida es un riesgo para la salud y la seguridad de los residentes diabéticos."
            },
            {
                text_en: "Which of the following is an example of 'Neglect'?",
                text_es: "¿Cuál de los siguientes es un ejemplo de 'Negligencia'?",
                options_en: [
                    "Helping a resident walk.",
                    "Failing to provide necessary care or assistance, resulting in harm.",
                    "Giving the resident their favorite meal.",
                    "Listening to the resident's concerns."
                ],
                options_es: [
                    "Ayudar a caminar a un residente.",
                    "No proporcionar los cuidados o la asistencia necesarios, resultando en daño.",
                    "Darle al residente su comida favorita.",
                    "Escuchar las inquietudes del residente."
                ],
                correct: 1,
                reason_en: "Neglect is a form of abuse involving failure to meet basic needs.",
                reason_es: "La negligencia es una forma de abuso que implica no satisfacer las necesidades básicas."
            },
            {
                text_en: "A resident is 'Wandering' into other residents' rooms. The CNA should:",
                text_es: "Un residente está 'deambulando' por las habitaciones de otros residentes. El CNA debe:",
                options_en: [
                    "Lock the resident's door.",
                    "Gently lead the resident back to their own room or a safe area.",
                    "Shout at the resident.",
                    "Tell the other residents to push them out."
                ],
                options_es: [
                    "Cerrar con llave la puerta del residente.",
                    "Guiar suavemente al residente de vuelta a su propia habitación o a un área segura.",
                    "Gritarle al residente.",
                    "Decirle a los otros residentes que lo echen."
                ],
                correct: 1,
                reason_en: "Residents must be managed with dignity and safety in mind.",
                reason_es: "Los residentes deben ser tratados con dignidad y teniendo en cuenta su seguridad."
            },
            {
                text_en: "What should the CNA do if they see a red area on a resident's tailbone?",
                text_es: "¿Qué debe hacer el CNA si ve una zona enrojecida en el cóccix de un residente?",
                options_en: [
                    "Massage the area to increase blood flow.",
                    "Apply a clean dressing.",
                    "Notify the nurse and avoid placing the resident on their back.",
                    "Ignore it if it doesn't look like an open wound."
                ],
                options_es: [
                    "Masajear la zona para aumentar el flujo sanguíneo.",
                    "Aplicar un vendaje limpio.",
                    "Informar a la enfermera y evitar colocar al residente de espaldas.",
                    "Ignorarlo si no parece una herida abierta."
                ],
                correct: 2,
                reason_en: "Never massage red areas (Stage 1 pressure ulcer); report it for assessment.",
                reason_es: "Nunca masajee las zonas enrojecidas (úlceras por presión de Etapa 1); infórmelo para su evaluación."
            },
            {
                text_en: "Which of the following is a sign of 'Physical Abuse' in a resident?",
                text_es: "¿Cuál de los siguientes es un signo de 'Abuso Físico' en un residente?",
                options_en: ["Bilateral bruises or symmetrical injuries.", "The resident being happy.", "Good skin integrity.", "A single minor scratch."],
                options_es: ["Hematomas bilaterales o lesiones simétricas.", "Que el residente esté feliz.", "Buena integridad de la piel.", "Un solo rasguño menor."],
                correct: 0,
                reason_en: "Suspicious injuries, especially matching ones, must be reported.",
                reason_es: "Se deben informar las lesiones sospechosas, especialmente si son simétricas."
            },
            {
                text_en: "When a resident is 'Dying', which senses are usually the last to go?",
                text_es: "Cuando un residente está 'Muriendo', ¿qué sentidos suelen ser los últimos en desaparecer?",
                options_en: ["Sight.", "Hearing.", "Taste.", "Smell."],
                options_es: ["La vista.", "El oído.", "El gusto.", "El olfato."],
                correct: 1,
                reason_en: "It is widely believed that hearing remains active even in unconscious patients near death.",
                reason_es: "Se cree ampliamente que el oído permanece activo incluso en pacientes inconscientes cerca de la muerte."
            },
            {
                text_en: "What is 'Hospice Care' also referred to as?",
                text_es: "¿Cómo se llama también al 'Cuidado de Hospicio'?",
                options_en: ["Acute care.", "Rehabilitative care.", "End-of-life or Comfort care.", "Preventative care."],
                options_es: ["Cuidados agudos.", "Cuidados de rehabilitación.", "Cuidados al final de la vida o de confort.", "Cuidados preventivos."],
                correct: 2,
                reason_en: "Hospice focuses on dignity and peace during the final stages of life.",
                reason_es: "El hospicio se centra en la dignidad y la paz durante las etapas finales de la vida."
            },
            {
                text_en: "A resident has 'Edema' (swelling) of the legs. The CNA can help by:",
                text_es: "Un residente tiene 'Edema' (hinchazón) en las piernas. El CNA puede ayudar:",
                options_en: [
                    "Keeping the resident standing for long periods.",
                    "Elevating the resident's legs as ordered.",
                    "Applying tight bandages without an order.",
                    "Giving the resident more water."
                ],
                options_es: [
                    "Mantener al residente de pie por largos periodos.",
                    "Elevar las piernas del residente según lo ordenado.",
                    "Aplicar vendajes apretados sin una orden.",
                    "Darle más agua al residente."
                ],
                correct: 1,
                reason_en: "Elevation helps with venous return and reduces swelling.",
                reason_es: "La elevación ayuda con el retorno venoso y reduce la hinchazón."
            },
            {
                text_en: "What should the CNA do if a resident's roommate is dying?",
                text_es: "¿Qué debe hacer el CNA si el compañero de habitación de un residente está muriendo?",
                options_en: [
                    "Ignore the roommate's feelings.",
                    "Provide privacy for the dying resident and support for the roommate.",
                    "Tell the roommate to move out.",
                    "Discuss the details of the dying resident's condition with the roommate."
                ],
                options_es: [
                    "Ignorar los sentimientos del compañero.",
                    "Proporcionar privacidad al residente que está muriendo y apoyo al compañero.",
                    "Decirle al compañero que se mude.",
                    "Hablar de los detalles de la condición del residente que está muriendo con el compañero."
                ],
                correct: 1,
                reason_en: "Privacy and emotional support are crucial in shared environments.",
                reason_es: "La privacidad y el apoyo emocional son cruciales en entornos compartidos."
            },
            {
                text_en: "Which of the following is a common cause of 'UTI' in elderly women?",
                text_es: "¿Cuál de los siguientes es una causa común de 'ITU' en mujeres ancianas?",
                options_en: ["Poor perineal hygiene.", "Drinking too much water.", "Exercise.", "Eating vegetables."],
                options_es: ["Mala higiene perineal.", "Beber demasiada agua.", "Hacer ejercicio.", "Comer verduras."],
                correct: 0,
                reason_en: "Bacteria entering the urethra from the rectum is a primary cause.",
                reason_es: "La entrada de bacterias en la uretra desde el recto es una de las causas principales."
            },
            {
                text_en: "A resident has a 'Foley Catheter'. The drainage bag should be placed:",
                text_es: "Un residente tiene una 'Sonda Foley'. La bolsa de drenaje debe colocarse:",
                options_en: [
                    "On the floor.",
                    "Below the level of the bladder.",
                    "Above the level of the heart.",
                    "On the resident's lap."
                ],
                options_es: [
                    "En el suelo.",
                    "Por debajo del nivel de la vejiga.",
                    "Por encima del nivel del corazón.",
                    "Sobre el regazo del residente."
                ],
                correct: 1,
                reason_en: "Gravity allows the urine to flow correctly and prevents backflow infection.",
                reason_es: "La gravedad permite que la orina fluya correctamente y evita que la infección retroceda."
            },
            {
                text_en: "What should the CNA do if they find a resident crying?",
                text_es: "¿Qué debe hacer el CNA si encuentra a un residente llorando?",
                options_en: [
                    "Ignore them to avoid embarrassment.",
                    "Offer comfort, listen, and report the sadness to the nurse.",
                    "Tell them to 'cheer up'.",
                    "Ask them why they are such a baby."
                ],
                options_es: [
                    "Ignorarlos para evitar que se sientan avergonzados.",
                    "Ofrecer consuelo, escuchar e informar de la tristeza a la enfermera.",
                    "Decirles que 'se animen'.",
                    "Preguntarles por qué se portan como bebés."
                ],
                correct: 1,
                reason_en: "Emotional support is as important as physical care.",
                reason_es: "El apoyo emocional es tan importante como los cuidados físicos."
            },
            {
                text_en: "A resident with diabetes has a small cut on their foot. The CNA should:",
                text_es: "Un residente con diabetes tiene un pequeño corte en el pie. El CNA debe:",
                options_en: [
                    "Wait 3 days to see if it heals.",
                    "Notify the nurse immediately.",
                    "Put a Band-aid on and forget it.",
                    "Soak the foot in hot water."
                ],
                options_es: [
                    "Esperar 30 días para ver si se cura.",
                    "Informar a la enfermera de inmediato.",
                    "Poner una tirita y olvidarlo.",
                    "Sumergir el pie en agua caliente."
                ],
                correct: 1,
                reason_en: "Diabetics have poor healing and high risk for severe foot infections.",
                reason_es: "Los diabéticos cicatrizan mal y tienen un alto riesgo de sufrir infecciones graves en los pies."
            },
            {
                text_en: "What is 'Pneumonia'?",
                text_es: "¿Qué es la 'Neumonía'?",
                options_en: [
                    "An infection of the lungs.",
                    "A type of heart attack.",
                    "A skin condition.",
                    "A digestive problem."
                ],
                options_es: [
                    "Una infección de los pulmones.",
                    "Un tipo de ataque cardíaco.",
                    "Una afección de la piel.",
                    "Un problema digestivo."
                ],
                correct: 0,
                reason_en: "Pneumonia causes inflammation of the air sacs in the lungs.",
                reason_es: "La neumonía causa la inflamación de los sacos de aire en los pulmones."
            },
            {
                text_en: "A resident is on 'Aspiration Precautions'. The CNA should:",
                text_es: "Un residente tiene 'Precauciones de Aspiración'. El CNA debe:",
                options_en: [
                    "Keep the head of the bed elevated during and after meals.",
                    "Help the resident eat quickly.",
                    "Give the resident thin liquids only.",
                    "Lay the resident flat after eating."
                ],
                options_es: [
                    "Mantener la cabecera de la cama elevada durante y después de las comidas.",
                    "Ayudar al residente a comer rápido.",
                    "Darle al residente solo líquidos claros.",
                    "Acostar al residente completamente plano después de comer."
                ],
                correct: 0,
                reason_en: "Upright positioning reduces the risk of food entering the lungs.",
                reason_es: "El posicionamiento erguido reduce el riesgo de que la comida entre en los pulmones."
            },
            {
                text_en: "What is the primary role of the CNA during end-of-life care?",
                text_es: "¿Cuál es la función principal del CNA durante los cuidados al final de la vida?",
                options_en: [
                    "To prolong life.",
                    "To provide comfort, dignity, and specialized skin care.",
                    "To restrict the family's presence.",
                    "To perform medical procedures."
                ],
                options_es: [
                    "Prolongar la vida.",
                    "Brindar comodidad, dignidad y cuidados especializados de la piel.",
                    "Restringir la presencia de la familia.",
                    "Realizar procedimientos médicos."
                ],
                correct: 1,
                reason_en: "CNAs focus on the resident's physical comfort and emotional dignity.",
                reason_es: "Los CNA se centran en la comodidad física y la dignidad emocional del residente."
            },
            {
                text_en: "Which of the following is a sign of 'Decline' in a hospice resident?",
                text_es: "¿Cuál de los siguientes es un signo de 'Deterioro' en un residente de hospicio?",
                options_en: ["Increased appetite.", "Increased sleeping and 'Mottling' of the skin.", "Talking more than usual.", "Strong, regular pulse."],
                options_es: ["Aumento del apetito.", "Aumento del sueño y 'moteado' (mottling) de la piel.", "Hablar más de lo habitual.", "Pulso fuerte y regular."],
                correct: 1,
                reason_en: "Mottling (bluish/red spots) indicates failing circulation near death.",
                reason_es: "El moteado (manchas azules/rojas) indica un fallo en la circulación cerca de la muerte."
            },
            {
                text_en: "What should a CNA do when a resident with dementia becomes sexually inappropriate?",
                text_es: "¿Qué debe hacer un CNA cuando un residente con demencia se vuelve sexualmente inapropiado?",
                options_en: [
                    "Laugh and flirt back.",
                    "Scold the resident loudly.",
                    "Remaining professional, redirect the resident, and report the behavior.",
                    "Ignore it entirely."
                ],
                options_es: [
                    "Reírse y coquetear de vuelta.",
                    "Regañar al residente en voz alta.",
                    "Mantener el profesionalismo, redirigir al residente e informar el comportamiento.",
                    "Ignorarlo por completo."
                ],
                correct: 2,
                reason_en: "Inappropriate behavior is often a symptom of the disease, not intent.",
                reason_es: "El comportamiento inapropiado suele ser un síntoma de la enfermedad, no una intención."
            },
            {
                text_en: "A resident has Chronic Obstructive Pulmonary Disease (COPD). The best position for them to breathe is:",
                text_es: "Un residente tiene Enfermedad Pulmonar Obstructiva Crónica (EPOC). La mejor posición para que respiren es:",
                options_en: ["Lying flat on their back (Supine).", "Fowler's or Orthopneic position (leaning over a table).", "On their stomach (Prone).", "Left side-lying."],
                options_es: ["Acostado de espaldas (Supina).", "Posición de Fowler u Ortopneica (inclinado sobre una mesa).", "Boca abajo (Prona).", "Acostado sobre el lado izquierdo."],
                correct: 1,
                reason_en: "Sitting up or leaning forward allows maximum lung expansion.",
                reason_es: "Sentarse o inclinarse hacia adelante permite la máxima expansión pulmonar."
            },
            {
                text_en: "What is 'Atrophy'?",
                text_es: "¿Qué es la 'Atrofia'?",
                options_en: [
                    "Overgrowth of a muscle.",
                    "Wasting away or reduction in size of a muscle due to lack of use.",
                    "A type of skin rash.",
                    "A memory disorder."
                ],
                options_es: [
                    "Crecimiento excesivo de un músculo.",
                    "Desgaste o reducción del tamaño de un músculo debido a la falta de uso.",
                    "Un tipo de erupción cutánea.",
                    "Un trastorno de la memoria."
                ],
                correct: 1,
                reason_en: "Immobility rapidly leads to muscle atrophy in seniors.",
                reason_es: "La inmovilidad provoca rápidamente atrofia muscular en los ancianos."
            },
            {
                text_en: "A resident is on a 'Low Sodium' diet. This is primarily for residents with:",
                text_es: "Un residente lleva una dieta 'Baja en Sodio'. Esto es principalmente para residentes con:",
                options_en: ["Broken bones.", "Hypertension and heart disease.", "Dementia.", "Anemia."],
                options_es: ["Huesos rotos.", "Hipertensión y enfermedades cardíacas.", "Demencia.", "Anemia."],
                correct: 1,
                reason_en: "Sodium causes fluid retention, which worsens high blood pressure and heart failure.",
                reason_es: "El sodio provoca la retención de líquidos, lo que empeora la presión arterial alta y la insuficiencia cardíaca."
            },
            {
                text_en: "What is the correct way to provide perineal care to a female resident?",
                text_es: "¿Cuál es la forma correcta de proporcionar cuidado perineal a una residente?",
                options_en: ["Back to front.", "Front to back (cleanest to dirtiest).", "Side to side.", "Scrubbing vigorously."],
                options_es: ["De atrás hacia adelante.", "De adelante hacia atrás (de lo más limpio a lo más sucio).", "De lado a lado.", "Frotando vigorosamente."],
                correct: 1,
                reason_en: "Wiping front to back prevents UTI by keeping fecal matter away from the urethra.",
                reason_es: "Limpiar de adelante hacia atrás previene la ITU al mantener la materia fecal alejada de la uretra."
            },
            {
                text_en: "A resident has 'Edema' in their ankles. This means they have:",
                text_es: "Un residente tiene 'Edema' en los tobillos. Esto significa que tienen:",
                options_en: ["Bony growths.", "Accumulation of fluid in the tissues (swelling).", "A rash.", "A lack of blood flow."],
                options_es: ["Crecimientos óseos.", "Acumulación de líquido en los tejidos (hinchazón).", "Una erupción.", "Falta de flujo sanguíneo."],
                correct: 1,
                reason_en: "Edema is a sign often seen in heart or kidney failure.",
                reason_es: "El edema es un signo que se ve a menudo en la insuficiencia cardíaca o renal."
            },
            {
                text_en: "Which of the following is a symptom of 'Hyperglycemia'?",
                text_es: "¿Cuál de los siguientes es un síntoma de 'Hiperglucemia'?",
                options_en: ["Extreme thirst and frequent urination.", "Shaking and cold sweats.", "Increased energy.", "Weight gain."],
                options_es: ["Sed extrema y micción frecuente.", "Temblores y sudores fríos.", "Aumento de energía.", "Aumento de peso."],
                correct: 0,
                reason_en: "Polydipsia (thirst) and polyuria (urination) are key signs of high blood sugar.",
                reason_es: "La polidipsia (sed) y la poliuria (micción) son signos clave de tener el nivel de azúcar en sangre alto."
            },
            {
                text_en: "A resident has a 'Mechanical Soft' diet. This means the food should be:",
                text_es: "Un residente tiene una dieta 'Blanda Mecánica'. Esto significa que la comida debe estar:",
                options_en: ["Pureed like baby food.", "Chopped or ground for easier chewing.", "Liquid only.", "Whole but very cold."],
                options_es: ["Hecha puré como la comida para bebés.", "Picada o molida para facilitar la masticación.", "Líquida solamente.", "Entera pero muy fría."],
                correct: 1,
                reason_en: "Mechanical soft is for residents with chewing difficulties but who can still swallow solid bits.",
                reason_es: "La dieta blanda mecánica es para residentes con dificultades para masticar pero que aún pueden tragar trozos sólidos."
            },
            {
                text_en: "What is the most common sign of a Hip Fracture in the elderly?",
                text_es: "¿Cuál es el signo más común de una fractura de cadera en los ancianos?",
                options_en: [
                    "One leg appears shorter and is externally rotated.",
                    "The resident can walk perfectly.",
                    "The leg is internally rotated and longer.",
                    "There is no pain."
                ],
                options_es: [
                    "Una pierna parece más corta y está rotada externamente.",
                    "El residente puede caminar perfectamente.",
                    "La pierna está rotada internamente y es más larga.",
                    "No hay dolor."
                ],
                correct: 0,
                reason_en: "Shortening and outward rotation are classic indicators of a hip fracture.",
                reason_es: "El acortamiento y la rotación hacia afuera son indicadores clásicos de una fractura de cadera."
            },
            {
                text_en: "A resident with rheumatoid arthritis has 'Morning Stiffness'. The CNA can help by:",
                text_es: "Un residente con artritis reumatoide tiene 'Rigidez Matutina'. El CNA puede ayudar:",
                options_en: [
                    "Applying cold ice immediately.",
                    "Helping with a warm bath or shower to loosen joints.",
                    "Telling the resident to stay in bed all day.",
                    "Forcing the joints to move quickly."
                ],
                options_es: [
                    "Aplicando hielo inmediatamente.",
                    "Ayudando con un baño o ducha tibia para relajar las articulaciones.",
                    "Diciéndole al residente que se quede en la cama todo el día.",
                    "Obligando a las articulaciones a moverse rápidamente."
                ],
                correct: 1,
                reason_en: "Heat therapy is effective for arthritic stiffness.",
                reason_es: "La terapia de calor es eficaz para la rigidez artrítica."
            },
            {
                text_en: "What is 'Aspiration'?",
                text_es: "¿Qué es la 'Apiración'?",
                options_en: [
                    "A career goal.",
                    "Inhaling food, fluid, or foreign material into the lungs.",
                    "A type of breathing treatment.",
                    "Deep breathing exercises."
                ],
                options_es: [
                    "Una meta profesional.",
                    "Inhalar comida, líquido o material extraño hacia los pulmones.",
                    "Un tipo de tratamiento respiratorio.",
                    "Ejercicios de respiración profunda."
                ],
                correct: 1,
                reason_en: "Aspiration can lead to deadly pneumonia and must be prevented.",
                reason_es: "La aspiración puede provocar una neumonía mortal y debe evitarse."
            },
            {
                text_en: "Which of the following describes 'Empathy'?",
                text_es: "¿Cuál de los siguientes describe la 'Empatía'?",
                options_en: [
                    "Feeling sorry for the resident.",
                    "Understanding and sharing the feelings of another person.",
                    "Thinking you are better than the resident.",
                    "Ignoring the resident's problems."
                ],
                options_es: [
                    "Sentir lástima por el residente.",
                    "Comprender y compartir los sentimientos de otra persona.",
                    "Pensar que eres mejor que el residente.",
                    "Ignorar los problemas del residente."
                ],
                correct: 1,
                reason_en: "Empathy is a core value in nursing care.",
                reason_es: "La empatía es un valor fundamental en los cuidados de enfermería."
            },
            {
                text_en: "A resident has a 'Fluid Restriction' of 1200mL. This means:",
                text_es: "Un residente tiene una 'Restricción de Líquidos' de 1200 ml. Esto significa:",
                options_en: [
                    "They should drink at least 1200mL.",
                    "The total amount of fluid they can have in 24 hours is 1200mL.",
                    "They can only drink water.",
                    "They should not drink anything at all."
                ],
                options_es: [
                    "Deberían beber al menos 1200 ml.",
                    "La cantidad total de líquido que pueden tomar en 24 horas es de 1200 ml.",
                    "Solo pueden beber agua.",
                    "No deberían beber nada de nada."
                ],
                correct: 1,
                reason_en: "Restrictions are common in kidney and heart failure patients.",
                reason_es: "Las restricciones son comunes en pacientes con insuficiencia renal y cardíaca."
            },
            {
                text_en: "When caring for a resident with a 'Hearing Aid', the CNA should:",
                text_es: "Al cuidar a un residente con un 'Audífono', el CNA debe:",
                options_en: [
                    "Wash it in soapy water.",
                    "Ensure the aid is turned on and the battery is working.",
                    "Tell the resident to stop wearing it.",
                    "Store it in the resident's pocket."
                ],
                options_es: [
                    "Lavarlo con agua y jabón.",
                    "Asegurarse de que el audífono esté encendido y la batería funcione.",
                    "Decirle al residente que deje de usarlo.",
                    "Guardarlo en el bolsillo del residente."
                ],
                correct: 1,
                reason_en: "Proper maintenance is required for the device to be effective.",
                reason_es: "Se requiere un mantenimiento adecuado para que el dispositivo sea eficaz."
            },
            {
                text_en: "A resident with dementia is 'Eloping'. This means they are:",
                text_es: "Un residente con demencia se está 'fugando' (Eloping). Esto significa que:",
                options_en: ["Getting married.", "Leaving the facility or safe area unsupervised.", "Sleeping too much.", "Eating too fast."],
                options_es: ["Casándose.", "Abandonando el centro o el área segura sin supervisión.", "Durmiendo demasiado.", "Comiendo demasiado rápido."],
                correct: 1,
                reason_en: "Elopement is a major safety risk in long-term care.",
                reason_es: "La fuga (elopement) es un riesgo de seguridad importante en los cuidados a largo plazo."
            },
            {
                text_en: "What is 'Incontinence'?",
                text_es: "¿Qué es la 'Incontinencia'?",
                options_en: [
                    "Inability to control the release of urine or feces.",
                    "A type of stomach flu.",
                    "Increased appetite.",
                    "A skin condition."
                ],
                options_es: [
                    "Incapacidad para controlar la eliminación de orina o heces.",
                    "Un tipo de gripe estomacal.",
                    "Aumento del apetito.",
                    "Una afección de la piel."
                ],
                correct: 0,
                reason_en: "Incontinence requires frequent skin checks to prevent breakdown.",
                reason_es: "La incontinencia requiere controles frecuentes de la piel para evitar su deterioro."
            },
            {
                text_en: "A resident has 'Post-traumatic Stress Disorder (PTSD)'. A common trigger for symptoms is:",
                text_es: "Un residente tiene 'Trastorno de Estrés Postraumático (TEPT)'. Un activador (trigger) común de los síntomas es:",
                options_en: ["Quiet environments.", "Loud noises or situations that remind them of the trauma.", "Eating a favorite meal.", "Reading a book."],
                options_es: ["Entornos tranquilos.", "Ruidos fuertes o situaciones que les recuerden el trauma.", "Comer su plato favorito.", "Leer un libro."],
                correct: 1,
                reason_en: "PTSD involves re-experiencing trauma through triggers.",
                reason_es: "El TEPT implica volver a experimentar el trauma a través de activadores."
            },
            {
                text_en: "Which of the following is a common symptom of a Stroke (CVA)?",
                text_es: "¿Cuál de los siguientes es un síntoma común de un accidente cerebrovascular (ACV)?",
                options_en: ["Sudden weakness or numbness on one side of the body.", "Gradual weight loss.", "Better vision.", "Increased appetite."],
                options_es: ["Debilidad repentina o entumecimiento en un lado del cuerpo.", "Pérdida de peso gradual.", "Mejor visión.", "Aumento del apetito."],
                correct: 0,
                reason_en: "Hemiparesis (weakness on one side) is a hallmark sign of a stroke.",
                reason_es: "La hemiparesia (debilidad en un lado) es un signo característico de un derrame cerebral."
            },
            {
                text_en: "What should the CNA do if a resident's family asks for the results of a recent blood test?",
                text_es: "¿Qué debe hacer el CNA si la familia de un residente pregunta por los resultados de un análisis de sangre reciente?",
                options_en: [
                    "Tell them the results if they know them.",
                    "Refer the family to the nurse or doctor.",
                    "Guess the results.",
                    "Tell them to wait for the mail."
                ],
                options_es: [
                    "Decirles los resultados si los conocen.",
                    "Remitir a la familia a la enfermera o al médico.",
                    "Adivinar los resultados.",
                    "Decirles que esperen al correo."
                ],
                correct: 1,
                reason_en: "Sharing medical results is beyond the CNA scope of practice.",
                reason_es: "Compartir resultados médicos está fuera del alcance de la práctica de un CNA."
            }
        ]
    },
    {
        name: "Batería 4: Salud Mental y Protocolos Avanzados / Mental Health & Advanced Protocols",
        questions: [
            {
                text_en: "A resident with dementia is pacing the hallway and appears agitated. The CNA should:",
                text_es: "Un residente con demencia camina de un lado a otro por el pasillo y parece agitado. El CNA debe:",
                options_en: [
                    "Tell them to sit down immediately.",
                    "Try to determine the cause (e.g., hunger, pain, or need to use the bathroom).",
                    "Lock them in their room until they calm down.",
                    "Ignore them."
                ],
                options_es: [
                    "Decirles que se sienten inmediatamente.",
                    "Tratar de determinar la causa (ej. hambre, dolor o necesidad de ir al baño).",
                    "Cerrarlos en su habitación hasta que se calmen.",
                    "Ignorarlos."
                ],
                correct: 1,
                reason_en: "Agitation is often an unmet need in residents who cannot communicate effectively.",
                reason_es: "La agitación suele ser una necesidad no satisfecha en residentes que no pueden comunicarse eficazmente."
            },
            {
                text_en: "What is 'Reality Orientation' primarily used for?",
                text_es: "¿Para qué se utiliza principalmente la 'Orientación a la Realidad'?",
                options_en: [
                    "Forgetting the past.",
                    "Helping residents with early-stage confusion stay connected to person, place, and time.",
                    "Forcing late-stage Alzheimer's patients to remember their dead relatives.",
                    "Restricting physical movement."
                ],
                options_es: [
                    "Olvidar el pasado.",
                    "Ayudar a los residentes con confusión en etapa temprana a mantenerse conectados con la persona, el lugar y el tiempo.",
                    "Obligar a los pacientes de Alzheimer en etapa avanzada a recordar a sus familiares fallecidos.",
                    "Restringir el movimiento físico."
                ],
                correct: 1,
                reason_en: "Reality orientation uses calendars, clocks, and signs to help confused residents.",
                reason_es: "La orientación a la realidad utiliza calendarios, relojes y letreros para ayudar a los residentes confundidos."
            },
            {
                text_en: "A resident believes that the CNA has stolen their watch. The CNA should:",
                text_es: "Un residente cree que el CNA le ha robado el reloj. El CNA debe:",
                options_en: [
                    "Get angry and defend themselves.",
                    "Search for the watch calmly and report the incident to the nurse.",
                    "Tell the resident they are crazy.",
                    "Ignore the resident's accusation."
                ],
                options_es: [
                    "Enojarse y defenderse.",
                    "Buscar el reloj con calma e informar del incidente a la enfermera.",
                    "Decirle al residente que está loco.",
                    "Ignorar la acusación del residente."
                ],
                correct: 1,
                reason_en: "Delusions are common in dementia; staying calm prevents escalation.",
                reason_es: "Los delirios son comunes en la demencia; mantener la calma evita que la situación empeore."
            },
            {
                text_en: "Which of the following describes 'Depression' in the elderly?",
                text_es: "¿Cuál de los siguientes describe la 'Depresión' en los ancianos?",
                options_en: [
                    "A normal part of aging.",
                    "A serious mood disorder that can cause symptoms like loss of interest and fatigue.",
                    "Just being grumpy.",
                    "Always being happy."
                ],
                options_es: [
                    "Una parte normal del envejecimiento.",
                    "Un trastorno del estado de ánimo grave que puede causar síntomas como pérdida de interés y fatiga.",
                    "Simplemente estar de mal humor.",
                    "Estar siempre feliz."
                ],
                correct: 1,
                reason_en: "Depression is treatable and should never be considered 'normal' for seniors.",
                reason_es: "La depresión es tratable y nunca debe considerarse 'normal' para los ancianos."
            },
            {
                text_en: "What should the CNA do if a resident talks about wanting to commit suicide?",
                text_es: "¿Qué debe hacer el CNA si un residente habla de querer suicidarse?",
                options_en: [
                    "Laugh and say 'You don't mean that'.",
                    "Leave the resident alone to think.",
                    "Stay with the resident and notify the nurse immediately.",
                    "Ask them to wait until tomorrow."
                ],
                options_es: [
                    "Reírse y decir 'No quieres decir eso'.",
                    "Dejar solo al residente para que piense.",
                    "Permanecer con el residente e informar a la enfermera de inmediato.",
                    "Pedirles que esperen hasta mañana."
                ],
                correct: 2,
                reason_en: "All threats of self-harm must be taken seriously and require immediate intervention.",
                reason_es: "Todas las amenazas de autolesión deben tomarse en serio y requieren intervención inmediata."
            },
            {
                text_en: "A resident with Alzheimer's is trying to leave the facility because they believe they have to 'go to work'. This is an example of:",
                text_es: "Un residente con Alzheimer intenta abandonar el centro porque cree que tiene que 'ir a trabajar'. Esto es un ejemplo de:",
                options_en: ["Elopement risk.", "Successful transition.", "Good memory.", "Ambition."],
                options_es: ["Riesgo de fuga (Elopement risk).", "Transición exitosa.", "Buena memoria.", "Ambición."],
                correct: 0,
                reason_en: "Wandering with a purpose (like going to work) can lead to dangerous elopement.",
                reason_es: "Deambular con un propósito (como ir a trabajar) puede conducir a una fuga peligrosa."
            },
            {
                text_en: "The best way to help a resident who is 'Hoarding' items is to:",
                text_es: "La mejor manera de ayudar a un residente que está 'Atesorando' (Hoarding) artículos es:",
                options_en: [
                    "Throw everything away while they are at lunch.",
                    "Scold them for being messy.",
                    "Check for safety and hygiene issues and report findings to the nurse.",
                    "Let them do whatever they want."
                ],
                options_es: [
                    "Tirarlo todo mientras están almorzando.",
                    "Regañarlos por ser desordenados.",
                    "Verificar si hay problemas de seguridad e higiene e informar de los hallazgos a la enfermera.",
                    "Dejarlos hacer lo que quieran."
                ],
                correct: 2,
                reason_en: "Hoarding can be a coping mechanism but may create fire or tripping hazards.",
                reason_es: "El atesoramiento puede ser un mecanismo de defensa, pero puede generar riesgos de incendio o tropiezos."
            },
            {
                text_en: "What is 'Cognitive Impairment'?",
                text_es: "¿Qué es el 'Deterioro Cognitivo'?",
                options_en: [
                    "A type of physical disability.",
                    "Loss of ability to think, remember, or reason clearly.",
                    "Being unable to walk.",
                    "Excellent hearing."
                ],
                options_es: [
                    "Un tipo de discapacidad física.",
                    "Pérdida de la capacidad de pensar, recordar o razonar con claridad.",
                    "No poder caminar.",
                    "Excelente audición."
                ],
                correct: 1,
                reason_en: "Cognitive impairment ranges from mild confusion to severe dementia.",
                reason_es: "El deterioro cognitivo va desde una confusión leve hasta una demencia grave."
            },
            {
                text_en: "When a resident with dementia is resistant to bathing, the CNA should:",
                text_es: "Cuando un residente con demencia se resiste a bañarse, el CNA debe:",
                options_en: [
                    "Force them into the shower.",
                    "Come back later and try again when the resident is more relaxed.",
                    "Tell them they smell bad.",
                    "Skip the bath for a week."
                ],
                options_es: [
                    "Obligarlos a entrar en la ducha.",
                    "Regresar más tarde e intentarlo de nuevo cuando el residente esté más relajado.",
                    "Decirles que huelen mal.",
                    "No bañarlos durante una semana."
                ],
                correct: 1,
                reason_en: "Flexibility and patience are essential for dementia care.",
                reason_es: "La flexibilidad y la paciencia son esenciales para el cuidado de la demencia."
            },
            {
                text_en: "What is the purpose of 'Reminiscence Therapy'?",
                text_es: "¿Cuál es el propósito de la 'Terapia de Reminiscencia'?",
                options_en: [
                    "To test the resident's memory of yesterday's lunch.",
                    "To encourage residents to talk about past experiences and memories.",
                    "To force them to learn new skills.",
                    "To make them feel sad."
                ],
                options_es: [
                    "Poner a prueba la memoria del residente sobre el almuerzo de ayer.",
                    "Animar a los residentes a hablar sobre experiencias y recuerdos pasados.",
                    "Obligarlos a aprender nuevas habilidades.",
                    "Hacer que se sientan tristes."
                ],
                correct: 1,
                reason_en: "Sharing positive past memories can improve self-esteem and mood.",
                reason_es: "Compartir recuerdos positivos del pasado puede mejorar la autoestima y el estado de ánimo."
            },
            {
                text_en: "A resident has 'Bipolar Disorder'. This means they experience:",
                text_es: "Un residente tiene 'Trastorno Bipolar'. Esto significa que experimentan:",
                options_en: [
                    "Extreme mood swings between mania (highs) and depression (lows).",
                    "Constant happiness.",
                    "Total loss of memory.",
                    "Inability to speak."
                ],
                options_es: [
                    "Cambios drásticos de humor entre la manía (altos) y la depresión (bajos).",
                    "Felicidad constante.",
                    "Pérdida total de la memoria.",
                    "Incapacidad para hablar."
                ],
                correct: 0,
                reason_en: "Bipolar disorder is a mental health condition characterized by significant shifts in energy and mood.",
                reason_es: "El trastorno bipolar es una afección de salud mental caracterizada por cambios significativos en la energía y el estado de ánimo."
            },
            {
                text_en: "What is 'Anxiety'?",
                text_es: "¿Qué es la 'Ansiedad'?",
                options_en: [
                    "Feeling very tired.",
                    "A feeling of worry, nervousness, or unease.",
                    "Being very angry.",
                    "Sleeping too much."
                ],
                options_es: [
                    "Sentirse muy cansado.",
                    "Un sentimiento de preocupación, nerviosismo o inquietud.",
                    "Estar muy enojado.",
                    "Dormir demasiado."
                ],
                correct: 1,
                reason_en: "Anxiety can manifest physically with increased heart rate and sweating.",
                reason_es: "La ansiedad puede manifestarse físicamente con un aumento del ritmo cardíaco y sudoración."
            },
            {
                text_en: "Which of the following is a symptom of 'Schizophrenia'?",
                text_es: "¿Cuál de los siguientes es un síntoma de 'Esquizofrenia'?",
                options_en: [
                    "Hallucinations (hearing or seeing things that aren't there).",
                    "Clear, logical thinking.",
                    "Excellent social skills.",
                    "Weight gain."
                ],
                options_es: [
                    "Alucinaciones (escuchar o ver cosas que no están allí).",
                    "Pensamiento claro y lógico.",
                    "Excelentes habilidades sociales.",
                    "Aumento de peso."
                ],
                correct: 0,
                reason_en: "Schizophrenia affects a person's ability to interpret reality correctly.",
                reason_es: "La esquizofrenia afecta la capacidad de una persona para interpretar la realidad correctamente."
            },
            {
                text_en: "A resident is experiencing a 'Panic Attack'. The CNA should:",
                text_es: "Un residente está experimentando un 'Ataque de Pánico'. El CNA debe:",
                options_en: [
                    "Tell them to 'get over it'.",
                    "Leave the room quickly.",
                    "Stay calm, speak in soft tones, and encourage slow, deep breaths.",
                    "Shout for help."
                ],
                options_es: [
                    "Decirles que 'lo superen'.",
                    "Salir de la habitación rápidamente.",
                    "Mantener la calma, hablar en tonos suaves y fomentar respiraciones lentas y profundas.",
                    "Gritar pidiendo ayuda."
                ],
                correct: 2,
                reason_en: "A calming presence helps the person feel safe until the attack passes.",
                reason_es: "Una presencia tranquilizadora ayuda a la persona a sentirse segura hasta que pase el ataque."
            },
            {
                text_en: "What is 'Defense Mechanism'?",
                text_es: "¿Qué es un 'Mecanismo de Defensa'?",
                options_en: [
                    "A type of lock for a door.",
                    "Unconscious behaviors used to release tension or cope with stress.",
                    "A physical fight.",
                    "A type of medication."
                ],
                options_es: [
                    "Un tipo de cerradura para una puerta.",
                    "Comportamientos inconscientes utilizados para liberar tensiones o hacer frente al estrés.",
                    "Una pelea física.",
                    "Un tipo de medicamento."
                ],
                correct: 1,
                reason_en: "Examples include denial, projection, and rationalization.",
                reason_es: "Los ejemplos incluyen la negación, la proyección y la racionalización."
            },
            {
                text_en: "A resident is 'Disoriented'. This means they are NOT aware of:",
                text_es: "Un residente está 'Desorientado'. Esto significa que NO es consciente de:",
                options_en: ["Their favorite food.", "Person, place, or time.", "How to breathe.", "Their age."],
                options_es: ["Su comida favorita.", "Persona, lugar o tiempo.", "Cómo respirar.", "Su edad."],
                correct: 1,
                reason_en: "Orientation checks are a standard part of neuro-assessments.",
                reason_es: "Los controles de orientación son una parte estándar de las evaluaciones neurológicas."
            },
            {
                text_en: "What is 'Delirium' compared to 'Dementia'?",
                text_es: "¿Qué es el 'Delirio' en comparación con la 'Demencia'?",
                options_en: [
                    "Delirium is permanent.",
                    "Delirium is a sudden, temporary state of confusion often caused by illness or infection.",
                    "They are exactly the same.",
                    "Dementia is temporary."
                ],
                options_es: [
                    "El delirio es permanente.",
                    "El delirio es un estado de confusión repentino y temporal causado a menudo por una enfermedad o infección.",
                    "Son exactamente lo mismo.",
                    "La demencia es temporal."
                ],
                correct: 1,
                reason_en: "Delirium is often reversible once the underlying cause (like a UTI) is treated.",
                reason_es: "El delirio suele ser reversible una vez que se trata la causa subyacente (como una ITU)."
            },
            {
                text_en: "A resident is 'Wandering' because they feel the need to walk. The facility should:",
                text_es: "Un residente está 'Deambulando' porque siente la necesidad de caminar. El centro debe:",
                options_en: [
                    "Tie them to a chair.",
                    "Provide a safe wandering path or area for the resident.",
                    "Sedate the resident.",
                    "Tell them to stop."
                ],
                options_es: [
                    "Atarlos a una silla.",
                    "Proporcionar un camino o zona de deambulación segura para el residente.",
                    "Sedar al residente.",
                    "Decirles que se detengan."
                ],
                correct: 1,
                reason_en: "Safe wandering is a way for residents to manage energy and anxiety.",
                reason_es: "La deambulación segura es una forma que tienen los residentes de gestionar la energía y la ansiedad."
            },
            {
                text_en: "What is 'Sun-downing behavior'?",
                text_es: "¿Qué es el 'Comportamiento de Sundowning'?",
                options_en: [
                    "Feeling better in the morning.",
                    "Increased confusion, restlessness, and agitation in the late afternoon or evening.",
                    "Going to bed early.",
                    "Waking up late."
                ],
                options_es: [
                    "Sentirse mejor por la mañana.",
                    "Aumento de la confusión, la inquietud y la agitación al final de la tarde o al anochecer.",
                    "Acostarse temprano.",
                    "Despertarse tarde."
                ],
                correct: 1,
                reason_en: "Sundowning is common in Alzheimer's and is triggered by fading light and fatigue.",
                reason_es: "El sundowning es común en el Alzheimer y se desencadena por la luz que se desvanece y la fatiga."
            },
            {
                text_en: "Which of the following describes 'Pacing'?",
                text_es: "¿Cuál de los siguientes describe el 'Pacing' (caminar de un lado a otro)?",
                options_en: [
                    "Walking back and forth in a specific area.",
                    "Running fast.",
                    "Sitting still.",
                    "Dancing."
                ],
                options_es: [
                    "Caminar de un lado a otro en un área específica.",
                    "Correr rápido.",
                    "Quedarse quieto.",
                    "Bailar."
                ],
                correct: 0,
                reason_en: "Pacing can be a physical expression of anxiety or the need for movement.",
                reason_es: "Pacing puede ser una expresión física de ansiedad o la necesidad de movimiento."
            },
            {
                text_en: "A resident has a 'Advance Directive'. This is a document that:",
                text_es: "Un residente tiene una 'Directiva Anticipada'. Este es un documento que:",
                options_en: [
                    "Lists the resident's favorite activities.",
                    "Outlines the resident's wishes for medical care if they become unable to make decisions.",
                    "Is a map of the facility.",
                    "Is a bill for services."
                ],
                options_es: [
                    "Enumera las actividades favoritas del residente.",
                    "Describe los deseos del residente en cuanto a atención médica si no puede tomar decisiones.",
                    "Es un mapa de las instalaciones.",
                    "Es una factura por los servicios."
                ],
                correct: 1,
                reason_en: "Advance directives include Living Wills and Durable Power of Attorney for Healthcare.",
                reason_es: "Las directivas anticipadas incluyen testamentos vitales y poderes notariales duraderos para la atención médica."
            },
            {
                text_en: "What is 'DNR' (Do Not Resuscitate)?",
                text_es: "¿Qué es 'DNR' (No Reanimar)?",
                options_en: [
                    "Do not provide food.",
                    "An order that medical professionals should not perform CPR if the resident's heart or breathing stops.",
                    "Do not report injuries.",
                    "Do not visit the resident."
                ],
                options_es: [
                    "No proporcionar alimentos.",
                    "Una orden de que los profesionales médicos no deben realizar RCP si el corazón o la respiración del residente se detienen.",
                    "No informar de las lesiones.",
                    "No visitar al residente."
                ],
                correct: 1,
                reason_en: "A DNR order specifically prohibits life-saving resuscitation efforts.",
                reason_es: "Una orden de DNR prohíbe específicamente los esfuerzos de reanimación para salvar vidas."
            },
            {
                text_en: "What is 'Ombudsman'?",
                text_es: "¿Qué es un 'Ombudsman' (Defensor del pueblo/residente)?",
                options_en: [
                    "The facility manager.",
                    "A legal advocate for residents who helps resolve complaints and protect rights.",
                    "A type of nurse.",
                    "A security guard."
                ],
                options_es: [
                    "El gerente del centro.",
                    "Un defensor legal de los residentes que ayuda a resolver quejas y proteger sus derechos.",
                    "Un tipo de enfermera.",
                    "Un guardia de seguridad."
                ],
                correct: 1,
                reason_en: "Ombudsmen are independent advocates for those in long-term care facilities.",
                reason_es: "Los ombudsmen son defensores independientes para quienes se encuentran en centros de cuidados a largo plazo."
            },
            {
                text_en: "Which of the following is a 'Resident Right'?",
                text_es: "¿Cuál de los siguientes es un 'Derecho del Residente'?",
                options_en: [
                    "The right to be treated with dignity and respect.",
                    "The right to have whatever they want for free.",
                    "The right to hit staff.",
                    "The right to leave without paying."
                ],
                options_es: [
                    "El derecho a ser tratado con dignidad y respeto.",
                    "El derecho a tener lo que quieran gratis.",
                    "El derecho a golpear al personal.",
                    "El derecho a irse sin pagar."
                ],
                correct: 0,
                reason_en: "Rights include privacy, confidentiality, and freedom from abuse.",
                reason_es: "Los derechos incluyen la privacidad, la confidencialidad y la protección contra el abuso."
            },
            {
                text_en: "A resident's 'Care Plan' is:",
                text_es: "El 'Plan de Cuidados' de un residente es:",
                options_en: [
                    "A list of rules for the staff only.",
                    "A personalized document that outlines the goals and planned care for the resident.",
                    "A menu for the week.",
                    "A cleaning schedule."
                ],
                options_es: [
                    "Una lista de reglas solo para el personal.",
                    "Un documento personalizado que describe los objetivos y la atención planificada para el residente.",
                    "Un menú para la semana.",
                    "Un horario de limpieza."
                ],
                correct: 1,
                reason_en: "The care plan is updated regularly as the resident's needs change.",
                reason_es: "El plan de cuidados se actualiza regularmente a medida que cambian las necesidades del residente."
            },
            {
                text_en: "When a CNA notices a change in the resident's condition, the most important step is to:",
                text_es: "Cuando un CNA nota un cambio en la condición del residente, el paso más importante es:",
                options_en: [
                    "Wait until tomorrow to see if it gets better.",
                    "Report the change immediately to the nurse.",
                    "Ask the other CNAs what they think.",
                    "Tell the resident's family first."
                ],
                options_es: [
                    "Esperar hasta mañana para ver si mejora.",
                    "Informar del cambio inmediatamente a la enfermera.",
                    "Preguntar a los otros CNA qué piensan.",
                    "Decírselo primero a la familia del residente."
                ],
                correct: 1,
                reason_en: "Timely reporting can prevent serious health complications.",
                reason_es: "Informar a tiempo puede prevenir complicaciones de salud graves."
            },
            {
                text_en: "What should the CNA do if they suspect another staff member is abusing a resident?",
                text_es: "¿Qué debe hacer el CNA si sospecha que otro miembro del personal está abusando de un residente?",
                options_en: [
                    "Ignore it to avoid trouble.",
                    "Report the suspicion to their supervisor immediately.",
                    "Confront the staff member themselves.",
                    "Ask the resident if it's true."
                ],
                options_es: [
                    "Ignorarlo para evitar problemas.",
                    "Informar de la sospecha a su supervisor de inmediato.",
                    "Confrontar al miembro del personal ellos mismos.",
                    "Preguntarle al residente si es verdad."
                ],
                correct: 1,
                reason_en: "CNAs are mandated reporters of abuse and must follow facility protocol.",
                reason_es: "Los CNA tienen la obligación legal de denunciar abusos y deben seguir el protocolo del centro."
            },
            {
                text_en: "What does 'Informed Consent' mean?",
                text_es: "¿Qué significa 'Consentimiento Informado'?",
                options_en: [
                    "The resident is forced to agree.",
                    "The resident makes a decision after receiving full information about a procedure or treatment.",
                    "The family makes all the decisions.",
                    "The doctor decides what is best without asking."
                ],
                options_es: [
                    "El residente se ve obligado a aceptar.",
                    "El residente toma una decisión tras recibir información completa sobre un procedimiento o tratamiento.",
                    "La familia toma todas las decisiones.",
                    "El médico decide qué es lo mejor sin preguntar."
                ],
                correct: 1,
                reason_en: "Residents have the right to know risks and benefits before agreeing to care.",
                reason_es: "Los residentes tienen derecho a conocer los riesgos y beneficios antes de aceptar la atención."
            },
            {
                text_en: "A resident is 'Comatose'. The CNA should still:",
                text_es: "Un residente está 'Comatoso'. El CNA aún así debe:",
                options_en: [
                    "Speak to the resident as if they can hear.",
                    "Not talk in the room.",
                    "Work in total silence.",
                    "Stop providing mouth care."
                ],
                options_es: [
                    "Hablar con el residente como si pudiera oír.",
                    "No hablar en la habitación.",
                    "Trabajar en total silencio.",
                    "Dejar de brindar cuidados bucales."
                ],
                correct: 0,
                reason_en: "Hearing is often the last sense to be lost, even in a coma.",
                reason_es: "El oído suele ser el último sentido en perderse, incluso en coma."
            },
            {
                text_en: "What is 'Personal Protective Equipment' (PPE)?",
                text_es: "¿Qué es el 'Equipo de Protección Personal' (EPP)?",
                options_en: [
                    "Clothing for a party.",
                    "Barriers used to protect against infection (gloves, gowns, masks).",
                    "A type of restraint.",
                    "Personal gym equipment."
                ],
                options_es: [
                    "Ropa para una fiesta.",
                    "Barreras utilizadas para proteger contra infecciones (guantes, batas, mascarillas).",
                    "Un tipo de restricción.",
                    "Equipo de gimnasio personal."
                ],
                correct: 1,
                reason_en: "PPE is essential for maintaining Standard Precautions and Transmission-Based Precautions.",
                reason_es: "El EPP es esencial para mantener las precauciones estándar y las basadas en la transmisión."
            },
            {
                text_en: "When using a 'Gait Belt', the CNA should grasp it:",
                text_es: "Al utilizar un 'Cinturón de Marcha' (Gait Belt), el CNA debe sujetarlo:",
                options_en: [
                    "From the top.",
                    "From the bottom (underhand grasp).",
                    "By the buckle.",
                    "With one finger."
                ],
                options_es: [
                    "Desde arriba.",
                    "Desde abajo (agarre por debajo).",
                    "Por la hebilla.",
                    "Con un solo dedo."
                ],
                correct: 1,
                reason_en: "An underhand grasp provides the best stability and prevents the belt from slipping up.",
                reason_es: "Un agarre por debajo proporciona la mejor estabilidad y evita que el cinturón se deslice hacia arriba."
            },
            {
                text_en: "A resident has 'Isolation Precautions'. A sign on the door says 'Droplet'. The CNA must wear:",
                text_es: "Un residente tiene 'Precauciones de Aislamiento'. Un letrero en la puerta dice 'Gotitas' (Droplet). El CNA debe usar:",
                options_en: [
                    "A gown and gloves only.",
                    "A surgical mask.",
                    "An N95 respirator.",
                    "Nothing extra."
                ],
                options_es: [
                    "Bata y guantes solamente.",
                    "Una mascarilla quirúrgica.",
                    "Un respirador N95.",
                    "Nada extra."
                ],
                correct: 1,
                reason_en: "Droplet precautions require a mask to prevent inhaling larger respiratory droplets.",
                reason_es: "Las precauciones contra gotitas requieren una mascarilla para evitar inhalar gotas respiratorias grandes."
            },
            {
                text_en: "What is the 'Heimlich Maneuver' used for?",
                text_es: "¿Para qué se utiliza la 'Maniobra de Heimlich'?",
                options_en: [
                    "Starting the heart.",
                    "Clearing a blocked airway in a person who is choking.",
                    "Helping someone sleep.",
                    "Treating a burn."
                ],
                options_es: [
                    "Iniciar el corazón.",
                    "Despejar una vía aérea bloqueada en una persona que se está asfixiando.",
                    "Ayudar a alguien a dormir.",
                    "Tratar una quemadura."
                ],
                correct: 1,
                reason_en: "Abdominal thrusts force air out of the lungs to dislodge an object.",
                reason_es: "Las compresiones abdominales fuerzan la salida de aire de los pulmones para desalojar un objeto."
            },
            {
                text_en: "A resident is having a 'Grand Mal Seizure'. The CNA should:",
                text_es: "Un residente está teniendo una 'Convulsión de Gran Mal'. El CNA debe:",
                options_en: [
                    "Put a tongue depressor in their mouth.",
                    "Restrain the resident's movements.",
                    "Protect the resident's head and move furniture out of the way.",
                    "Leave the room to get help."
                ],
                options_es: [
                    "Poner un depresor de lengua en su boca.",
                    "Restringir los movimientos del residente.",
                    "Proteger la cabeza del residente y apartar los muebles del camino.",
                    "Salir de la habitación para pedir ayuda."
                ],
                correct: 2,
                reason_en: "Never put anything in the mouth or restrain a seizing person; focus on safety.",
                reason_es: "Nunca ponga nada en la boca ni restrinja a una persona que convulsiona; concéntrese en la seguridad."
            },
            {
                text_en: "What is 'Abuse'?",
                text_es: "¿Qué es el 'Abuso'?",
                options_en: [
                    "Helping a resident dress.",
                    "Purposeful mistreatment that causes physical, mental, or emotional pain.",
                    "Giving a resident a gift.",
                    "Watching TV with a resident."
                ],
                options_es: [
                    "Ayudar a un residente a vestirse.",
                    "Maltrato intencionado que causa dolor físico, mental o emocional.",
                    "Darle un regalo a un residente.",
                    "Ver la televisión con un residente."
                ],
                correct: 1,
                reason_en: "Abuse can be physical, verbal, sexual, or financial.",
                reason_es: "El abuso puede ser físico, verbal, sexual o financiero."
            },
            {
                text_en: "Which of the following describes 'Self-Determination'?",
                text_es: "¿Cuál de los siguientes describe la 'Autodeterminación'?",
                options_en: [
                    "The right to make choices about one's own life and care.",
                    "Staff deciding everything for the resident.",
                    "The resident having no choice.",
                    "Following a strict facility schedule without input."
                ],
                options_es: [
                    "El derecho a tomar decisiones sobre la propia vida y los cuidados.",
                    "El personal decidiendo todo por el residente.",
                    "El residente no teniendo otra opción.",
                    "Seguir un horario estricto del centro sin intervención."
                ],
                correct: 0,
                reason_en: "Autonomy and self-determination are fundamental ethical principles in care.",
                reason_es: "La autonomía y la autodeterminación son principios éticos fundamentales en los cuidados."
            },
            {
                text_en: "What should the CNA do if a resident's religious beliefs conflict with their care plan?",
                text_es: "¿Qué debe hacer el CNA si las creencias religiosas de un residente entran en conflicto con su plan de cuidados?",
                options_en: [
                    "Tell the resident their religion is wrong.",
                    "Report the concern to the nurse and respect the resident's wishes.",
                    "Ignore the resident's beliefs.",
                    "Force the resident to follow the plan."
                ],
                options_es: [
                    "Decirle al residente que su religión está equivocada.",
                    "Informar del problema a la enfermera y respetar los deseos del residente.",
                    "Ignorar las creencias del residente.",
                    "Obligar al residente a seguir el plan."
                ],
                correct: 1,
                reason_en: "Cultural and religious sensitivity is part of providing person-centered care.",
                reason_es: "La sensibilidad cultural y religiosa forma parte de la prestación de cuidados centrados en la persona."
            },
            {
                text_en: "What is 'Code of Ethics'?",
                text_es: "¿Qué es el 'Código de Ética'?",
                options_en: [
                    "A set of laws.",
                    "Rules that guide professional conduct and moral judgment.",
                    "A secret password.",
                    "A list of employees."
                ],
                options_es: [
                    "Un conjunto de leyes.",
                    "Normas que guían la conducta profesional y el juicio moral.",
                    "Una contraseña secreta.",
                    "Una lista de empleados."
                ],
                correct: 1,
                reason_en: "Ethical behavior involves honesty, confidentiality, and providing quality care.",
                reason_es: "El comportamiento ético implica honestidad, confidencialidad y la prestación de cuidados de calidad."
            },
            {
                text_en: "A resident is 'Choking' but can still cough and speak. The CNA should:",
                text_es: "Un residente se está 'Atragantando' pero aún puede toser y hablar. El CNA debe:",
                options_en: [
                    "Perform the Heimlich maneuver immediately.",
                    "Encourage the resident to keep coughing and stay with them.",
                    "Leave the room to get help.",
                    "Slap the resident on the back."
                ],
                options_es: [
                    "Realizar la maniobra de Heimlich inmediatamente.",
                    "Animar al residente a seguir tosiendo y quedarse con él.",
                    "Darle palmadas en la espalda al residente."
                ],
                correct: 1,
                reason_en: "As long as the person can cough or speak, the airway is not fully blocked.",
                reason_es: "Mientras la persona pueda toser o hablar, la vía aérea no está totalmente bloqueada."
            },
            {
                text_en: "What should the CNA do if they find a resident on the floor?",
                text_es: "¿Qué debe hacer el CNA si encuentra a un residente en el suelo?",
                options_en: [
                    "Pick them up immediately.",
                    "Stay with the resident, call for the nurse, and do not move them.",
                    "Ask the resident to get up themselves.",
                    "Run for help."
                ],
                options_es: [
                    "Recogerlo inmediatamente.",
                    "Quedarse con el residente, llamar a la enfermera y no moverlo.",
                    "Pedirle al residente que se levante solo.",
                    "Salir corriendo a pedir ayuda."
                ],
                correct: 1,
                reason_en: "Moving a fallen resident before a nursing assessment could cause further injury.",
                reason_es: "Mover a un residente que se ha caído antes de una evaluación de enfermería podría causar más lesiones."
            },
            {
                text_en: "Which of the following is an example of 'Verbal Abuse'?",
                text_es: "¿Cuál de los siguientes es un ejemplo de 'Abuso Verbal'?",
                options_en: ["Yelling at or insulting a resident.", "Speaking kindly.", "Singing with a resident.", "Whispering."],
                options_es: ["Gritar o insultar a un residente.", "Hablar con amabilidad.", "Cantar con un residente.", "Susurrar."],
                correct: 0,
                reason_en: "Verbal abuse causes emotional distress and is a violation of resident rights.",
                reason_es: "El abuso verbal causa angustia emocional y es una violación de los derechos del residente."
            },
            {
                text_en: "A resident with Alzheimer's is continually asking to 'Go Home'. The CNA should:",
                text_es: "Un residente con Alzheimer pide continuamente 'Irse a casa'. El CNA debe:",
                options_en: ["Tell them they are already home.", "Argue with them.", "Use validation therapy and redirect them with a gentle activity.", "Ignore them."],
                options_es: ["Decirles que ya están en casa.", "Discutir con ellos.", "Utilizar la terapia de validación y redirigirlos con una actividad suave.", "Ignorarlos."],
                correct: 2,
                reason_en: "Validation therapy acknowledges the resident's feelings while redirection shifts their focus.",
                reason_es: "La terapia de validación reconoce los sentimientos del residente, mientras que la redirección cambia su enfoque."
            },
            {
                text_en: "What is 'Sundowning'?",
                text_es: "¿Qué es el 'Sundowning' (Síndrome del Ocaso)?",
                options_en: [
                    "A type of exercise.",
                    "Increased confusion and agitation that occurs in the late afternoon and evening.",
                    "A way to improve sleep.",
                    "Watching the sunset."
                ],
                options_es: [
                    "Un tipo de ejercicio.",
                    "Aumento de la confusión y agitación que ocurre al final de la tarde y al anochecer.",
                    "Una forma de mejorar el sueño.",
                    "Ver la puesta de sol."
                ],
                correct: 1,
                reason_en: "Sundowning is common in individuals with dementia and requires a calm environment.",
                reason_es: "El 'sundowning' es común en personas con demencia y requiere un entorno tranquilo."
            },
            {
                text_en: "When a resident is 'Hoarding' (collecting many items), the CNA should:",
                text_es: "Cuando un residente está 'Atesorando' (acumulando muchos objetos), el CNA debe:",
                options_en: [
                    "Throw everything away while the resident is sleeping.",
                    "Check the items for safety and sanitation (like spoiled food) while keeping the resident's dignity.",
                    "Shout at the resident.",
                    "Lock the closet."
                ],
                options_es: [
                    "Tirarlo todo mientras el residente duerme.",
                    "Revisar los objetos por seguridad e higiene (como comida estropeada) manteniendo la dignidad del residente.",
                    "Gritar al residente.",
                    "Cerrar con llave el armario."
                ],
                correct: 1,
                reason_en: "Hoarding can be a symptom of dementia; any removal of items should be done according to facility policy.",
                reason_es: "El acaparamiento puede ser un síntoma de demencia; cualquier retirada de objetos debe hacerse de acuerdo con la política del centro."
            },
            {
                text_en: "Which of the following is a symptom of 'Depression' in the elderly?",
                text_es: "¿Cuál de los siguientes es un síntoma de 'Depresión' en los ancianos?",
                options_en: ["Increased energy.", "Loss of interest in activities, withdrawal, and weight changes.", "Frequent laughter.", "Doing more exercises."],
                options_es: ["Aumento de la energía.", "Pérdida de interés en actividades, retraimiento y cambios de peso.", "Risas frecuentes.", "Hacer más ejercicios."],
                correct: 1,
                reason_en: "Depression is often misdiagnosed as dementia in older adults.",
                reason_es: "La depresión a menudo se diagnostica erróneamente como demencia en los adultos mayores."
            },
            {
                text_en: "A resident is experiencing a 'Catastrophic Reaction' (an extreme emotional response). The CNA should:",
                text_es: "Un residente está experimentando una 'Reacción Catastrófica' (una respuesta emocional extrema). El CNA debe:",
                options_en: [
                    "Restrain the resident.",
                    "Stay calm, speak softly, and try to remove the source of stress.",
                    "Yell for help loudly.",
                    "Leave the room."
                ],
                options_es: [
                    "Restringir al residente.",
                    "Mantener la calma, hablar en voz baja y tratar de eliminar la fuente de estrés.",
                    "Gritar pidiendo ayuda en voz alta.",
                    "Salir de la habitación."
                ],
                correct: 1,
                reason_en: "Over-stimulation often triggers catastrophic reactions in dementia patients.",
                reason_es: "La sobreestimulación suele desencadenar reacciones catastróficas en pacientes con demencia."
            },
            {
                text_en: "What is 'Validation Therapy'?",
                text_es: "¿Qué es la 'Terapia de Validación'?",
                options_en: [
                    "Checking if a resident is real.",
                    "Accepting a resident's belief about their reality, even if it is not true.",
                    "Telling the resident they are lying.",
                    "A type of medication."
                ],
                options_es: [
                    "Comprobar si un residente es real.",
                    "Aceptar la creencia de un residente sobre su realidad, aunque no sea cierta.",
                    "Decirle al residente que está mintiendo.",
                    "Un tipo de medicamento."
                ],
                correct: 1,
                reason_en: "Validation therapy reduces anxiety and helps maintain self-esteem in dementia patients.",
                reason_es: "La terapia de validación reduce la ansiedad y ayuda a mantener la autoestima en los pacientes con demencia."
            },
            {
                text_en: "What is 'Reminiscence Therapy'?",
                text_es: "¿Qué es la 'Terapia de Reminiscencia'?",
                options_en: [
                    "Forcing the resident to forget the past.",
                    "Encouraging residents to talk about past experiences and memories.",
                    "Predicting the future.",
                    "Exercise for the legs."
                ],
                options_es: [
                    "Obligar al residente a olvidar el pasado.",
                    "Animar a los residentes a hablar de experiencias y recuerdos pasados.",
                    "Predecir el futuro.",
                    "Ejercicio para las piernas."
                ],
                correct: 1,
                reason_en: "Reminiscing can improve mood and cognitive function in older adults.",
                reason_es: "Recordar puede mejorar el estado de ánimo y la función cognitiva de los adultos mayores."
            },
            {
                text_en: "A resident is 'Wandering'. The most important concern is:",
                text_es: "Un residente está 'Vagando' (Wandering). La preocupación más importante es:",
                options_en: ["The resident's exercise level.", "Safety (risk of getting lost or entering dangerous areas).", "The staff's work schedule.", "The resident's shoes."],
                options_es: ["El nivel de ejercicio del residente.", "La seguridad (riesgo de perderse o entrar en zonas peligrosas).", "El horario de trabajo del personal.", "Los zapatos del residente."],
                correct: 1,
                reason_en: "Wandering can lead to elopement (leaving the facility unnoticed) which is life-threatening.",
                reason_es: "Vagar puede conducir a la fuga (salir del centro sin ser notado), lo que pone la vida en peligro."
            },
            {
                text_en: "What is 'Elopement'?",
                text_es: "¿Qué es la 'Fuga' (Elopement)?",
                options_en: [
                    "Getting married secretly.",
                    "A resident with cognitive impairment leaving a safe area or facility unsupervised.",
                    "A type of hospital food.",
                    "A new exercise program."
                ],
                options_es: [
                    "Casarse en secreto.",
                    "Un residente con deterioro cognitivo que abandona una zona segura o un centro sin supervisión.",
                    "Un tipo de comida de hospital.",
                    "Un nuevo programa de ejercicios."
                ],
                correct: 1,
                reason_en: "Elopement is a critical safety failure and must be reported immediately.",
                reason_es: "La fuga es un fallo de seguridad crítico y debe notificarse inmediatamente."
            },
            {
                text_en: "Which of the following describes 'Agnosia'?",
                text_es: "¿Cuál de los siguientes describe la 'Agnosia'?",
                options_en: [
                    "Loss of movement.",
                    "The inability to recognize objects or people, even though senses are normal.",
                    "Loss of hearing.",
                    "Fast talking."
                ],
                options_es: [
                    "Pérdida de movimiento.",
                    "La incapacidad de reconocer objetos o personas, aunque los sentidos sean normales.",
                    "Pérdida de audición.",
                    "Hablar rápido."
                ],
                correct: 1,
                reason_en: "Agnosia is a common symptom in later stages of Alzheimer's disease.",
                reason_es: "La agnosia es un síntoma común en las etapas posteriores de la enfermedad de Alzheimer."
            },
            {
                text_en: "What is 'Aphasia'?",
                text_es: "¿Qué es la 'Afasia'?",
                options_en: [
                    "Loss of the ability to communicate (speech or understanding).",
                    "Loss of hair.",
                    "A type of stomach ache.",
                    "Inability to walk."
                ],
                options_es: [
                    "Pérdida de la capacidad de comunicarse (habla o comprensión).",
                    "Pérdida de cabello.",
                    "Un tipo de dolor de estómago.",
                    "Incapacidad para caminar."
                ],
                correct: 0,
                reason_en: "Aphasia can be expressive (output) or receptive (input).",
                reason_es: "La afasia puede ser expresiva (salida) o receptiva (entrada)."
            },
            {
                text_en: "A resident has 'Apraxia'. This means they cannot:",
                text_es: "Un residente tiene 'Apraxia'. Esto significa que no puede:",
                options_en: [
                    "See at all.",
                    "Perform purposeful movements or tasks (like brushing teeth) despite having the physical ability.",
                    "Hear loud noises.",
                    "Digest food."
                ],
                options_es: [
                    "No puede ver en absoluto.",
                    "Realizar movimientos o tareas con un propósito (como cepillarse los dientes) a pesar de tener la capacidad física.",
                    "Oír ruidos fuertes.",
                    "Digerir la comida."
                ],
                correct: 1,
                reason_en: "Apraxia is a motor disorder caused by damage to the brain.",
                reason_es: "La apraxia es un trastorno motor causado por daños cerebrales."
            },
            {
                text_en: "When a resident is 'Combative' (trying to hit or kick), the CNA should:",
                text_es: "Cuando un residente está 'Combativo' (tratando de golpear o patear), el CNA debe:",
                options_en: [
                    "Hit the resident back.",
                    "Stay out of reach and try to calm the resident using a low, soothing voice.",
                    "Throw water on them.",
                    "Ignore them entirely."
                ],
                options_es: [
                    "Devolver el golpe al residente.",
                    "Mantenerse fuera de su alcance y tratar de calmar al residente con una voz baja y tranquilizadora.",
                    "Echarles agua encima.",
                    "Ignorarlos por completo."
                ],
                correct: 1,
                reason_en: "Physical aggression is often a sign of fear or unmet needs in dementia patients.",
                reason_es: "La agresión física suele ser un signo de miedo o de necesidades no satisfechas en los pacientes con demencia."
            },
            {
                text_en: "Which of the following is an example of 'Reality Orientation'?",
                text_es: "¿Cuál de los siguientes es un ejemplo de 'Orientación a la Realidad'?",
                options_en: [
                    "Lying to the resident.",
                    "Gently reminding the resident of the actual date, time, and where they are.",
                    "Asking the resident to guess the year.",
                    "Telling the resident they are crazy."
                ],
                options_es: [
                    "Mentir al residente.",
                    "Recordar suavemente al residente la fecha, la hora y el lugar donde se encuentra.",
                    "Pedir al residente que adivine el año.",
                    "Decirle al residente que está loco."
                ],
                correct: 1,
                reason_en: "Reality orientation is best for early-stage dementia or temporary confusion.",
                reason_es: "La orientación a la realidad es mejor para la demencia precoz o la confusión temporal."
            },
            {
                text_en: "What should the CNA do if a resident is 'Hallucinating' (seeing or hearing things not there)?",
                text_es: "¿Qué debe hacer el CNA si un residente está 'Alucinando' (viendo u oyendo cosas que no están allí)?",
                options_en: [
                    "Agree with the hallucination and join in.",
                    "Acknowledge the resident's feelings but do not pretend to see/hear the hallucination.",
                    "Tell the resident they are dreaming.",
                    "Laugh at the resident."
                ],
                options_es: [
                    "Estar de acuerdo con la alucinación y participar.",
                    "Reconocer los sentimientos del residente pero no fingir que ve/oye la alucinación.",
                    "Decirle al residente que está soñando.",
                    "Reírse del residente."
                ],
                correct: 1,
                reason_en: "Validate the emotion behind the experience without reinforcing the false reality.",
                reason_es: "Validar la emoción que subyace a la experiencia sin reforzar la falsa realidad."
            },
            {
                text_en: "Which of the following is true about 'Dementia'?",
                text_es: "¿Cuál de las siguientes afirmaciones es cierta sobre la 'Demencia'?",
                options_en: [
                    "It is a normal part of aging.",
                    "It is a chronic, progressive loss of mental functions.",
                    "It can be cured with a pill.",
                    "It only affects memory."
                ],
                options_es: [
                    "Es una parte normal del envejecimiento.",
                    "Es una pérdida crónica y progresiva de las funciones mentales.",
                    "Puede curarse con una pastilla.",
                    "Sólo afecta a la memoria."
                ],
                correct: 1,
                reason_en: "Dementia affects memory, thinking, behavior, and the ability to perform daily tasks.",
                reason_es: "La demencia afecta a la memoria, el pensamiento, el comportamiento y la capacidad para realizar las tareas diarias."
            },
            {
                text_en: "What is 'Delirium'?",
                text_es: "¿Qué es el 'Delirio'?",
                options_en: [
                    "A permanent state of confusion.",
                    "A sudden, severe state of confusion that is often reversible and caused by an underlying issue (like infection).",
                    "A type of exercise.",
                    "A special diet."
                ],
                options_es: [
                    "Un estado permanente de confusión.",
                    "Un estado súbito y grave de confusión que suele ser reversible y está causado por un problema subyacente (como una infección).",
                    "Un tipo de ejercicio.",
                    "Una dieta especial."
                ],
                correct: 1,
                reason_en: "Delirium is a medical emergency and must be reported immediately.",
                reason_es: "El delirio es una emergencia médica y debe notificarse inmediatamente."
            },
            {
                text_en: "A resident has 'Bipolar Disorder'. This condition involves:",
                text_es: "Un residente tiene 'Trastorno Bipolar'. Esta condición implica:",
                options_en: [
                    "Extreme mood swings from high (mania) to low (depression).",
                    "Always being happy.",
                    "Losing all memory.",
                    "Inability to swallow."
                ],
                options_es: [
                    "Cambios extremos en el estado de ánimo, de alto (manía) a bajo (depresión).",
                    "Estar siempre feliz.",
                    "Perder toda la memoria.",
                    "Incapacidad para tragar."
                ],
                correct: 0,
                reason_en: "Medication and a stable environment are key for managing bipolar disorder.",
                reason_es: "La medicación y un entorno estable son fundamentales para controlar el trastorno bipolar."
            },
            {
                text_en: "What is 'Schizophrenia'?",
                text_es: "¿Qué es la 'Esquizofrenia'?",
                options_en: [
                    "A split personality.",
                    "A complex brain disorder that involves hallucinations and delusional thinking.",
                    "A type of heart problem.",
                    "Loss of hearing."
                ],
                options_es: [
                    "Doble personalidad.",
                    "Un trastorno cerebral complejo que implica alucinaciones y pensamiento delirante.",
                    "Un tipo de problema cardíaco.",
                    "Pérdida de audición."
                ],
                correct: 1,
                reason_en: "Individuals with schizophrenia may lose touch with reality.",
                reason_es: "Las personas con esquizofrenia pueden perder el contacto con la realidad."
            },
            {
                text_en: "If a resident talks about 'Suicide', what is the CNA's FIRST action?",
                text_es: "Si un residente habla de 'Suicidio', ¿cuál es la PRIMERA acción del CNA?",
                options_en: [
                    "Take it as a joke.",
                    "Leave the resident alone to think.",
                    "Stay with the resident and inform the nurse immediately.",
                    "Tell the resident to be happy."
                ],
                options_es: [
                    "Tomárselo como una broma.",
                    "Dejar solo al residente para que piense.",
                    "Quedarse con el residente e informar inmediatamente a la enfermera.",
                    "Decirle al residente que sea feliz."
                ],
                correct: 2,
                reason_en: "All threats of self-harm must be taken seriously and require immediate attention.",
                reason_es: "Todas las amenazas de autolesión deben tomarse en serio y requieren atención inmediata."
            },
            {
                text_en: "What is 'Anxiety Disorder'?",
                text_es: "¿Qué es el 'Trastorno de Ansiedad'?",
                options_en: [
                    "Being a little nervous about a test.",
                    "Excessive, persistent worry and fear that interferes with daily life.",
                    "A type of physical pain.",
                    "A lung infection."
                ],
                options_es: [
                    "Estar un poco nervioso por un examen.",
                    "Preocupación y miedo excesivos y persistentes que interfieren en la vida diaria.",
                    "Un tipo de dolor físico.",
                    "Una infección pulmonar."
                ],
                correct: 1,
                reason_en: "Signs of anxiety include fast heart rate, sweating, and restlessness.",
                reason_es: "Los signos de ansiedad incluyen ritmo cardíaco rápido, sudoración e inquietud."
            },
            {
                text_en: "What is 'OCD' (Obsessive-Compulsive Disorder)?",
                text_es: "¿Qué es el 'TOC' (Trastorno Obsesivo-Compulsivo)?",
                options_en: [
                    "Being very neat.",
                    "Repetitive, unwanted thoughts and behaviors (rituals) that a person feels driven to perform.",
                    "A type of digestion problem.",
                    "Loss of voice."
                ],
                options_es: [
                    "Ser muy ordenado.",
                    "Pensamientos y comportamientos (rituales) repetitivos y no deseados que una persona se siente impulsada a realizar.",
                    "Un tipo de problema digestivo.",
                    "Pérdida de voz."
                ],
                correct: 1,
                reason_en: "Rituals are often a way for the person to manage intense anxiety.",
                reason_es: "Los rituales suelen ser una forma de que la persona controle una ansiedad intensa."
            },
            {
                text_en: "What is 'PTSD' (Post-Traumatic Stress Disorder)?",
                text_es: "¿Qué es el 'TEPT' (Trastorno de Estrés Postraumático)?",
                options_en: [
                    "Being tired after work.",
                    "A mental health condition triggered by witnessing or experiencing a terrifying event.",
                    "A skin condition.",
                    "A type of ear infection."
                ],
                options_es: [
                    "Estar cansado después del trabajo.",
                    "Una afección de salud mental desencadenada al presenciar o experimentar un acontecimiento aterrador.",
                    "Una afección cutánea.",
                    "Un tipo de infección de oído."
                ],
                correct: 1,
                reason_en: "Symptoms include flashbacks, nightmares, and severe anxiety.",
                reason_es: "Los síntomas incluyen escenas retrospectivas (flashbacks), pesadillas y ansiedad grave."
            },
            {
                text_en: "A resident has a 'Phobia'. This is:",
                text_es: "Un residente tiene una 'Fobia'. Esto es:",
                options_en: [
                    "A slight dislike of something.",
                    "An intense, irrational fear of a specific object or situation.",
                    "A type of physical allergy.",
                    "A hobby."
                ],
                options_es: [
                    "Un ligero disgusto por algo.",
                    "Un miedo intenso e irracional a un objeto o situación específicos.",
                    "Un tipo de alergia física.",
                    "Un hobby."
                ],
                correct: 1,
                reason_en: "Phobias can cause physical symptoms like panic attacks.",
                reason_es: "Las fobias pueden causar síntomas físicos como ataques de pánico."
            },
            {
                text_en: "How should a CNA communicate with a resident who has 'Intellectual Disabilities'?",
                text_es: "¿Cómo debe comunicarse un CNA con un residente que tiene 'Discapacidades Intelectuales'?",
                options_en: [
                    "Speak very loudly.",
                    "Use simple words, speak slowly, and treat the resident with respect according to their age.",
                    "Treat the resident like a baby.",
                    "Do not talk to the resident at all."
                ],
                options_es: [
                    "Hablar muy alto.",
                    "Utilizar palabras sencillas, hablar despacio y tratar al residente con respeto de acuerdo con su edad.",
                    "Tratar al residente como a un bebé.",
                    "No hablar en absoluto con el residente."
                ],
                correct: 1,
                reason_en: "Always treat the resident with the dignity they deserve as an adult.",
                reason_es: "Trate siempre al residente con la dignidad que merece como adulto."
            },
        ]
    },
    {
        name: "Batería 5: Cuidados Especializados y Temas Legales y Éticos / Specialized Care & Legal Ethical Issues",
        questions: [
            {
                text_en: "What is the correct way to feed a resident with 'Dysphagia' (difficulty swallowing)?",
                text_es: "¿Cuál es la forma correcta de alimentar a un residente con 'Disfagia' (dificultad para tragar)?",
                options_en: [
                    "Feed them very quickly.",
                    "Feed small bites slowly while the resident is sitting upright (90 degrees).",
                    "Lay them flat on their back.",
                    "Give them large pieces of meat."
                ],
                options_es: [
                    "Alimentarlos muy rápido.",
                    "Alimentar con bocados pequeños lentamente mientras el residente está sentado en posición vertical (90 grados).",
                    "Acostarlos boca arriba.",
                    "Darles grandes trozos de carne."
                ],
                correct: 1,
                reason_en: "An upright position and small, controlled bites reduce the risk of choking and aspiration.",
                reason_es: "La posición erguida y los bocados pequeños y controlados reducen el riesgo de atragantamiento y aspiración."
            },
            {
                text_en: "What should a CNA do if they see a resident's 'IV' (Intravenous) site is red or swollen?",
                text_es: "¿Qué debe hacer un CNA si ve que el sitio de la 'vía intravenosa' (IV) de un residente está rojo o hinchado?",
                options_en: [
                    "Adjust the needle themselves.",
                    "Inform the nurse immediately.",
                    "Stop the flow of fluid.",
                    "Ignore it if the resident isn't complaining."
                ],
                options_es: [
                    "Ajustar la aguja ellos mismos.",
                    "Informar a la enfermera de inmediato.",
                    "Detener el flujo de líquido.",
                    "Ignorarlo si el residente no se queja."
                ],
                correct: 1,
                reason_en: "Redness and swelling can indicate infiltration or infection at the IV site.",
                reason_es: "El enrojecimiento y la hinchazón pueden indicar infiltración o infección en el sitio de la vía IV."
            },
            {
                text_en: "What is 'Supplemental Oxygen' used for?",
                text_es: "¿Para qué se utiliza el 'Oxígeno Suplementario'?",
                options_en: [
                    "To help residents with breathing difficulties maintain proper oxygen levels.",
                    "To make the resident feel cooler.",
                    "To clean the air in the room.",
                    "To help the resident sleep better."
                ],
                options_es: [
                    "Ayudar a los residentes con dificultades respiratorias a mantener niveles adecuados de oxígeno.",
                    "Para que el residente se sienta más fresco.",
                    "Para limpiar el aire de la habitación.",
                    "Para ayudar al residente a dormir mejor."
                ],
                correct: 0,
                reason_en: "Oxygen is a medication and must be handled with care and follow safety precautions.",
                reason_es: "El oxígeno es un medicamento y debe manejarse con cuidado y siguiendo las precauciones de seguridad."
            },
            {
                text_en: "Which of the following is a 'Safety Precaution' for a resident using oxygen?",
                text_es: "¿Cuál de las siguientes es una 'Precaución de Seguridad' para un residente que usa oxígeno?",
                options_en: [
                    "Allowing smoking near the oxygen tank.",
                    "Using oil-based lubricants on the resident's nose.",
                    "Ensuring no open flames or smoking are permitted in the area.",
                    "Turning the oxygen up to a high level whenever the resident wants."
                ],
                options_es: [
                    "Permitir fumar cerca del tanque de oxígeno.",
                    "Usar lubricantes a base de aceite en la nariz del residente.",
                    "Asegurarse de que no se permitan llamas abiertas ni fumar en el área.",
                    "Subir el oxígeno a un nivel alto siempre que el residente quiera."
                ],
                correct: 2,
                reason_en: "Oxygen is highly flammable and increases the risk of fire.",
                reason_es: "El oxígeno es altamente inflamable y aumenta el riesgo de incendio."
            },
            {
                text_en: "What is a 'Specimen'?",
                text_es: "¿Qué es una 'Muestra' (Specimen)?",
                options_en: [
                    "A type of insect.",
                    "A sample of body fluid or tissue used for laboratory testing (urine, stool, sputum).",
                    "A new type of resident.",
                    "A medical degree."
                ],
                options_es: [
                    "Un tipo de insecto.",
                    "Una muestra de fluido o tejido corporal utilizada para análisis de laboratorio (orina, heces, esputo).",
                    "Un nuevo tipo de residente.",
                    "Un título médico."
                ],
                correct: 1,
                reason_en: "Proper collection and labeling of specimens are essential for accurate diagnosis.",
                reason_es: "La toma y el etiquetado correctos de las muestras son esenciales para un diagnóstico preciso."
            },
            {
                text_en: "When collecting a 'Mid-Stream Urine' specimen, the CNA should:",
                text_es: "Al recolectar una muestra de 'Orina de Mitad del Chorro' (Mid-Stream), el CNA debe:",
                options_en: [
                    "Collect all the urine from the beginning.",
                    "Have the resident start urinating, then catch the sample in the middle of the flow.",
                    "Collect the sample from the bottom of the toilet.",
                    "Ask the resident to wait until tomorrow."
                ],
                options_es: [
                    "Recoger toda la orina desde el principio.",
                    "Hacer que el residente empiece a orinar y luego capturar la muestra en la mitad del flujo.",
                    "Recoger la muestra del fondo del inodoro.",
                    "Pedirle al residente que espere hasta mañana."
                ],
                correct: 1,
                reason_en: "Mid-stream collection reduces contamination from surface bacteria.",
                reason_es: "La recolección de mitad del chorro reduce la contaminación por bacterias superficiales."
            },
            {
                text_en: "What is 'Sputum'?",
                text_es: "¿Qué es el 'Esputo'?",
                options_en: [
                    "Saliva from the mouth.",
                    "Mucus coughed up from the lungs.",
                    "Urine.",
                    "Food that has been chewed."
                ],
                options_es: [
                    "Saliva de la boca.",
                    "Mucosidad expulsada de los pulmones al toser.",
                    "Orina.",
                    "Comida que ha sido masticada."
                ],
                correct: 1,
                reason_en: "Sputum specimens are often used to test for respiratory infections.",
                reason_es: "Las muestras de esputo se utilizan a menudo para detectar infecciones respiratorias."
            },
            {
                text_en: "What is the 'Sims Position'?",
                text_es: "¿Qué es la 'Posición de Sims'?",
                options_en: [
                    "Lying flat on the back.",
                    "Lying on the left side with the right knee flexed (often used for enemas).",
                    "Sitting upright in a chair.",
                    "Standing up."
                ],
                options_es: [
                    "Acostado boca arriba.",
                    "Acostado sobre el lado izquierdo con la rodilla derecha flexionada (a menudo utilizado para enemas).",
                    "Sentado erguido en una silla.",
                    "Estar de pie."
                ],
                correct: 1,
                reason_en: "Sims position allows easy access to the rectum.",
                reason_es: "La posición de Sims permite un fácil acceso al recto."
            },
            {
                text_en: "Which of the following describes 'Prone Position'?",
                text_es: "¿Cuál de los siguientes describe la 'Posición Prona'?",
                options_en: ["Lying on the back.", "Lying on the stomach face down.", "Lying on the side.", "Sitting Up."],
                options_es: ["Acostado boca arriba.", "Acostado boca abajo sobre el estómago.", "Acostado de lado.", "Sentado."],
                correct: 1,
                reason_en: "Prone position is less common in elderly residents but may be used for specific treatments.",
                reason_es: "La posición prona es menos común en residentes ancianos, pero puede utilizarse para tratamientos específicos."
            },
            {
                text_en: "What is 'Supine Position'?",
                text_es: "¿Qué es la 'Posición Supina'?",
                options_en: ["Lying flat on the back.", "Lying on the stomach.", "Sitting in a chair.", "Standing."],
                options_es: ["Acostado plano sobre la espalda.", "Acostado sobre el estómago.", "Sentado en una silla.", "De pie."],
                correct: 0,
                reason_en: "Supine is a common sleeping position but can increase the risk of pressure ulcers on the heels and sacrum.",
                reason_es: "La posición supina es una posición común para dormir, pero puede aumentar el riesgo de úlceras por presión en los talones y el sacro."
            },
            {
                text_en: "What is 'Fowler's Position'?",
                text_es: "¿Qué es la 'Posición de Fowler'?",
                options_en: [
                    "A semi-sitting position (head of bed raised 45-60 degrees).",
                    "Lying flat on the stomach.",
                    "Standing up with assistance.",
                    "Lying on the side."
                ],
                options_es: [
                    "Posición semisentada (cabecera de la cama elevada entre 45 y 60 grados).",
                    "Acostado boca abajo sobre el estómago.",
                    "Estar de pie con ayuda.",
                    "Acostado de lado."
                ],
                correct: 0,
                reason_en: "Fowler's position helps with breathing and eating.",
                reason_es: "La posición de Fowler ayuda a respirar y a comer."
            },
            {
                text_en: "When a resident is in the 'Orthopneic Position', they are:",
                text_es: "Cuando un residente está en 'Posición Ortopneica', está:",
                options_en: [
                    "Lying flat on their back.",
                    "Sitting up and leaning forward over a table (often to help with breathing).",
                    "Sleeping on their side.",
                    "Walking with a cane."
                ],
                options_es: [
                    "Acostado boca arriba.",
                    "Sentado e inclinado hacia adelante sobre una mesa (a menudo para ayudar a respirar).",
                    "Durmiendo de lado.",
                    "Caminando con un bastón."
                ],
                correct: 1,
                reason_en: "This position allows for maximum lung expansion.",
                reason_es: "Esta posición permite la máxima expansión pulmonar."
            },
            {
                text_en: "What is 'Logrolling'?",
                text_es: "¿Qué es el 'Logrolling' (Giro en bloque)?",
                options_en: [
                    "A type of exercise.",
                    "Turning a resident as a unit, keeping the head, back, and hips in a straight line.",
                    "Rolling a resident onto the floor.",
                    "A faster way to walk."
                ],
                options_es: [
                    "Un tipo de ejercicio.",
                    "Girar a un residente como una unidad, manteniendo la cabeza, la espalda y las caderas en línea recta.",
                    "Hacer rodar a un residente por el suelo.",
                    "Una forma más rápida de caminar."
                ],
                correct: 1,
                reason_en: "Logrolling is used for residents with spinal injuries to prevent further damage.",
                reason_es: "El logrolling se utiliza para residentes con lesiones medulares para evitar daños mayores."
            },
            {
                text_en: "What is a 'Transfer Board' used for?",
                text_es: "¿Para qué se utiliza una 'Tabla de Transferencia'?",
                options_en: [
                    "As a dining table.",
                    "To bridge the gap between two surfaces (like a bed and a wheelchair) during transfers.",
                    "To restrain a resident.",
                    "To lift a resident into the air."
                ],
                options_es: [
                    "Como mesa de comedor.",
                    "Para cerrar el espacio entre dos superficies (como una cama y una silla de ruedas) durante los traslados.",
                    "Para restringir a un residente.",
                    "Para levantar a un residente por los aires."
                ],
                correct: 1,
                reason_en: "Transfer boards allow residents to slide between surfaces with minimal lifting from staff.",
                reason_es: "Las tablas de transferencia permiten a los residentes deslizarse entre superficies con una elevación mínima por parte del personal."
            },
            {
                text_en: "What is a 'Mechanical Lift' (e.g., Hoyer Lift)?",
                text_es: "¿Qué es un 'Levantador Mecánico' (ej. Grúa Hoyer)?",
                options_en: [
                    "An elevator.",
                    "Equipment used to lift and move residents who cannot bear weight.",
                    "A type of exercise machine.",
                    "A specialized bed."
                ],
                options_es: [
                    "Un elevador.",
                    "Equipo utilizado para levantar y mover a residentes que no pueden soportar peso.",
                    "Un tipo de máquina de ejercicio.",
                    "Una cama especializada."
                ],
                correct: 1,
                reason_en: "Using mechanical lifts prevents back injuries for staff and provides safe transfers for residents.",
                reason_es: "El uso de elevadores mecánicos previene lesiones de espalda en el personal y proporciona traslados seguros a los residentes."
            },
            {
                text_en: "When using a mechanical lift, how many staff members are usually required for safety?",
                text_es: "Al utilizar un levantador mecánico, ¿cuántos miembros del personal se requieren normalmente por seguridad?",
                options_en: ["One.", "At least two.", "Four.", "Six."],
                options_es: ["Uno.", "Al menos dos.", "Cuatro.", "Seis."],
                correct: 1,
                reason_en: "Two people ensure the resident is secure and the equipment is operated correctly.",
                reason_es: "Dos personas garantizan que el residente esté seguro y que el equipo se maneje correctamente."
            },
            {
                text_en: "What is the 'Base of Support' when lifting?",
                text_es: "¿Qué es la 'Base de Apoyo' al levantar?",
                options_en: ["The resident's bed.", "The feet (standing with feet shoulder-width apart).", "The staff's back.", "The floor."],
                options_es: ["La cama del residente.", "Los pies (parado con los pies a la anchura de los hombros).", "La espalda del personal.", "El suelo."],
                correct: 1,
                reason_en: "A wide base of support provides balance and prevents falls.",
                reason_es: "Una base de apoyo amplia proporciona equilibrio y evita las caídas."
            },
            {
                text_en: "Where is the 'Center of Gravity' in the human body?",
                text_es: "¿Dónde está el 'Centro de Gravedad' en el cuerpo humano?",
                options_en: ["In the head.", "In the pelvis or lower abdomen.", "In the feet.", "In the hands."],
                options_es: ["En la cabeza.", "En la pelvis o el abdomen inferior.", "En los pies.", "En las manos."],
                correct: 1,
                reason_en: "Keeping the object being lifted close to your center of gravity makes it easier and safer to move.",
                reason_es: "Mantener el objeto que se levanta cerca del centro de gravedad facilita y hace más seguro el movimiento."
            },
            {
                text_en: "What is 'Body Mechanics'?",
                text_es: "¿Qué es la 'Mecánica Corporal'?",
                options_en: [
                    "A type of car repair.",
                    "Using the body in an efficient and safe way to perform tasks.",
                    "A type of weightlifting sport.",
                    "Learning how muscles work in a lab."
                ],
                options_es: [
                    "Un tipo de reparación de automóviles.",
                    "Utilizar el cuerpo de forma eficaz y segura para realizar las tareas.",
                    "Un tipo de deporte de levantamiento de pesas.",
                    "Aprender cómo funcionan los músculos en un laboratorio."
                ],
                correct: 1,
                reason_en: "Good body mechanics prevent injuries and reduce fatigue.",
                reason_es: "Una buena mecánica corporal previene lesiones y reduce la fatiga."
            },
            {
                text_en: "When a resident is 'Ambulating', the CNA should walk:",
                text_es: "Cuando un residente está 'Ambulando' (caminando), el CNA debe caminar:",
                options_en: [
                    "In front of the resident.",
                    "Behind the resident.",
                    "Slightly behind and to the side of the resident, using a gait belt.",
                    "Ten feet away."
                ],
                options_es: [
                    "Delante del residente.",
                    "Detrás del residente.",
                    "Ligeramente detrás y al lado del residente, utilizando un cinturón de marcha.",
                    "A tres metros de distancia."
                ],
                correct: 2,
                reason_en: "Walking to the side and slightly behind provides the best support if the resident stumbles.",
                reason_es: "Caminar a un lado y ligeramente detrás proporciona el mejor apoyo si el residente tropieza."
            },
            {
                text_en: "What is the correct way to handle a resident's 'Private Property'?",
                text_es: "¿Cuál es la forma correcta de manejar la 'Propiedad Privada' de un residente?",
                options_en: [
                    "Use it whenever you want.",
                    "Treat it with care and respect, as it belongs to the resident.",
                    "Throw it away if it's old.",
                    "Borrow it without asking."
                ],
                options_es: [
                    "Usa la propiedad cuando quieras.",
                    "Trátala con cuidado y respeto, ya que pertenece al residente.",
                    "Tírala si es vieja.",
                    "Pídela prestada sin preguntar."
                ],
                correct: 1,
                reason_en: "Respect for personal belongings is a key part of respect for the individual.",
                reason_es: "El respeto por las pertenencias personales es una parte fundamental del respeto por el individuo."
            },
            {
                text_en: "Which of the following is a sign of 'Financial Abuse'?",
                text_es: "¿Cuál de los siguientes es un signo de 'Abuso Financiero'?",
                options_en: [
                    "A CNA taking money from a resident's wallet.",
                    "A family member paying for the resident's care.",
                    "The resident buying a gift for their grandchild.",
                    "The business office managing the resident's funds."
                ],
                options_es: [
                    "Un CNA tomando dinero de la billetera de un residente.",
                    "Un familiar pagando el cuidado del residente.",
                    "El residente comprando un regalo para su nieto.",
                    "La oficina comercial administrando los fondos del residente."
                ],
                correct: 0,
                reason_en: "Theft or misappropriation of funds is a serious crime and form of abuse.",
                reason_es: "El robo o la malversación de fondos es un delito grave y una forma de abuso."
            },
            {
                text_en: "A resident has 'Dyspnea'. This means they have:",
                text_es: "Un residente tiene 'Disnea'. Esto significa que tiene:",
                options_en: ["Difficulty breathing.", "Swallowing problems.", "A skin rash.", "Ear pain."],
                options_es: ["Dificultad para respirar.", "Problemas de deglución.", "Una erupción cutánea.", "Dolor de oídos."],
                correct: 0,
                reason_en: "Dyspnea is often seen in respiratory and cardiac conditions.",
                reason_es: "La disnea se observa a menudo en afecciones respiratorias y cardíacas."
            },
            {
                text_en: "What is 'Tachycardia'?",
                text_es: "¿Qué es la 'Taquicardia'?",
                options_en: ["A slow heart rate.", "A fast heart rate (over 100 bpm).", "Normal blood pressure.", "Fast breathing."],
                options_es: ["Ritmo cardíaco lento.", "Ritmo cardíaco rápido (más de 100 lpm).", "Presión arterial normal.", "Respiración rápida."],
                correct: 1,
                reason_en: "Tachycardia can be caused by fever, pain, or exercise.",
                reason_es: "La taquicardia puede ser causada por fiebre, dolor o ejercicio."
            },
            {
                text_en: "Which of the following describes 'Bradypnea'?",
                text_es: "¿Cuál de los siguientes describe la 'Bradipnea'?",
                options_en: ["Fast breathing.", "Slow breathing.", "No breathing.", "Deep breathing."],
                options_es: ["Respiración rápida.", "Respiración lenta.", "Ausencia de respiración.", "Respiración profunda."],
                correct: 1,
                reason_en: "Bradypnea refers to a respiratory rate that is lower than normal.",
                reason_es: "La bradipnea se refiere a una frecuencia respiratoria inferior a la normal."
            },
            {
                text_en: "What is 'Hypotension'?",
                text_es: "¿Qué es la 'Hipotensión'?",
                options_en: ["High blood pressure.", "Low blood pressure.", "Rapid heart rate.", "Sugar in the urine."],
                options_es: ["Presión arterial alta.", "Presión arterial baja.", "Ritmo cardíaco rápido.", "Azúcar en la orina."],
                correct: 1,
                reason_en: "Hypotension can cause dizziness and fainting.",
                reason_es: "La hipotensión puede causar mareos y desmayos."
            },
            {
                text_en: "A resident has 'Anuria'. This means:",
                text_es: "Un residente tiene 'Anuria'. Esto significa:",
                options_en: ["Excessive urination.", "Absence of or very little urine production.", "Painful urination.", "Bloody urine."],
                options_es: ["Micción excesiva.", "Ausencia o muy poca producción de orina.", "Micción dolorosa.", "Orina con sangre."],
                correct: 1,
                reason_en: "Anuria is a serious sign of kidney failure.",
                reason_es: "La anuria es un signo grave de insuficiencia renal."
            },
            {
                text_en: "Which of the following is a symptom of 'Cystitis'?",
                text_es: "¿Cuál de los siguientes es un síntoma de 'Cistitis' (infección de vejiga)?",
                options_en: ["Burning during urination and urgency.", "Excessive hunger.", "Clear, painless urine.", "Better sleep."],
                options_es: ["Ardor al orinar y urgencia.", "Hambre excesiva.", "Orina clara y sin dolor.", "Mejor sueño."],
                correct: 0,
                reason_en: "Cystitis is an inflammation of the bladder, usually caused by infection.",
                reason_es: "La cistitis es una inflamación de la vejiga, causada generalmente por una infección."
            },
            {
                text_en: "What is 'Hematuria'?",
                text_es: "¿Qué es la 'Hematuria'?",
                options_en: ["High blood sugar.", "Blood in the urine.", "Pus in the urine.", "Lack of appetite."],
                options_es: ["Nivel alto de azúcar en sangre.", "Sangre en la orina.", "Pus en la orina.", "Falta de apetito."],
                correct: 1,
                reason_en: "Hematuria can indicate infection, stones, or injury.",
                reason_es: "La hematuria puede indicar infección, cálculos o lesiones."
            },
            {
                text_en: "A resident needs 'Post-Mortem Care'. This is care provided:",
                text_es: "Un residente necesita 'Cuidados Post-Mortem'. Estos son los cuidados proporcionados:",
                options_en: ["Before surgery.", "After death.", "During birth.", "While sleeping."],
                options_es: ["Antes de la cirugía.", "Después de la muerte.", "Durante el parto.", "Mientras duerme."],
                correct: 1,
                reason_en: "Post-mortem care ensures the body is handled with dignity and respect.",
                reason_es: "El cuidado post-mortem asegura que el cuerpo sea tratado con dignidad y respeto."
            },
            {
                text_en: "What is 'Rigors'?",
                text_es: "¿Qué es el 'Rigor' (Escalofríos intensos)?",
                options_en: ["Extreme happiness.", "Episodes of intense shivering and shaking often with fever.", "A type of medication.", "A deep sleep."],
                options_es: ["Felicidad extrema.", "Episodios de escalofríos intensos y temblores, a menudo con fiebre.", "Un tipo de medicamento.", "Un sueño profundo."],
                correct: 1,
                reason_en: "Rigors are often a sign of a systemic infection or sepsis.",
                reason_es: "Los rigores suelen ser un signo de una infección sistémica o sepsis."
            },
            {
                text_en: "Which of the following is an 'Advanced Protocol' for a CNA during an emergency?",
                text_es: "¿Cuál de los siguientes es un 'Protocolo Avanzado' para un CNA durante una emergencia?",
                options_en: [
                    "Providing clear information to the arriving EMS team.",
                    "Performing surgery.",
                    "Giving the resident medicine without an order.",
                    "Leaving the facility to get help."
                ],
                options_es: [
                    "Proporcionar información clara al equipo de emergencias (EMS) que llega.",
                    "Realizar una cirugía.",
                    "Darle medicina al residente sin una orden.",
                    "Abandonar el centro para pedir ayuda."
                ],
                correct: 0,
                reason_en: "Accurate communication is vital for the continuity of care during emergencies.",
                reason_es: "La comunicación precisa es vital para la continuidad de los cuidados durante las emergencias."
            },
            {
                text_en: "What is 'Passive ROM'?",
                text_es: "¿Qué es el 'ROM Pasivo'?",
                options_en: [
                    "The resident moves their own joints.",
                    "The CNA moves the resident's joints for them.",
                    "Running a marathon.",
                    "Sitting still."
                ],
                options_es: [
                    "El residente mueve sus propias articulaciones.",
                    "El CNA mueve las articulaciones del residente por él.",
                    "Correr un maratón.",
                    "Quedarse quieto."
                ],
                correct: 1,
                reason_en: "Passive ROM prevents contractures and improves circulation in residents who cannot move.",
                reason_es: "El ROM pasivo previene contracturas y mejora la circulación en residentes que no pueden moverse."
            },
            {
                text_en: "A resident has a 'Restraint'. The CNA must check the resident every:",
                text_es: "Un residente tiene una 'Restricción' (Restraint). El CNA debe revisar al residente cada:",
                options_en: ["15 minutes.", "1 hour.", "4 hours.", "Once a day."],
                options_es: ["15 minutos.", "1 hora.", "4 horas.", "Una vez al día."],
                correct: 0,
                reason_en: "Frequent checks are required to ensure safety and prevent injury from the restraint.",
                reason_es: "Se requieren controles frecuentes para garantizar la seguridad y evitar lesiones causadas por la restricción."
            },
            {
                text_en: "When a restraint is used, it MUST be removed and the resident released every:",
                text_es: "Cuando se utiliza una restricción, esta DEBE retirarse y liberarse al residente cada:",
                options_en: ["30 minutes.", "2 hours.", "8 hours.", "48 hours."],
                options_es: ["30 minutos.", "2 horas.", "8 horas.", "48 horas."],
                correct: 1,
                reason_en: "Residents must be released for exercise, skin care, and toileting.",
                reason_es: "Los residentes deben ser liberados para hacer ejercicio, cuidar su piel e ir al baño."
            },
            {
                text_en: "Which of the following is a 'Negative Side Effect' of restraints?",
                text_es: "¿Cuál de los siguientes es un 'Efecto Secundario Negativo' de las restricciones?",
                options_en: [
                    "Increased risk of pressure ulcers and pneumonia.",
                    "Improved appetite.",
                    "Better balance.",
                    "Faster healing."
                ],
                options_es: [
                    "Aumento del riesgo de úlceras por presión y neumonía.",
                    "Mejor apetito.",
                    "Mejor equilibrio.",
                    "Cicatrización más rápida."
                ],
                correct: 0,
                reason_en: "Restraints can lead to severe physical and psychological decline.",
                reason_es: "Las restricciones pueden provocar un deterioro físico y psicológico grave."
            },
            {
                text_en: "A CNA hits a resident who is being difficult. This is an example of:",
                text_es: "Un CNA golpea a un residente que se está comportando de forma difícil. Esto es un ejemplo de:",
                options_en: ["Physical abuse.", "Good discipline.", "Self-defense.", "Negligence."],
                options_es: ["Abuso físico.", "Buena disciplina.", "Defensa propia.", "Negligencia."],
                correct: 0,
                reason_en: "Physical abuse is any intentional act that causes physical harm or pain.",
                reason_es: "El abuso físico es cualquier acto intencionado que causa daño físico o dolor."
            },
            {
                text_en: "Sexual abuse includes which of the following?",
                text_es: "¿Qué incluye el abuso sexual entre lo siguiente?",
                options_en: [
                    "Touching a resident's private parts without their consent or medical reason.",
                    "Helping a resident dress.",
                    "Giving a bed bath.",
                    "Applying lotion to the arms."
                ],
                options_es: [
                    "Tocar las partes íntimas de un residente sin su consentimiento ni motivo médico.",
                    "Ayudar a un residente a vestirse.",
                    "Dar un baño en la cama.",
                    "Aplicar loción en los brazos."
                ],
                correct: 0,
                reason_en: "Sexual abuse is any non-consensual sexual contact or activity.",
                reason_es: "El abuso sexual es cualquier contacto o actividad sexual no consentida."
            },
            {
                text_en: "Leaving a resident in soiled linens for several hours is an example of:",
                text_es: "Dejar a un residente con la ropa de cama sucia durante varias horas es un ejemplo de:",
                options_en: ["Efficiency.", "Neglect.", "Malpractice.", "Assault."],
                options_es: ["Eficiencia.", "Negligencia / Abandono (Neglect).", "Mala praxis.", "Agresión."],
                correct: 1,
                reason_en: "Neglect is the failure to provide necessary care, resulting in harm.",
                reason_es: "La negligencia (neglect) es la falta de prestación de los cuidados necesarios, lo que produce un daño."
            },
            {
                text_en: "Residents have the right to 'Privacy'. This means the CNA should:",
                text_es: "Los residentes tienen derecho a la 'Privacidad'. Esto significa que el CNA debe:",
                options_en: [
                    "Close the door and pull the curtain during personal care.",
                    "Leave the door open so everyone can see.",
                    "Talk about the resident's care in the hallway.",
                    "Show the resident's body to their friends."
                ],
                options_es: [
                    "Cerrar la puerta y correr la cortina durante el cuidado personal.",
                    "Dejar la puerta abierta para que todos puedan ver.",
                    "Hablar de los cuidados del residente en el pasillo.",
                    "Mostrar el cuerpo del residente a sus amigos."
                ],
                correct: 0,
                reason_en: "Privacy is a fundamental right that maintains a resident's dignity.",
                reason_es: "La privacidad es un derecho fundamental que mantiene la dignidad del residente."
            },
            {
                text_en: "A resident wants to join a 'Resident Council' group. The facility must:",
                text_es: "Un residente quiere unirse a un grupo del 'Consejo de Residentes'. El centro debe:",
                options_en: [
                    "Tell them they are too busy.",
                    "Allow and support the resident's participation in these groups.",
                    "Charge them a fee to join.",
                    "Only allow certain residents to join."
                ],
                options_es: [
                    "Decirles que están demasiado ocupados.",
                    "Permitir y apoyar la participación del residente en estos grupos.",
                    "Cobrarles una cuota por unirse.",
                    "Permitir que sólo se unan ciertos residentes."
                ],
                correct: 1,
                reason_en: "Facilities must allow residents to organize and participate in resident groups.",
                reason_es: "Los centros deben permitir que los residentes se organicen y participen en grupos de residentes."
            },
            {
                text_en: "A resident has the right to see 'Visitors' at any time. The facility should:",
                text_es: "Un residente tiene derecho a recibir 'Visitas' en cualquier momento. El centro debe:",
                options_en: [
                    "Lock the doors and prevent visitors.",
                    "Provide reasonable access to visitors and private space for the visit.",
                    "Only allow visitors on Sundays.",
                    "Monitor the visit with a camera."
                ],
                options_es: [
                    "Cerrar las puertas con llave e impedir las visitas.",
                    "Proporcionar un acceso razonable a los visitantes y un espacio privado para la visita.",
                    "Sólo permitir visitas los domingos.",
                    "Vigilar la visita con una cámara."
                ],
                correct: 1,
                reason_en: "Social contact is essential for a resident's emotional well-being.",
                reason_es: "El contacto social es esencial para el bienestar emocional del residente."
            },
            {
                text_en: "A resident's family offers the CNA $50 as a 'Thank You' gift. The CNA should:",
                text_es: "La familia de un residente ofrece al CNA $50 como regalo de 'Agradecimiento'. El CNA debe:",
                options_en: ["Accept it and keep it secret.", "Politely refuse the money.", "Ask for $100 instead.", "Accept it and share it with other CNAs."],
                options_es: ["Aceptarlo y mantenerlo en secreto.", "Rechazar educadamente el dinero.", "Pedir $100 en su lugar.", "Aceptarlo y compartirlo con otros CNA."],
                correct: 1,
                reason_en: "Accepting tips or gifts is generally against facility policy and ethical standards.",
                reason_es: "Aceptar propinas o regalos suele ir en contra de las políticas del centro y de las normas éticas."
            },
            {
                text_en: "A CNA sees a beautiful comb in a resident's room and decides to 'Borrow' it without asking. This is:",
                text_es: "Un CNA ve un peine precioso en la habitación de un residente y decide 'Tomarlo prestado' sin preguntar. Esto es:",
                options_en: ["Borrowing.", "Theft or misappropriation of property.", "Smart thinking.", "Helping the resident clean."],
                options_es: ["Préstamo.", "Robo o malversación de la propiedad.", "Pensar con inteligencia.", "Ayudar al residente a limpiar."],
                correct: 1,
                reason_en: "Using a resident's personal items without permission is illegal and unethical.",
                reason_es: "Utilizar los objetos personales de un residente sin permiso es ilegal y poco ético."
            },
            {
                text_en: "What is the difference between 'Assault' and 'Battery'?",
                text_es: "¿Cuál de los Navigator.product: diferencia entre 'Agresión' (Assault) y 'Lesiones' (Battery)?",
                options_en: [
                    "Assault is the threat of harm; Battery is the actual physical contact or harm.",
                    "They are the same thing.",
                    "Assault is hitting; Battery is yelling.",
                    "Battery is a type of medical test."
                ],
                options_es: [
                    "Assault es la amenaza de daño; Battery es el contacto físico o daño real.",
                    "Son lo mismo.",
                    "Assault es golpear; Battery es gritar.",
                    "Battery es un tipo de prueba médica."
                ],
                correct: 0,
                reason_en: "Both are legal terms that healthcare workers must understand to avoid liability.",
                reason_es: "Ambos son términos legales que los trabajadores sanitarios deben comprender para evitar responsabilidades."
            },
            {
                text_en: "What is 'False Imprisonment'?",
                text_es: "¿Qué es el 'Encarcelamiento Falso' (False Imprisonment)?",
                options_en: [
                    "Locking a resident in their room or using restraints without a medical order or necessity.",
                    "Going to jail for a crime you didn't commit.",
                    "Helping a resident walk.",
                    "Closing the curtains for privacy."
                ],
                options_es: [
                    "Encerrar a un residente en su habitación o utilizar restricciones sin orden médica o necesidad.",
                    "Ir a la cárcel por un delito que no has cometido.",
                    "Ayudar a un residente a caminar.",
                    "Cerrar las cortinas para tener intimidad."
                ],
                correct: 0,
                reason_en: "Restricting a resident's freedom of movement without legal/medical justification is illegal.",
                reason_es: "Restringir la libertad de movimientos de un residente sin justificación legal/médica es ilegal."
            },
            {
                text_en: "When emptying a 'Colostomy Bag', what should the CNA observe?",
                text_es: "Al vaciar una 'Bolsa de Colostomía', ¿qué debe observar el CNA?",
                options_en: [
                    "The color of the resident's eyes.",
                    "The color, consistency, and amount of the stool.",
                    "The resident's favorite food.",
                    "The weather outside."
                ],
                options_es: [
                    "El color de los ojos del residente.",
                    "El color, la consistencia y la cantidad de las heces.",
                    "La comida favorita del residente.",
                    "El tiempo que hace fuera."
                ],
                correct: 1,
                reason_en: "Changes in stool can indicate infection or other medical issues.",
                reason_es: "Los cambios en las heces pueden indicar una infección u otros problemas médicos."
            },
            {
                text_en: "What is a 'Urostomy'?",
                text_es: "¿Qué es una 'Urostomía'?",
                options_en: [
                    "A surgical opening to drain urine.",
                    "A type of heart surgery.",
                    "A breathing tube.",
                    "A way to see better."
                ],
                options_es: [
                    "Una abertura quirúrgica para drenar la orina.",
                    "Un tipo de cirugía cardíaca.",
                    "Un tubo de respiración.",
                    "Una forma de ver mejor."
                ],
                correct: 0,
                reason_en: "Urostomies are used when the bladder is removed or not functioning.",
                reason_es: "Las urostomías se utilizan cuando se extirpa la vejiga o ésta no funciona."
            },
            {
                text_en: "A resident has a 'Gastrostomy Tube' (G-tube) for feeding. The CNA should report if they see:",
                text_es: "Un residente tiene un 'Tubo de Gastrostomía' (G-tube) para alimentación. El CNA debe informar si ve:",
                options_en: [
                    "Redness, swelling, or drainage around the insertion site.",
                    "The resident sleeping.",
                    "The resident watching TV.",
                    "Normal colored skin."
                ],
                options_es: [
                    "Enrojecimiento, hinchazón o drenaje alrededor del lugar de inserción.",
                    "El residente durmiendo.",
                    "El residente viendo la televisión.",
                    "Piel de color normal."
                ],
                correct: 0,
                reason_en: "Infection at the tube site can be serious.",
                reason_es: "Una infección en el lugar del tubo puede ser grave."
            },
            {
                text_en: "When it comes to 'Suctioning' a resident's airway, the CNA:",
                text_es: "Cuando se trata de 'Succionar' las vías respiratorias de un residente, el CNA:",
                options_en: [
                    "Can perform deep suctioning anytime.",
                    "Is NOT usually permitted to perform deep suctioning; it is a nurse's task.",
                    "Can teach the family how to do it.",
                    "Should do it even if they aren't trained."
                ],
                options_es: [
                    "Puede realizar una succión profunda en cualquier momento.",
                    "Normalmente NO está autorizado a realizar una aspiración profunda; es una tarea de la enfermera.",
                    "Puede enseñar a la familia cómo hacerlo.",
                    "Debe hacerlo aunque no esté capacitado."
                ],
                correct: 1,
                reason_en: "Deep suctioning is an invasive procedure that requires nursing training.",
                reason_es: "La aspiración profunda es un procedimiento invasivo que requiere formación de enfermería."
            },
            {
                text_en: "A resident is in 'Isolation' for a contagious disease. This means:",
                text_es: "Un residente está en 'Aislamiento' por una enfermedad contagiosa. Esto significa que:",
                options_en: [
                    "They should never have visitors.",
                    "Special precautions (like PPE) must be used to prevent the spread of germs.",
                    "The resident is in trouble.",
                    "The resident must be ignored."
                ],
                options_es: [
                    "Nunca deben recibir visitas.",
                    "Deben utilizarse precauciones especiales (como el EPP) para evitar la propagación de gérmenes.",
                    "El residente tiene problemas.",
                    "Hay que ignorar al residente."
                ],
                correct: 1,
                reason_en: "Isolation precautions protect other residents and staff from infection.",
                reason_es: "Las precauciones de aislamiento protegen a otros residentes y al personal de las infecciones."
            },
            {
                text_en: "What is 'C-diff' (Clostridioides difficile)?",
                text_es: "¿Qué es el 'C-diff' (Clostridioides difficile)?",
                options_en: [
                    "A type of vitamins.",
                    "A bacterium that causes severe diarrhea and is highly contagious.",
                    "A skin rash.",
                    "A common cold virus."
                ],
                options_es: [
                    "Un tipo de vitaminas.",
                    "Una bacteria que causa diarrea grave y es muy contagiosa.",
                    "Una erupción cutánea.",
                    "Un virus de resfriado común."
                ],
                correct: 1,
                reason_en: "C-diff requires contact precautions and thorough handwashing (soap and water).",
                reason_es: "El C-diff requiere precauciones de contacto y un lavado de manos a fondo (agua y jabón)."
            },
            {
                text_en: "What is 'MRSA'?",
                text_es: "¿Qué es el 'MRSA'?",
                options_en: [
                    "A type of antibiotics.",
                    "An antibiotic-resistant staph infection.",
                    "A legal document.",
                    "A type of nursing degree."
                ],
                options_es: [
                    "Un tipo de antibióticos.",
                    "Una infección por estafilococo resistente a los antibióticos.",
                    "Un documento legal.",
                    "Un tipo de título de enfermería."
                ],
                correct: 1,
                reason_en: "MRSA is difficult to treat because it does not respond to common antibiotics.",
                reason_es: "El MRSA es difícil de tratar porque no responde a los antibióticos comunes."
            },
            {
                text_en: "What is 'VRE'?",
                text_es: "¿Qué es el 'VRE'?",
                options_en: [
                    "A type of exercise.",
                    "An antibiotic-resistant infection found in the digestive and urinary tracts.",
                    "A vision test.",
                    "A type of heart rate."
                ],
                options_es: [
                    "Un tipo de ejercicio.",
                    "Una infección resistente a los antibióticos que se encuentra en los tractos digestivo y urinario.",
                    "Una prueba de visión.",
                    "Un tipo de ritmo cardíaco."
                ],
                correct: 1,
                reason_en: "Like MRSA, VRE is a serious healthcare-associated infection.",
                reason_es: "Al igual que el MRSA, el VRE es una infección grave asociada a la atención sanitaria."
            },
            {
                text_en: "When 'Donning' (putting on) PPE, what is the generally recommended order?",
                text_es: "Al 'Ponerse' (Donning) el EPP (PPE), ¿cuál es el orden generalmente recomendado?",
                options_en: [
                    "Gloves, then gown, then mask.",
                    "Gown, then mask, then goggles, then gloves.",
                    "Mask first, then anything else.",
                    "Gloves always go on first."
                ],
                options_es: [
                    "Los guantes, luego la bata y después la mascarilla.",
                    "La bata, luego la mascarilla, después las gafas y, por último, los guantes.",
                    "Primero la mascarilla, luego cualquier otra cosa.",
                    "Los guantes siempre se ponen primero."
                ],
                correct: 1,
                reason_en: "The correct order ensures maximum protection and prevents contamination.",
                reason_es: "El orden correcto garantiza la máxima protección y evita la contaminación."
            },
            {
                text_en: "When 'Doffing' (taking off) PPE, what is the generally recommended order?",
                text_es: "Al 'Quitarse' (Doffing) el EPP (PPE), ¿cuál es el orden generalmente recomendado?",
                options_en: [
                    "Gloves first (they are most contaminated), then goggles, then gown, then mask.",
                    "Mask first, then gown.",
                    "Wait until you are in the hallway.",
                    "Take everything off at once."
                ],
                options_es: [
                    "Primero los guantes (son los más contaminados), luego las gafas, después la bata y, por último, la mascarilla.",
                    "Primero la mascarilla y después la bata.",
                    "Espera a estar en el pasillo.",
                    "Quítatelo todo a la vez."
                ],
                correct: 0,
                reason_en: "Taking off the most contaminated items first reduces the risk of accidental spread.",
                reason_es: "Quitar primero los artículos más contaminados reduce el riesgo de propagación accidental."
            },
            {
                text_en: "What should be placed in a 'Biohazard Bag'?",
                text_es: "¿Qué debe colocarse en una 'Bolsa de Riesgo Biológico' (Biohazard Bag)?",
                options_en: [
                    "Regular paper trash.",
                    "Items soaked in blood or body fluids.",
                    "Leftover food.",
                    "Dirty clothes."
                ],
                options_es: [
                    "Basura de papel normal.",
                    "Objetos empapados en sangre o fluidos corporales.",
                    "Restos de comida.",
                    "Ropa sucia."
                ],
                correct: 1,
                reason_en: "Biohazard waste must be handled and disposed of using specific safety protocols.",
                reason_es: "Los residuos biológicos peligrosos deben manipularse y eliminarse siguiendo protocolos de seguridad específicos."
            },
            {
                text_en: "A CNA is a 'Mandatory Reporter'. This means they MUST:",
                text_es: "Un CNA es un 'Informador Obligatorio' (Mandatory Reporter). Esto significa que DEBE:",
                options_en: [
                    "Report any suspected abuse or neglect to their supervisor immediately.",
                    "Report only if they have proof.",
                    "Keep it a secret to protect the facility.",
                    "Wait a week before reporting."
                ],
                options_es: [
                    "Informar inmediatamente a su supervisor de cualquier sospecha de abuso o negligencia.",
                    "Informar sólo si tienen pruebas.",
                    "Mantenerlo en secreto para proteger al centro.",
                    "Esperar una semana antes de informar."
                ],
                correct: 0,
                reason_en: "Failure to report suspected abuse is a legal violation and puts residents at risk.",
                reason_es: "No denunciar las sospechas de abuso es una violación legal y pone en peligro a los residentes."
            },
            {
                text_en: "What is an 'Ombudsman'?",
                text_es: "¿Qué es un 'Defensor del Residente' (Ombudsman)?",
                options_en: [
                    "The facility manager.",
                    "An independent legal advocate for residents who investigates complaints and protects rights.",
                    "A type of doctor.",
                    "A janitor."
                ],
                options_es: [
                    "El gerente del centro.",
                    "Un defensor legal independiente de los residentes que investiga las quejas y protege los derechos.",
                    "Un tipo de médico.",
                    "Un conserje."
                ],
                correct: 1,
                reason_en: "Ombudsmen are advocates for residents' quality of care and quality of life.",
                reason_es: "Los Ombudsman son defensores de la calidad de la atención y de la calidad de vida de los residentes."
            },
            {
                text_en: "What is 'Client's Bill of Rights'?",
                text_es: "¿Qué es la 'Carta de Derechos del Cliente' (Client's Bill of Rights)?",
                options_en: [
                    "A list of the prices of the facility.",
                    "A document that outlines the ethical and legal rights of a person receiving home health care.",
                    "A type of insurance card.",
                    "A map of the local area."
                ],
                options_es: [
                    "Una lista de los precios del centro.",
                    "Un documento que describe los derechos éticos y legales de una persona que recibe atención sanitaria en su domicilio.",
                    "Un tipo de tarjeta de seguro.",
                    "Un mapa de la zona local."
                ],
                correct: 1,
                reason_en: "Patients receiving care at home have specific rights that must be respected by the CNA.",
                reason_es: "Los pacientes que reciben cuidados en casa tienen derechos específicos que el CNA debe respetar."
            },
            {
                text_en: "When it comes to 'Wound Care', the CNA's role is usually to:",
                text_es: "Cuando se trata del 'Cuidado de Heridas', el papel del CNA suele ser:",
                options_en: [
                    "Perform clinical dressing changes on deep wounds.",
                    "Observe the wound and dressing for changes and report them to the nurse.",
                    "Apply antibiotic cream without an order.",
                    "Cut off dead tissue with scissors."
                ],
                options_es: [
                    "Realizar cambios de apósitos clínicos en heridas profundas.",
                    "Observar la herida y el apósito para detectar cambios e informar de ellos a la enfermera.",
                    "Aplicar crema antibiótica sin una orden.",
                    "Cortar el tejido muerto con tijeras."
                ],
                correct: 1,
                reason_en: "Observing and reporting are key CNA functions; clinical wound care is often outside the scope of practice.",
                reason_es: "Observar e informar son funciones fundamentales del CNA; el cuidado clínico de las heridas suele estar fuera de su alcance."
            },
            {
                text_en: "What should the CNA do if a resident asks to see their own medical storage or 'Medical Record'?",
                text_es: "¿Qué debe hacer el CNA si un residente pide ver su propia historia clínica (Medical Record)?",
                options_en: [
                    "Tell them they are not allowed.",
                    "Report the request to the nurse, as residents have a legal right to see their records.",
                    "Show them the record themselves.",
                    "Ignore the request."
                ],
                options_es: [
                    "Decirles que no se les permite.",
                    "Informar de la solicitud a la enfermera, ya que los residentes tienen el derecho legal de ver su historial.",
                    "Mostrarles el historial ellos mismos.",
                    "Ignorar la solicitud."
                ],
                correct: 1,
                reason_en: "Residents have the legal right to access their medical information, but protocols must be followed.",
                reason_es: "Los residentes tienen el derecho legal de acceder a su información médica, pero se deben seguir los protocolos."
            }
        ]
    }
];
