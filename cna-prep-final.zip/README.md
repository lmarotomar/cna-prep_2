# CNA Exam ProMaster | Simulador Profesional

Un simulador de certificación CNA (Certified Nursing Assistant) de **nivel experto**, diseñado siguiendo los estándares de **ProMetric**.

![Versión](https://img.shields.io/badge/Version-1.0.0-blue)
![Bilingüe](https://img.shields.io/badge/Language-English%20%2F%20Spanish-green)

## 🎯 Objetivo del Proyecto
Este simulador está diseñado para preparar a los estudiantes para el examen de certificación CNA con preguntas de alta dificultad, cubriendo no solo los conocimientos básicos sino también protocolos avanzados, ética legal y cuidados especializados.

## 🚀 Características Principales
- **Base de Datos Excepcional:** 311 preguntas originales de nivel experto.
- **Soporte Bilingüe Total:** Cambia entre Inglés, Español o **Modo Biligüe** (ambos idiomas a la vez) en cualquier momento.
- **5 Baterías de Estudio:**
  1. Cuidados Básicos (Higiene, Nutrición, Vitales).
  2. Emergencias y Seguridad.
  3. Paciente Geriátrico y Cuidados Crónicos.
  4. Salud Mental y Protocolos Avanzados.
  5. Cuidados Especializados y Temas Legales y Éticos.
- **Simulación Real:** Temporizador de 90 minutos y requisito del 80% para aprobar.
- **Retroalimentación Inmediata:** Explicaciones detalladas (Racionales) para cada respuesta correcta e incorrecta.

## 💻 Cómo Empezar
No requiere instalación. Solo necesitas un navegador web moderno.

1. Descarga o clona este repositorio.
2. Abre el archivo `index.html` en tu navegador (Chrome, Safari, Edge).

## 📂 Estructura del Proyecto
- `index.html`: Menú principal y selección de batería.
- `exam.html`: Interfaz del simulador de examen.
- `css/`: Estilos modernos y responsivos.
- `js/app.js`: Lógica del simulador y gestión de estados.
- `js/questions.js`: Base de datos de las 311 preguntas.

## 🛠️ Tecnologías Utilizadas
- HTML5 / CSS3 (Vanilla)
- JavaScript (ES6+)
- Google Fonts (Inter)

---
*Desarrollado para el éxito en la certificación profesional.*
